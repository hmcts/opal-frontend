/**
 * @file cypress.config.ts
 * @description Cypress configuration, plugin wiring, and reporting setup for Opal.
 */
import { defineConfig } from 'cypress';
import { mergeZephyrReports, cleanZephyrReports } from '@hmcts/zephyr-automation-nodejs';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

import {
  addCucumberPreprocessorPlugin,
  beforeRunHandler,
  afterRunHandler,
  afterSpecHandler,
  afterScreenshotHandler,
} from '@badeball/cypress-cucumber-preprocessor';
import TsconfigPathsPlugin from 'tsconfig-paths-webpack-plugin';
import * as path from 'node:path';
import {
  ensureAccountCaptureFile,
  initializeAccountCapture,
  registerAccountCaptureTasks,
  resetEvidenceForRun,
  releaseEvidenceResetLock,
} from './cypress/support/tasks/accountCaptureTask';
import { cleanupEmptyScreenshotDirs, registerScreenshotTasks } from './cypress/support/tasks/screenshotTask';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const webpackPreprocessor = require('@cypress/webpack-preprocessor');

interface IAngularWorkspaceProjectBuildOptions {
  tsConfig?: string;
  assets?: unknown[];
  styles?: string[];
  stylePreprocessorOptions?: {
    includePaths?: string[];
  };
  scripts?: string[];
  allowedCommonJsDependencies?: string[];
  inlineStyleLanguage?: string;
  [key: string]: unknown;
}

interface IAngularWorkspaceProject {
  root?: string;
  sourceRoot: string;
  architect: {
    build: {
      options: IAngularWorkspaceProjectBuildOptions;
      configurations?: {
        development?: Record<string, unknown>;
      };
    };
  };
}

interface IAngularWorkspaceConfig {
  projects: Record<string, IAngularWorkspaceProject>;
}

const resolveBrowserToRun = (): string => (process.env.BROWSER_TO_RUN || 'edge').trim().toLowerCase();
const resolvedBrowserToRun = resolveBrowserToRun();
const componentTsconfigPath = path.resolve(__dirname, 'cypress/tsconfig.json');
const componentStylesPath = path.resolve(__dirname, 'cypress/support/component-styles.scss');
const angularWorkspace = JSON.parse(
  readFileSync(path.resolve(__dirname, 'angular.json'), 'utf8'),
) as IAngularWorkspaceConfig;
const angularProject = angularWorkspace.projects['opal-frontend'];
const componentProjectConfig = {
  root: angularProject.root || '.',
  sourceRoot: angularProject.sourceRoot,
  buildOptions: {
    ...angularProject.architect.build.options,
    ...(angularProject.architect.build.configurations?.development || {}),
    styles: [path.relative(__dirname, componentStylesPath)],
  },
};

/**
 * Register browser launch hooks to standardize window size in headless runs.
 * @param on - Cypress plugin event emitter.
 * @returns void
 */
function setupBrowserLaunch(on: Cypress.PluginEvents): void {
  on('before:browser:launch', (browser: Cypress.Browser, launchOptions: Cypress.BeforeBrowserLaunchOptions) => {
    // eslint-disable-next-line no-console
    console.log('launching browser %s is headless? %s', browser.name, browser.isHeadless);

    const width = 3640;
    const height = 2560;

    // eslint-disable-next-line no-console
    console.log('setting the browser window size to %d x %d', width, height);

    if (browser.name === 'chrome' && browser.isHeadless) {
      launchOptions.args = [
        ...(launchOptions.args ?? []),
        `--window-size=${width},${height}`,
        '--force-device-scale-factor=1',
      ];
    }

    if (browser.name === 'electron' && browser.isHeadless) {
      launchOptions.preferences = {
        ...launchOptions.preferences,
        width,
        height,
      } as typeof launchOptions.preferences;
    }

    if (browser.name === 'firefox' && browser.isHeadless) {
      launchOptions.args = [...(launchOptions.args ?? []), `--width=${width}`, `--height=${height}`];
    }

    return launchOptions;
  });
}

/**
 * Configure Cypress node event handlers, plugins, and per-run evidence tasks.
 * @param on - Cypress plugin event emitter.
 * @param config - Cypress plugin configuration.
 * @returns Cypress plugin configuration after setup.
 */
async function setupNodeEvents(
  on: Cypress.PluginEvents,
  config: Cypress.PluginConfigOptions,
): Promise<Cypress.PluginConfigOptions> {
  const e2eTsconfigPath = path.resolve(__dirname, 'e2e.tsconfig.json');

  await addCucumberPreprocessorPlugin(on, config, {
    omitAfterScreenshotHandler: true,
    omitAfterSpecHandler: true,
  });
  // Evidence reset is handled in before:run with a per-run lock.
  // Register tasks so Cypress can write the per-run created-accounts artifact.
  registerAccountCaptureTasks(on);
  // Register tasks to relocate scenario evidence screenshots.
  registerScreenshotTasks(on, config);
  // Relay selected logs to the terminal for CI troubleshooting.
  on('task', {
    'contentDigest:sha512Base64': (payload: unknown) => {
      if (typeof payload !== 'string') {
        throw new TypeError('contentDigest:sha512Base64 expects a string payload');
      }

      return createHash('sha512').update(payload, 'utf8').digest('base64');
    },
    'log:message': (payload: unknown) => {
      if (typeof payload === 'string') {
        // eslint-disable-next-line no-console
        console.log(payload);
        return null;
      }
      if (payload && typeof payload === 'object') {
        const record = payload as { message?: unknown; details?: unknown };
        if (typeof record.message === 'string') {
          // eslint-disable-next-line no-console
          console.log(record.message);
        }
        if (typeof record.details !== 'undefined') {
          try {
            // eslint-disable-next-line no-console
            console.log(typeof record.details === 'string' ? record.details : JSON.stringify(record.details));
          } catch {
            // eslint-disable-next-line no-console
            console.log(record.details);
          }
        }
      }
      return null;
    },
  });

  on(
    'file:preprocessor',
    webpackPreprocessor({
      webpackOptions: {
        // IMPORTANT: use a valid sourcemap mode, not false,
        // to avoid broken Base64 / "length must be multiple of 4" errors.
        devtool: 'eval',
        resolve: {
          extensions: ['.ts', '.js'],
          plugins: [
            new TsconfigPathsPlugin({
              configFile: e2eTsconfigPath,
            }),
          ],
        },
        module: {
          rules: [
            {
              test: /\.ts$/,
              exclude: [/node_modules/, /src/],
              use: [
                {
                  loader: 'ts-loader',
                  options: {
                    context: __dirname,
                    configFile: e2eTsconfigPath,
                    // keep transpileOnly to speed up bundling for Cypress
                    transpileOnly: true,
                    compilerOptions: {
                      // TS sourcemaps are optional; Webpack devtool handles
                      // bundle-level sourcemaps for Cucumber.
                      sourceMap: false,
                      inlineSourceMap: false,
                      inlineSources: false,
                    },
                  },
                },
              ],
            },
            {
              test: /\.feature$/,
              include: [/cypress\/e2e/],
              use: [
                {
                  loader: '@badeball/cypress-cucumber-preprocessor/webpack',
                  options: config,
                },
              ],
            },
          ],
        },
      },
    }),
  );

  setupBrowserLaunch(on);

  // Initialize the artifact at run start and flush it at run end.
  on('before:run', async () => {
    await beforeRunHandler(config);
    await resetEvidenceForRun();
    await initializeAccountCapture();
  });

  // Flush the artifact to disk once the entire run completes.
  on('after:run', async (results) => {
    await ensureAccountCaptureFile();
    try {
      await afterRunHandler(config, results);
    } finally {
      await releaseEvidenceResetLock();
      await cleanupEmptyScreenshotDirs(config.screenshotsFolder as string | undefined);
    }
  });

  // In open mode, clean up per-run locks after each spec execution.
  on('after:spec', async (spec, results) => {
    try {
      await afterSpecHandler(config, spec, results);
    } finally {
      await releaseEvidenceResetLock();
      await cleanupEmptyScreenshotDirs(config.screenshotsFolder as string | undefined);
    }
  });

  // Only attach screenshots for failed steps (evidence screenshots attach separately).
  on('after:screenshot', async (details) => {
    if (!details?.testFailure) {
      return details;
    }
    return afterScreenshotHandler(config, details);
  });

  const browserToRun = resolveBrowserToRun();

  // OPAL runs keep browser-specific artifacts for all browsers and stages.
  if (process.env.TEST_MODE === 'OPAL') {
    const baseOutputDir = `${process.env.TEST_STAGE}-output/prod/${browserToRun}`;
    config.env.messagesOutput = `${baseOutputDir}/cucumber/${process.env.TEST_MODE}-report-${process.env.CYPRESS_THREAD}.ndjson`;
  } else if (process.env.TEST_MODE === 'LEGACY') {
    config.env.messagesOutput =
      `${process.env.TEST_STAGE}-output/prod/${browserToRun}/legacy/cucumber/` +
      `${process.env.TEST_MODE}-report-${process.env.CYPRESS_THREAD}.ndjson`;
  }

  return config;
}

export default defineConfig({
  viewportWidth: 2560,
  viewportHeight: 2560,
  reporter: 'junit',
  // Keep failure screenshots in a browser-specific output location by default.
  screenshotsFolder: `functional-output/screenshots/${resolvedBrowserToRun}`,

  e2e: {
    baseUrl: process.env.TEST_URL || 'http://localhost:4000/',
    specPattern: 'cypress/e2e/**/*.feature',
    excludeSpecPattern: [
      '**/*/*.cy.ts',
      'cypress/e2e/DiscoPlus_accountEnquiry/**/*',
      'cypress/e2e/Old_functional_E2E_Tests/**/*',
    ],
    setupNodeEvents,
    retries: { runMode: 1, openMode: 0 },
    // make sure our support file always loads
    supportFile: 'cypress/support/e2e.ts',
  },

  experimentalModifyObstructiveThirdPartyCode: true,
  chromeWebSecurity: false,

  env: {
    CYPRESS_TEST_EMAIL: process.env.OPAL_TEST_USER_EMAIL,
    CYPRESS_TEST_PASSWORD: process.env.OPAL_TEST_USER_PASSWORD,
    TEST_MODE: process.env.TEST_MODE || 'OPAL',
    TAGS: process.env.TAGS || '',
    DEV_DEFAULT_APP_MODE: process.env.DEV_DEFAULT_APP_MODE || '',
    DEFAULT_APP_MODE: process.env.DEFAULT_APP_MODE || '',
    LEGACY_ENABLED: process.env.LEGACY_ENABLED || false,
    omitFiltered: true,
    filterSpecs: true,
  },

  component: {
    devServer: {
      framework: 'angular',
      bundler: 'webpack',
      options: {
        projectConfig: componentProjectConfig,
      },
      webpackConfig: {
        devServer: {
          port: Number(`809${process.env.CYPRESS_THREAD || '0'}`),
        },
        resolve: {
          extensions: ['.ts', '.js'],
          plugins: [
            new TsconfigPathsPlugin({
              configFile: componentTsconfigPath,
            }),
          ],
        },
      },
    },
    specPattern: 'cypress/component/**/*.cy.ts',
    reporter: 'cypress-multi-reporters',
    reporterOptions: {
      reporterEnabled:
        'cypress-mochawesome-reporter, mocha-junit-reporter, @hmcts/zephyr-automation-nodejs/cypress/ZephyrReporter',
      mochaJunitReporterReporterOptions: {
        mochaFile: `functional-output/component/${resolvedBrowserToRun}/junit/component-test-output-[hash].xml`,
        toConsole: false,
      },
      cypressMochawesomeReporterReporterOptions: {
        reportDir: `functional-output/component/${resolvedBrowserToRun}/json`,
        overwrite: false,
        html: false,
        json: true,
      },
    },
    /**
     * Configure component testing plugins and reporters.
     * @param on - Cypress plugin event emitter.
     * @param config - Cypress plugin configuration.
     * @returns Cypress plugin configuration after setup.
     */
    setupNodeEvents(on, config) {
      setupBrowserLaunch(on);
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { plugin: cypressGrepPlugin } = require('@cypress/grep/plugin');
      cypressGrepPlugin(config);
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      require('cypress-mochawesome-reporter/plugin')(on);

      on('before:run', () => {
        cleanZephyrReports({
          rootDir: 'functional-output',
        });
      });
      on('after:run', () => {
        mergeZephyrReports({
          rootDir: 'functional-output',
          dedupe: true,
        });
      });
      config.env.messagesOutput = `${process.env.TEST_STAGE}-output/prod/cucumber/${process.env.TEST_MODE}-report-${process.env.CYPRESS_THREAD}.ndjson`;
      return config;
    },
  },
});
