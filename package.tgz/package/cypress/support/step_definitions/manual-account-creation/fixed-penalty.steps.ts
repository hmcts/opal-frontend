/**
 * @file fixed-penalty.steps.ts
 * @description
 * Step definitions for the Fixed Penalty manual account journey, wiring
 * Cucumber steps to Cypress flows/actions and ensuring draft cleanup between runs.
 */
import { Given, When, Then, DataTable } from '@badeball/cypress-cucumber-preprocessor';
import { DefendantType } from '../../../e2e/functional/opal/actions/manual-account-creation/create-account.actions';
import { FixedPenaltyFlow } from '../../../e2e/functional/opal/flows/fixed-penalty.flow';
import { FixedPenaltyDetailsActions } from '../../../e2e/functional/opal/actions/manual-account-creation/fixed-penalty-details.actions';
import { FixedPenaltyReviewActions } from '../../../e2e/functional/opal/actions/manual-account-creation/fixed-penalty-review.actions';
import { DraftAccountsInterceptActions } from '../../../e2e/functional/opal/actions/draft-accounts.intercepts';
import { DraftTabsActions } from '../../../e2e/functional/opal/actions/draft-tabs.actions';
import { log } from '../../utils/log.helper';
import { CommonActions } from '../../../e2e/functional/opal/actions/common/common.actions';
import { installDraftAccountCleanup } from '../../../support/draftAccounts';
import { applyUniqPlaceholder } from '../../utils/stringUtils';

installDraftAccountCleanup();

const flow = () => new FixedPenaltyFlow();
const details = () => new FixedPenaltyDetailsActions();
const review = () => new FixedPenaltyReviewActions();
const intercepts = () => new DraftAccountsInterceptActions();
const tabs = () => new DraftTabsActions();
const common = () => new CommonActions();

const mapSummaryRows = (table: DataTable) =>
  table
    .rows()
    .map(([label, value]) => ({ label: label.trim(), value: (value ?? '').trim() }))
    .filter(({ label }) => !!label && !/^label$/i.test(label));

const mapFieldExpectations = (table: DataTable) => {
  const rows = table.rows();
  const hasHeader = rows.length > 0 && rows[0][0].toLowerCase() === 'field';
  const relevantRows = hasHeader ? rows.slice(1) : rows;
  return Object.fromEntries(relevantRows.map(([field, value]) => [field, value]));
};

/**
 * @step Starts a Fixed Penalty account selecting originator type with the provided business unit, defendant type.
 * @description Navigates from the dashboard into Manual Account Creation and selects Fixed Penalty + defendant type.
 * @param businessUnit - Business unit option to pick.
 * @param defendantType - Defendant type option to pick.
 * @example
 *   When I start a fixed penalty account for business unit "West London", defendant type "Adult or youth only" and originator type "New"
 */
When(
  'I start a fixed penalty account for business unit {string}, defendant type {string} and originator type {string}',
  (businessUnit: string, defendantType: DefendantType, originatorType: 'New' | 'Transfer in') => {
    log('step', 'Starting fixed penalty account', { businessUnit, defendantType, originatorType });
    flow().startFixedPenaltyAccount(businessUnit, defendantType, originatorType);
  },
);

/**
 * @step Completes the Fixed Penalty details form using a Section/Field/Value table.
 * @description Maps the provided table into the composite details payload and fills the form.
 * @param table - DataTable containing Section, Field, Value columns.
 * @example
 *   When I complete fixed penalty details:
 *     | Section          | Field         | Value   |
 *     | Personal details | First names   | John    |
 */
When('I complete fixed penalty details:', (table: DataTable) => {
  log('step', 'Completing fixed penalty details from table');
  const rowsWithUniq = table
    .raw()
    .map((row) => row.map((cell, idx) => (idx === 2 ? applyUniqPlaceholder(cell) : cell)));
  flow().completeDetailsFromTable(rowsWithUniq);
});

/**
 * @step Proceeds to the Fixed Penalty review page.
 * @description Clicks Review Account and asserts the review page is displayed.
 */
When('I review the fixed penalty account', () => {
  log('navigate', 'Proceeding to fixed penalty review');
  flow().goToReview();
});

/**
 * @step Attempts to proceed to review while expecting validation errors.
 * @description Clicks Review Account but asserts we stay on details due to validation failures.
 */
When('I attempt to review the fixed penalty account', () => {
  log('navigate', 'Attempting to review fixed penalty account (expecting validation errors)');
  flow().attemptReviewExpectingErrors();
});

/**
 * @step Asserts a review summary section contains expected rows.
 * @description Validates summary list label/value pairs for the given section.
 * @param section - Section name (e.g., "Offence details").
 * @param table - DataTable of Label/Value rows.
 * @example
 *   Then the fixed penalty review "Offence details" summary is:
 *     | Label          | Value   |
 *     | Notice number  | FPN1234 |
 */
Then('the fixed penalty review {string} summary is:', (section: string, table: DataTable) => {
  const rows = mapSummaryRows(table);
  log('assert', 'Asserting fixed penalty review summary', { section, rows });
  review().assertSummary(section, rows);
});

/**
 * @step Opens change links for multiple review sections and returns to review.
 * @description Iterates provided sections, clicks Change, asserts details page, then returns to review.
 * @param table - DataTable with a single Section column.
 * @example
 *   When I change the fixed penalty sections from review:
 *     | Section          |
 *     | Personal details |
 *     | Offence details  |
 */
When('I change the fixed penalty sections from review:', (table: DataTable) => {
  const sections = table
    .rows()
    .map(([section]) => section.trim())
    .filter(Boolean)
    .filter((section) => !/^section$/i.test(section));

  if (!sections.length) {
    throw new Error('No sections provided to change from review');
  }

  sections.forEach((section) => {
    log('navigate', `Opening change link from review (${section})`, { section });
    flow().openChangeAndReturnToReview(section);
  });
});

/**
 * @step Returns from the review page to Fixed Penalty details.
 * @description Clicks Back on review and asserts the details page is shown.
 */
When('I return to fixed penalty details from review', () => {
  log('navigate', 'Returning to Fixed Penalty details from review');
  flow().goBackFromReview();
});

/**
 * @step Opens the delete account flow from review.
 * @description Clicks Delete account on the Fixed Penalty review page.
 */
When('I request fixed penalty account deletion', () => {
  log('navigate', 'Opening delete account from review');
  review().openDeleteAccount();
});

/**
 * @step Cancels the delete account confirmation.
 * @description Clicks the cancel option on the delete confirmation page.
 */
When('I cancel fixed penalty account deletion', () => {
  log('cancel', 'Cancelling delete account confirmation');
  review().cancelDeletion();
});

/**
 * @step Submits the fixed penalty account and records the generated account number.
 * @description Clicks Submit for review, waits for POST response, and logs the id for cleanup.
 */
When('I submit the fixed penalty account for review and capture the draft account id', () => {
  log('navigate', 'Submitting fixed penalty account and capturing draft account id');
  flow().submitForReviewAndCapture();
});

/**
 * @step Submits the fixed penalty account for review.
 * @description Clicks Submit for review without capturing the account id.
 */
When('I submit the fixed penalty account for review', () => {
  log('navigate', 'Submitting fixed penalty account');
  flow().submitForReview();
});

/**
 * @step Stubs the submit-for-review call to return a specific status.
 * @description Intercepts POST /draft-accounts and forces the given error code.
 * @param statusCode - HTTP status to stub.
 */
When('I stub fixed penalty submission as failing with status {int}', (statusCode: number) => {
  log('intercept', 'Stubbing fixed penalty submission failure', { statusCode });
  flow().stubSubmitError(statusCode);
});

/**
 * @step Asserts the Fixed Penalty review page shows the global error banner.
 * @description Checks for the standard failure banner on the review screen.
 */
Then('I see the fixed penalty global error banner', () => {
  log('assert', 'Checking global error banner');
  review().assertGlobalErrorBanner();
});

/**
 * @step Cancels out of Fixed Penalty details via the Cancel control.
 * @description Handles the unsaved changes confirmation with the provided choice.
 * @param choice - "Ok" to leave or "Cancel" to stay.
 */
When('I cancel fixed penalty details choosing {string}', (choice: 'Ok' | 'Cancel') => {
  log('cancel', 'Cancelling fixed penalty details', { choice });
  details().cancelAndChoose(choice);
});

/**
 * @step Asserts Fixed Penalty details fields contain expected values.
 * @description Maps a Field/Value table into assertions on the details form.
 * @param table - DataTable of field/value pairs.
 */
Then('the fixed penalty details fields are:', (table: DataTable) => {
  const expected = mapFieldExpectations(table);
  log('assert', 'Asserting fixed penalty field values', { expected });
  details().assertFields(expected);
});

/**
 * @step Asserts a specific inline or summary error for a Fixed Penalty field.
 * @description Checks for the provided validation message tied to the given field label.
 * @param message - Expected validation text.
 * @param fieldLabel - Human-readable field label.
 */
Then('I see a fixed penalty error {string} for {string}', (message: string, fieldLabel: string) => {
  log('assert', 'Asserting fixed penalty inline error', { fieldLabel, message });
  details().assertInlineError(fieldLabel, message);
});

/**
 * @step Navigates back from Fixed Penalty details, handling unsaved changes.
 * @description Uses the page back link and responds to the confirm dialog with the given choice.
 * @param choice - "Ok" to leave or "Cancel" to stay.
 */
When('I navigate back from fixed penalty details choosing {string}', (choice: 'Ok' | 'Cancel') => {
  const accept = choice.toLowerCase() === 'ok';
  log('navigate', 'Back link from fixed penalty details', { choice });
  common().confirmNextUnsavedChanges(accept);
  details().clickBackLink();
});

/**
 * @step Stubs fixed penalty draft account listings API.
 * @description Intercepts GET /draft-accounts and serves fixture data filtered by status query.
 */
Given('I stub fixed penalty draft account listings', () => {
  log('intercept', 'Stubbing fixed penalty draft listings');
  intercepts().stubFixedPenaltyListings();
});

/**
 * @step Asserts the account type column shows Fixed Penalty.
 * @description Checks the draft listings table for the Fixed Penalty account type text.
 */
Then('I see fixed penalty in the account type column', () => {
  log('assert', 'Checking account type column for Fixed Penalty');
  tabs().assertAccountType('Fixed Penalty');
});
