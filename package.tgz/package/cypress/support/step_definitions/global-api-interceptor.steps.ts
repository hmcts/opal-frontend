/**
 * @file global-api-interceptor.steps.ts
 * @description Step definitions for global API interceptor scenarios.
 */
import { When, Then, DataTable } from '@badeball/cypress-cucumber-preprocessor';
import { GlobalApiInterceptorFlow } from '../../e2e/functional/opal/flows/global-api-interceptor.flow';
import { GlobalApiInterceptorActions } from '../../e2e/functional/opal/actions/global-api-interceptor.actions';
import { log } from '../utils/log.helper';

const flow = () => new GlobalApiInterceptorFlow();
const actions = () => new GlobalApiInterceptorActions();

When(
  /^I attempt to open Manual Account Creation and the business units request fails with (\d+|<errorCode>)$/,
  (statusCode: string) => {
    if (statusCode === '<errorCode>') {
      throw new Error('Scenario Outline placeholder <errorCode> was not substituted before execution.');
    }

    const parsedStatusCode = Number(statusCode);
    log('step', 'Attempting Manual Account Creation with business units error', {
      statusCode: parsedStatusCode,
    });
    flow().openManualAccountCreationWithBusinessUnitsError(parsedStatusCode);
  },
);

When(
  'I attempt to open Manual Account Creation and the business units request fails with a retriable {int} error',
  (statusCode: number) => {
    log('step', 'Attempting Manual Account Creation with retriable business units error', { statusCode });
    flow().openManualAccountCreationWithRetriableBusinessUnitsError(statusCode);
  },
);

When('I attempt to open Manual Account Creation and the business units request fails due to a network error', () => {
  log('step', 'Attempting Manual Account Creation with business units network error');
  flow().openManualAccountCreationWithBusinessUnitsNetworkFailure();
});

When('I click the Cancel button and the Cancel confirmation popup is displayed with:', (table: DataTable) => {
  log('step', 'Clicking Cancel and asserting Cancel confirmation popup', { rows: table.raw() });
  actions().clickCancelAndAssertConfirmationPopupFromTable(table);
});

When(
  'I attempt to open Manual Account Creation and the business units request fails with a non-retriable {int} error',
  (statusCode: number) => {
    log('step', 'Attempting Manual Account Creation with non-retriable business units error', { statusCode });
    flow().openManualAccountCreationWithNonRetriableBusinessUnitsError(statusCode);
  },
);

When(
  'I attempt a Companies account search for reference {string} with a retriable {int} error',
  (reference: string, statusCode: number) => {
    log('step', 'Attempting Companies search with retriable error', { reference, statusCode });
    flow().searchCompaniesWithRetriableError(reference, statusCode);
  },
);

When(
  'I attempt a Companies account search for reference {string} with a non-retriable {int} error',
  (reference: string, statusCode: number) => {
    log('step', 'Attempting Companies search with non-retriable error', { reference, statusCode });
    flow().searchCompaniesWithNonRetriableError(reference, statusCode);
  },
);

When('I open the Fixed penalty section and the fixed penalty details request receives no response', () => {
  log('step', 'Opening Fixed penalty section with no response from the details request');
  flow().openFixedPenaltyDetailsWithNetworkFailure();
});

When(
  'I save the defendant details and the Replace Defendant Account Party request fails with a non-retriable {int} error',
  (statusCode: number) => {
    log('step', 'Saving defendant details with defendant account party concurrency error', { statusCode });
    flow().saveDefendantDetailsWithPartyConcurrencyError(statusCode);
  },
);

When(
  'I save account note {string} and the Add Note request fails with a non-retriable {int} error',
  (noteText: string, statusCode: number) => {
    log('step', 'Saving account note with non-retriable Add Note error', { statusCode });
    flow().saveAccountNoteWithNonRetriablePermissionError(noteText, statusCode);
  },
);

Then('the global error banner is displayed', () => {
  log('assert', 'Asserting global error banner is visible');
  actions().assertGlobalErrorBanner();
});

Then('the global warning banner is displayed with:', (table: DataTable) => {
  log('assert', 'Asserting global warning banner', { rows: table.raw() });
  actions().assertGlobalWarningBannerFromTable(table);
});

Then('the global banner clears after refresh on the {string} page', (expectedHeader: string) => {
  log('assert', 'Refreshing and confirming global banner cleared', { expectedHeader });
  flow().refreshAndAssertBannerCleared(expectedHeader);
});

Then('the error page shows:', (table: DataTable) => {
  log('assert', 'Asserting error page content', { rows: table.raw() });
  actions().assertErrorPageContent(table);
});
