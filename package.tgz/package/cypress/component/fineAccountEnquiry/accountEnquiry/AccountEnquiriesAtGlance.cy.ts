import { ACCOUNT_ENQUIRY_HEADER_ELEMENTS as DOM } from '../../../shared/selectors/account-enquiry/account.enquiry.header.locators';
import { createDefendantHeaderMockWithName, DEFENDANT_HEADER_MOCK } from './mocks/defendant_details_mock';

import {
  USER_STATE_MOCK_PERMISSION_BU17,
  USER_STATE_MOCK_PERMISSION_BU77,
} from '../../CommonIntercepts/CommonUserState.mocks';

import {
  OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK,
  OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK,
} from './mocks/defendant_details_at_glance_mock';
import { mount } from 'cypress/angular';
import { interceptAtAGlance, interceptDefendantHeader } from './intercept/defendantAccountIntercepts';
import { interceptAuthenticatedUser, interceptUserState } from 'cypress/component/CommonIntercepts/CommonIntercepts';
import { IComponentProperties } from './setup/setupComponent.interface';
import { setupAccountEnquiryComponent } from './setup/SetupComponent';
import { FinesAccDefendantDetailsAtAGlanceTabComponent } from 'src/app/flows/fines/fines-acc/fines-acc-defendant-details/fines-acc-defendant-details-at-a-glance-tab/fines-acc-defendant-details-at-a-glance-tab.component';

const ACCOUNT_ENQUIRY_JIRA_LABEL = '@JIRA-LABEL:account-enquiry';
type AtAGlanceMock = typeof OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK;

const buildTags = (...tags: string[]): string[] => [...tags, ACCOUNT_ENQUIRY_JIRA_LABEL];

describe('Defendant Account Summary - At a Glance Tab', () => {
  const mountAtAGlanceTab = ({
    tabData,
    hasAccountMaintenencePermission = false,
  }: {
    tabData: AtAGlanceMock;
    hasAccountMaintenencePermission?: boolean;
  }) => {
    mount(FinesAccDefendantDetailsAtAGlanceTabComponent, {
      componentProperties: {
        tabData,
        hasAccountMaintenencePermission,
      },
    });
  };

  beforeEach(() => {
    interceptAuthenticatedUser();
  });
  const componentProperties: IComponentProperties = {
    accountId: '77',
    fragments: 'at-a-glance',
    interceptedRoutes: [
      '/access-denied',
      '../note/add',
      '../debtor/individual/amend',
      '../debtor/parentGuardian/amend',
      // Add more routes here as needed
    ],
  };
  it(
    'AC1,Ac1a, Ac1b: The At a Glance tab is built as per the design artefact for company',
    { tags: [...buildTags('@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4011'] },
    () => {
      const header = structuredClone(DEFENDANT_HEADER_MOCK);
      header.party_details.organisation_flag = true;
      header.party_details.organisation_details = {
        organisation_name: 'Test Org Ltd',
        organisation_aliases: [],
      };
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, header, '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get(DOM.pageHeader).should('exist');
      cy.get(DOM.headingWithCaption).should('exist');
      cy.get(DOM.headingName).should('exist').and('contain.text', 'Test Org Ltd');
      cy.get(DOM.accountInfo).should('exist');
      cy.get(DOM.summaryMetricBar).should('exist');
      cy.get(DOM.subnav).should('exist');
      cy.get(DOM.atAGlanceTabComponent).should('exist');
      cy.contains(DOM.labelDefendant).should('be.visible');
      cy.contains(DOM.labelPaymentTerms).should('be.visible');
      cy.contains(DOM.labelEnforcementStatus).should('be.visible');
      cy.get('h3').contains('Company Name').next('p').should('be.visible').and('contain.text', ' Tech Solutions Ltd ');
      cy.get('h3')
        .contains('Address')
        .next('p')
        .should('be.visible')
        .should('contain.text', ' 123 Main Street  Apt 4  AB12 3CD ');
    },
  );

  it(
    'AC1,Ac1a, Ac1b: The At a Glance tab is built as per the design artefact for defendant',
    { tags: [...buildTags('@JIRA-STORY:PO-984'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4012'] },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get(DOM.pageHeader).should('exist');
      cy.get(DOM.headingWithCaption).should('exist');
      cy.get(DOM.headingName).should('exist').and('contain.text', 'Mr Robert THOMSON');
      cy.get(DOM.accountInfo).should('exist');
      cy.get(DOM.summaryMetricBar).should('exist');
      cy.get(DOM.subnav).should('exist');
      cy.get(DOM.atAGlanceTabComponent).should('exist');
      cy.contains(DOM.labelDefendant).should('be.visible');
      cy.contains(DOM.labelPaymentTerms).should('be.visible');
      cy.contains(DOM.labelEnforcementStatus).should('be.visible');
      cy.get('h3')
        .contains('Date of birth')
        .next('p')
        .should('be.visible')
        .should('contain.text', ' 03 February 1980 ');
      cy.get('h3')
        .contains('Address')
        .next('p')
        .should('be.visible')
        .should('contain.text', ' 123 Main Street  Apt 4  AB12 3CD ');
    },
  );

  it(
    'AC2a: Displays Language Preferences section below National Insurance Number',
    { tags: [...buildTags('@JIRA-STORY:PO-984'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4013'] },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('National Insurance Number').next('p').should('be.visible').as('niH3');
      cy.get('@niH3')
        .siblings('h2')
        .contains(/language preference(s)?/i)
        .should('be.visible');
    },
  );

  it(
    'AC2ai: Displays Language Preferences as read-only fields',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4014'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.contains('h2', /language preference(s)?/i)
        .should('be.visible')
        .parent()
        .within(() => {
          // Verify all language preference fields are read-only (no input elements)
          cy.get('input').should('not.exist');
          cy.get('select').should('not.exist');
          cy.get('textarea').should('not.exist');
        });
    },
  );

  it(
    'AC2b: displays Document language and Court hearing language values in Language Preferences section',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4015'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.contains('h2', /language preference(s)?/i)
        .should('be.visible')
        .parent()
        .within(() => {
          // Verify Document language field and value are displayed
          cy.contains(/document language/i).should('be.visible');
          cy.contains('p', 'Welsh and English').should('be.visible');

          //Verify Court hearing language field and value are displayed
          cy.contains(/court hearing language/i).should('be.visible');
          cy.contains('p', 'Welsh and English').should('be.visible');
        });
    },
  );
  it(
    'AC2bi: Label Welsh and Language is displayed in blue',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4016'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get(DOM.enforcementStatusTag)
        .should('be.visible')
        .and('contain.text', 'Welsh and English')
        .and('have.class', 'govuk-tag');
    },
  );

  it(
    'AC2bia: Label Welsh and Language is not displayed',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4017'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get(DOM.enforcementStatusTag).should('not.exist');
    },
  );

  it(
    'AC2c: Labels not displayed',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4018'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.contains('h2', /language preference(s)?/i).should('not.exist');
      cy.contains(/document language/i).should('not.exist');
      cy.contains('p', 'Welsh and English').should('not.exist');

      cy.contains(/court hearing language/i).should('not.exist');
      cy.contains('p', 'Welsh and English').should('not.exist');
    },
  );

  it(
    'AC3: displays Aliases section when defendant has one or more aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-984'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4019'] },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3')
        .contains('Aliases')
        .next('p')
        .should('exist')
        .invoke('text')
        .then((text) => {
          const aliases = text.replace(/\s+/g, ' ').trim();

          expect(aliases).to.contain('Ewan SMITH');
          expect(aliases).to.contain('Megan WILLIAMS');
          expect(aliases.indexOf('Ewan SMITH')).to.be.lessThan(aliases.indexOf('Megan WILLIAMS')); // order check
        });
    },
  );
  it(
    'AC3b: does not display Aliases section when defendant has no aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-984'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4020'] },
    () => {
      const headerNoAliases = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      headerNoAliases.party_details.individual_details!.individual_aliases = [];

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, headerNoAliases, '1');

      setupAccountEnquiryComponent(componentProperties);
      cy.get('h3').contains('Aliases').next('p').should('not.have.text');
    },
  );

  it(
    'AC3: displays Aliases section when company has one or more aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4021'] },
    () => {
      const header = structuredClone(DEFENDANT_HEADER_MOCK);
      header.party_details.organisation_flag = true;
      header.party_details.organisation_details = {
        organisation_name: 'Test Org Ltd',
        organisation_aliases: [],
      };
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, header, '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get(DOM.pageHeader).should('exist');

      cy.get('h3')
        .contains('Aliases')
        .next('p')
        .should('exist')
        .invoke('text')
        .then((text) => {
          const aliases = text.replace(/\s+/g, ' ').trim();

          expect(aliases).to.contain('Meridian Construction Ltd');
          expect(aliases).to.contain('Meridian Solutions Ltd');
          expect(aliases.indexOf('Meridian Construction Ltd')).to.be.lessThan(
            aliases.indexOf('Meridian Solutions Ltd'),
          ); // order check
        });
    },
  );

  it(
    'AC3b: does not display Aliases section when company has no aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4022'] },
    () => {
      const header = structuredClone(DEFENDANT_HEADER_MOCK);
      header.party_details.organisation_flag = true;
      header.party_details.organisation_details = {
        organisation_name: 'Test Org Ltd',
        organisation_aliases: [],
      };
      const atAGlanceNoAliases = structuredClone(OPAL_FINES_ACCOUNT_ORG_AT_A_GLANCE_MOCK);
      atAGlanceNoAliases.party_details.organisation_details!.organisation_aliases = [];

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, header, '1');
      interceptAtAGlance(77, atAGlanceNoAliases, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('Aliases').next('p').should('not.have.text');
    },
  );

  it(
    'AC4,AC4a: displays Comments section with no Account Comment or Free Text Notes',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4023'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: null,
        free_text_note_1: null,
        free_text_note_2: null,
        free_text_note_3: null,
      };

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('Comment').should('not.exist');
      cy.get('h3').contains('Free text notes').should('not.exist');
      cy.get(DOM.linkText).should('exist').should('have.text', 'Add comments');
    },
  );

  it(
    'AC4b, Ac9: displays Comments section with Account Comment but no Free Text Notes',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4024'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: 'Test account comment',
        free_text_note_1: null,
        free_text_note_2: null,
        free_text_note_3: null,
      };

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('Comment').and('be.visible').next('p').should('have.text', 'Test account comment');
      cy.get('h3').contains('Free text notes').and('be.visible').next('p').should('have.text', '—');
    },
  );

  it(
    'AC4c, Ac9: displays Comments section with Free Text Notes but no Account Comment',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4025'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: null,
        free_text_note_1: 'First note.',
        free_text_note_2: null,
        free_text_note_3: null,
      };

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('Comment').and('be.visible').next('p').should('have.text', '-');
      cy.get('h3').contains('Free text notes').and('be.visible').next('p').should('have.text', ' First note. ');
    },
  );

  it(
    'AC4d: displays Comments section with both Account Comment and Free Text Notes',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4026'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: 'Test account comment',
        free_text_note_1: 'First note.',
        free_text_note_2: null,
        free_text_note_3: null,
      };

      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);

      cy.get('h3').contains('Comment').and('be.visible').next('p').should('have.text', 'Test account comment');
      cy.get('h3').contains('Free text notes').and('be.visible').next('p').should('have.text', ' First note. ');
    },
  );

  it(
    'AC5: Shows Add comments link and navigates to Comments screen when user has Account Maintenance permission in associated  BU',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4027'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: null,
        free_text_note_1: null,
        free_text_note_2: null,
        free_text_note_3: null,
      };
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);
      // First verify the button exists and is visible
      cy.get(DOM.linkText).should('be.visible').and('contain.text', 'Add comments');

      // Click the link
      cy.get(DOM.linkText).click();

      cy.get('@routerNavigate')
        .its('lastCall.args.0')
        .should((arg0) => {
          const path = Array.isArray(arg0) ? arg0.join('/') : String(arg0);
          expect(path).to.match(/comments\/add/);
        });
    },
  );

  it(
    'AC5: Shows Change link and navigates to Comments screen when user has Account Maintenance permission in associated BU',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4028'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: 'Test account comment',
        free_text_note_1: 'first note',
        free_text_note_2: null,
        free_text_note_3: null,
      };
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);
      cy.get(DOM.linkText).should('be.visible').and('contain.text', 'Change');

      cy.get(DOM.linkText).click();

      cy.get('@routerNavigate')
        .its('lastCall.args.0')
        .should((arg0) => {
          const path = Array.isArray(arg0) ? arg0.join('/') : String(arg0);
          expect(path).to.match(/comments\/add/);
        });
    },
  );

  it(
    'AC5a: Add Comment link exists when user has permission in at least one BU but not the BU associated to the account',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4029'],
    },
    () => {
      const mockDataNoComments = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoComments.comments_and_notes = {
        account_comment: null,
        free_text_note_1: null,
        free_text_note_2: null,
        free_text_note_3: null,
      };
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU17);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, mockDataNoComments, '1');

      setupAccountEnquiryComponent(componentProperties);
      // First verify the button exists and is visible
      cy.get(DOM.linkText).should('be.visible').and('contain.text', 'Add comments');

      // Click the link
      cy.get(DOM.linkText).click();

      cy.get('@routerNavigate')
        .its('lastCall.args.0')
        .should((arg0) => {
          const path = Array.isArray(arg0) ? arg0.join('/') : String(arg0);
          expect(path).to.match(/access-denied/);
        });
    },
  );

  it(
    'AC5a: Change link exists when user has permission in at least one BU but not the BU associated to the account',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4030'],
    },
    () => {
      interceptUserState(USER_STATE_MOCK_PERMISSION_BU17);
      interceptDefendantHeader(77, createDefendantHeaderMockWithName('Robert', 'Thomson'), '1');
      interceptAtAGlance(77, OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK, '1');

      setupAccountEnquiryComponent(componentProperties);
      cy.get(DOM.linkText).should('be.visible').and('contain.text', 'Change');
      cy.get(DOM.linkText).click();

      cy.get('@routerNavigate')
        .its('lastCall.args.0')
        .should((arg0) => {
          const path = Array.isArray(arg0) ? arg0.join('/') : String(arg0);
          expect(path).to.match(/access-denied/);
        });
    },
  );

  it(
    'AC5b: Change link and add comment do not exist when user has no permission in any BU',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4031'],
    },
    () => {
      mountAtAGlanceTab({ tabData: structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK) });

      cy.get(DOM.linkText).should('not.exist');
    },
  );

  it(
    'AC6a: displays Payment Terms section for "Pay by date" scenario',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4032'],
    },
    () => {
      const mockDataPayByDate = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataPayByDate.payment_terms = {
        payment_terms_type: {
          payment_terms_type_code: 'B',
          payment_terms_type_display_name: 'By date',
        },
        effective_date: '31/12/2024',
        instalment_period: null,
        lump_sum_amount: null,
        instalment_amount: null,
      };

      mountAtAGlanceTab({ tabData: mockDataPayByDate });
      cy.get('h2').contains('Payment terms').should('exist');
      cy.get('h3').contains('Payment terms').and('be.visible').next('p').should('have.text', 'Pay in full');
      cy.get('h3').contains('Pay by date').and('be.visible').next('p').should('have.text', ' 31 December 2024 ');

      // Verify that instalment-specific fields are not displayed
      cy.get('h3').contains('Frequency').should('not.exist');
      cy.get('h3').contains('Instalments').should('not.exist');
      cy.get('h3').contains('Start Date').should('not.exist');
    },
  );

  it(
    'AC6b: displays Payment Terms section for "Lump sum plus instalments" scenario',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4033'],
    },
    () => {
      mountAtAGlanceTab({ tabData: structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK) });

      cy.get('h3')
        .contains('Payment terms')
        .and('be.visible')
        .next('p')
        .should('have.text', 'Lump sum plus instalments');
      cy.get('h3').contains('Frequency').and('be.visible').next('p').should('have.text', 'Monthly');
      cy.get('h3').contains('Instalments').and('be.visible').next('p').should('have.text', ' £100.00 ');
      cy.get('h3').contains('Start date').and('be.visible').next('p').should('have.text', ' 01 January 2024 ');

      // Verify that "By date" field is not displayed
      cy.get('h3').contains('By date').should('not.exist');
    },
  );

  it(
    'AC6c: displays Payment Terms section for "Instalments only" scenario',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4034'],
    },
    () => {
      const mockDataPayByDate = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataPayByDate.payment_terms = {
        payment_terms_type: {
          payment_terms_type_code: 'I',
          payment_terms_type_display_name: 'By date',
        },
        effective_date: '31/12/2024',
        instalment_period: {
          instalment_period_code: 'M',
          instalment_period_display_name: 'Monthly',
        },
        lump_sum_amount: 1000,
        instalment_amount: 100,
      };

      mountAtAGlanceTab({ tabData: mockDataPayByDate });
      cy.get('h2').contains('Payment terms').should('exist');
      cy.get('h3').contains('Frequency').and('be.visible').next('p').should('have.text', 'Monthly');
      cy.get('h3').contains('Instalments').and('be.visible').next('p').should('have.text', ' £100.00 ');
      cy.get('h3').contains('Start date').and('be.visible').next('p').should('have.text', ' 31 December 2024 ');
    },
  );

  it(
    'AC7a, AC7b, AC7c, AC7d: displays Last Enforcement Action field only when value is present',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4035'],
    },
    () => {
      const mockDataNoEnforcementAction = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataNoEnforcementAction.enforcement_status = {
        last_enforcement_action: {
          last_enforcement_action_id: 'EA-001',
          last_enforcement_action_title: 'Warrant Issued',
        },
        collection_order_made: true,
        default_days_in_jail: 45,
        enforcement_override: {
          enforcement_override_result: {
            enforcement_override_result_id: 'EOR-001',
            enforcement_override_result_title: 'Override Approved',
          },
          enforcer: {
            enforcer_id: 10,
            enforcer_name: 'Court Officer',
          },
          lja: {
            lja_id: 20,
            lja_name: 'Central LJA',
          },
        },
        last_movement_date: '01/05/2024',
      };
      mountAtAGlanceTab({ tabData: mockDataNoEnforcementAction });
      cy.get('h3').contains('Days in default').and('be.visible').next('p').should('have.text', ' 45 days ');
      cy.get('h3')
        .contains('Enforcement override')
        .and('be.visible')
        .next('p')
        .should('have.text', ' Override Approved EOR-001 ');
      cy.get('h3').contains('Date of last movement').and('be.visible').next('p').should('have.text', ' 01 May 2024 ');
    },
  );
  it(
    'AC8a: displays blue "collection order" label when defendant is adult and CO flag is true',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4036'],
    },
    () => {
      const mockDataAdultWithCO = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataAdultWithCO.is_youth = false;
      mockDataAdultWithCO.enforcement_status.collection_order_made = true;
      mockDataAdultWithCO.enforcement_status.default_days_in_jail = 30;

      mountAtAGlanceTab({ tabData: mockDataAdultWithCO });

      cy.get(DOM.badgeBlue).contains('Collection Order').should('be.visible').and('have.class', 'moj-badge--blue');
    },
  );
  it(
    'AC8b: displays red "no collection order" label when defendant is adult and CO flag is false',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4037'],
    },
    () => {
      const mockDataAdultNoCO = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataAdultNoCO.is_youth = false;
      mockDataAdultNoCO.enforcement_status.collection_order_made = false;
      mockDataAdultNoCO.enforcement_status.default_days_in_jail = 30;

      mountAtAGlanceTab({ tabData: mockDataAdultNoCO });

      cy.get(DOM.badgeRed).contains('No collection Order').should('be.visible').and('have.class', 'moj-badge--red');
    },
  );

  it(
    'AC8c: displays red "no collection order" label when defendant is youth and CO flag is true',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4038'],
    },
    () => {
      const mockDataYouthWithCO = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataYouthWithCO.is_youth = true;
      mockDataYouthWithCO.enforcement_status.collection_order_made = true;

      mountAtAGlanceTab({ tabData: mockDataYouthWithCO });

      cy.get(DOM.badgeRed).contains('No collection Order').should('be.visible').and('have.class', 'moj-badge--red');
    },
  );

  it(
    'AC8d: displays no collection order label when defendant is youth and CO flag is false',
    {
      tags: [...buildTags('@JIRA-STORY:PO-984', '@JIRA-STORY:PO-814'), '@JIRA-EPIC:PO-812', '@JIRA-TEST-KEY:PO-4039'],
    },
    () => {
      const mockDataYouthNoCO = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_AT_A_GLANCE_MOCK);
      mockDataYouthNoCO.is_youth = true;
      mockDataYouthNoCO.enforcement_status.collection_order_made = false;

      mountAtAGlanceTab({ tabData: mockDataYouthNoCO });

      cy.get('opal-lib-govuk-tag')
        .contains(/collection order/i)
        .should('not.exist');
      cy.get('h2').contains('Enforcement status').should('be.visible');
    },
  );
});
