import { DOM_ELEMENTS as ENF_OVR } from '../../../shared/selectors/account-enquiry/account.enquiry.enforcement-override-add.locators';
import { ACCOUNT_ENQUIRY_ENFORCEMENT_STATUS_ELEMENTS as ENF } from '../../../shared/selectors/account-enquiry/account.enquiry.enforcement.locators';
import { DOM_ELEMENTS as VERSION_CONTROL } from '../../../shared/selectors/account-enquiry/account.enquiry.version-control.locators';
import { mount } from 'cypress/angular';
import { setupAccountEnquiryComponent } from '../accountEnquiry/setup/SetupComponent';
import { IComponentProperties } from '../accountEnquiry/setup/setupComponent.interface';
import {
  interceptAuthenticatedUser,
  interceptUserState,
  interceptResultByCode,
  interceptEnforcementOverrideResults,
  interceptLocalJusticeAreas,
  interceptEnforcers,
} from 'cypress/component/CommonIntercepts/CommonIntercepts';
import { USER_STATE_MOCK_PERMISSION_BU77 } from 'cypress/component/CommonIntercepts/CommonUserState.mocks';
import { OPAL_FINES_ENF_OVERRIDE_RESULT_REF_DATA_MOCK } from '../../CommonIntercepts/referenceData/results/EnforcementOverrideResultsIntercept.mocks';
import { OPAL_FINES_ENFORCER_REF_DATA_MOCK } from '../../CommonIntercepts/referenceData/enforcers/EnforcersIntercept.mocks';
import { OPAL_FINES_LOCAL_JUSTICE_AREA_REF_DATA_MOCK } from '../../CommonIntercepts/referenceData/localJusticeAreas/LocalJusticeAreasIntercept.mocks';
import {
  interceptDefendantHeader,
  interceptEnforcementStatus,
  interceptPatchDefendantAccount,
} from '../accountEnquiry/intercept/defendantAccountIntercepts';
import {
  createDefendantHeaderMockWithName,
  createParentGuardianHeaderMockWithName,
} from '../accountEnquiry/mocks/defendant_details_mock';
import { OPAL_FINES_ACCOUNT_DEFENDANT_DETAILS_ENFORCEMENT_TAB_REF_DATA_MOCK } from '@app/flows/fines/services/opal-fines-service/mocks/opal-fines-account-defendant-details-enforcement-tab-ref-data.mock';
import { ActivatedRoute, provideRouter } from '@angular/router';
import { UtilsService } from '@hmcts/opal-frontend-common/services/utils-service';
import { OpalFines } from '@app/flows/fines/services/opal-fines-service/opal-fines.service';
import { of } from 'rxjs';
import { FinesAccEnfOverrideAddChangeFormComponent } from 'src/app/flows/fines/fines-acc/fines-acc-enf-override-add-change/fines-acc-enf-override-add-change-form/fines-acc-enf-override-add-change-form.component';
import { FINES_ACC_ENF_OVERRIDE_ADD_CHANGE_FORM_DEFAULT } from 'src/app/flows/fines/fines-acc/fines-acc-enf-override-add-change/constants/fines-acc-enf-override-add-change-form-default.constant';
import { IFinesAccEnfOverrideAddChangeFormState } from 'src/app/flows/fines/fines-acc/fines-acc-enf-override-add-change/interfaces/fines-acc-enf-override-add-change-form-state.interface';

const componentProperties: IComponentProperties = {
  accountId: '77',
  fragments: 'enforcement',
  interceptedRoutes: [
    '/access-denied',
    '../note/add',
    '../debtor/individual/amend',
    '../debtor/parentGuardian/amend',
    '../enforcement/amend',
    '../enforcement/amend-denied',
    // Add more routes here as needed
  ],
};

const ENFORCEMENT_OVERRIDE_OPTIONS = OPAL_FINES_ENF_OVERRIDE_RESULT_REF_DATA_MOCK.refData.map((result) => ({
  value: result.result_id,
  name: result.result_id,
}));
const ENFORCER_OPTIONS = OPAL_FINES_ENFORCER_REF_DATA_MOCK.refData
  .filter((enforcer) => enforcer.name === 'The DWP')
  .map((enforcer) => ({
    value: `${enforcer.name} (${enforcer.enforcer_code})`,
    name: `${enforcer.name} (${enforcer.enforcer_code})`,
  }));
const LOCAL_JUSTICE_AREA_OPTIONS = OPAL_FINES_LOCAL_JUSTICE_AREA_REF_DATA_MOCK.refData.map((lja) => ({
  value: `${lja.name} (${lja.local_justice_area_id})`,
  name: `${lja.name} (${lja.local_justice_area_id})`,
}));

function mountAddEnforcementOverrideForm(
  expectedCaption: string,
  formValues: IFinesAccEnfOverrideAddChangeFormState = FINES_ACC_ENF_OVERRIDE_ADD_CHANGE_FORM_DEFAULT,
) {
  const [accountNumber, partyName] = expectedCaption.split(' - ');

  mount(FinesAccEnfOverrideAddChangeFormComponent, {
    providers: [
      provideRouter([]),
      UtilsService,
      {
        provide: ActivatedRoute,
        useValue: {
          snapshot: {
            params: {},
            data: {},
          },
        },
      },
      {
        provide: OpalFines,
        useValue: {
          getResult: (id: string) =>
            of({
              requires_enforcer: ['ABDC', 'BWTD', 'BWTU'].includes(id),
              requires_lja: id === 'TFOOUT',
            }),
        },
      },
    ],
    componentProperties: {
      enforcementActionOptions: ENFORCEMENT_OVERRIDE_OPTIONS,
      enforcerOptions: ENFORCER_OPTIONS,
      localJusticeAreaOptions: LOCAL_JUSTICE_AREA_OPTIONS,
      partyName,
      accountNumber,
      pageTitle: 'Add enforcement override',
      formValues,
    },
  });
}
function setupAddEnforcementOverride(
  headerMock = structuredClone(createDefendantHeaderMockWithName('Robert', 'Thomson')),
) {
  let enforcementMock = structuredClone(OPAL_FINES_ACCOUNT_DEFENDANT_DETAILS_ENFORCEMENT_TAB_REF_DATA_MOCK);
  enforcementMock.enforcement_override!.enforcement_override_result = {
    enforcement_override_result_id: null,
    enforcement_override_result_name: null,
  };

  const accountId = headerMock.defendant_account_party_id;
  interceptAuthenticatedUser();
  interceptUserState(USER_STATE_MOCK_PERMISSION_BU77);
  interceptDefendantHeader(accountId, headerMock, '123');
  interceptEnforcementStatus(accountId, enforcementMock, '123');

  interceptEnforcementOverrideResults();
  interceptLocalJusticeAreas();
  interceptEnforcers();

  ['ABDC', 'AEOC', 'BWTD', 'BWTU', 'CLAMPO', 'CWN', 'DW', 'MAN', 'NBWT', 'REGF', 'SUMA', 'TFOOUT'].forEach((code) =>
    interceptResultByCode(code),
  );
  interceptPatchDefendantAccount();
  cy.intercept('/opal-fines-service/results/').as('getResults');

  setupAccountEnquiryComponent({ ...componentProperties, accountId: accountId });
  cy.get(ENF.addEnforcementOverrideLink).click();

  return { accountId };
}

function commonSetup() {
  const headerMock = structuredClone(createDefendantHeaderMockWithName('Robert', 'Thomson'));
  headerMock.debtor_type = 'individual';

  return setupAddEnforcementOverride(headerMock);
}

function parentGuardianSetup() {
  const headerMock = structuredClone(createParentGuardianHeaderMockWithName('Roberto', 'Thomson'));
  headerMock.debtor_type = 'Parent/Guardian';

  return setupAddEnforcementOverride(headerMock);
}

describe(
  'Add Enforcement Override - Adult/Youth',
  { tags: ['@JIRA-STORY:PO-1850', '@JIRA-EPIC:PO-1675', '@JIRA-LABEL:account-enquiry'] },
  () => {
    it('AC1a, AC1b. Should render the form with title', { tags: ['@JIRA-TEST-KEY:PO-4413'] }, () => {
      mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

      cy.get(ENF_OVR.title).should('contain.text', '177A - Mr Robert THOMSON');
      cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
    });

    it(
      'AC1c, AC1d. Select an enforcement override dropdown, add override button and cancel link',
      { tags: ['@JIRA-TEST-KEY:PO-4414'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains('ABDC').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('AEOC').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CLAMPO').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CWN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('DW').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('FSN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('MAN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('NBWT').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('REGF').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('SUMA').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');

        cy.get(ENF_OVR.addOverrideButton).should('exist');
        cy.get(ENF_OVR.cancelLink).should('exist');
      },
    );

    it(
      'Should support forward keyboard navigation across the add enforcement override form',
      { tags: ['@JIRA-TEST-KEY:PO-4415'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('be.visible').focus();
        cy.get(ENF_OVR.enfOverrideDropdown).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.get(ENF_OVR.addOverrideButton).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.contains('a.govuk-link', /^Cancel$/i).should('have.focus');
      },
    );

    it('AC2. Enforcer dropdown for valid override', { tags: ['@JIRA-TEST-KEY:PO-4416'] }, () => {
      mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

      cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
      cy.get(ENF_OVR.enfOverrideDropdown).click().type('AB');
      cy.get(ENF_OVR.dropdownOptions).contains('ABDC').should('exist');
      cy.get(ENF_OVR.dropdownOptions).contains('AEOC').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('CLAMPO').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('CWN').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('DW').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('FSN').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('MAN').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('NBWT').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('REGF').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('SUMA').should('not.exist');
      cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('not.exist');

      cy.get(ENF_OVR.dropdownOptions).contains('ABDC').click();
      cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'ABDC');

      cy.get(ENF_OVR.enforcerDropdown).should('exist');
      cy.get(ENF_OVR.enforcerDropdown).click();
      cy.get(ENF_OVR.dropdownOptions).contains('The DWP (3)').should('exist');
    });

    it('AC3. LJA dropdown for valid override', { tags: ['@JIRA-TEST-KEY:PO-4417'] }, () => {
      mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

      cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
      cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
      cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');

      cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
      cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
      cy.get(ENF_OVR.localJusticeAreaDropdown).should('exist');
      cy.get(ENF_OVR.localJusticeAreaDropdown).click();
      cy.get(ENF_OVR.dropdownOptions).contains("Bedfordshire Magistrates' Court (4165)").should('exist');
    });

    it(
      'AC4a. Error when no enforcement override is selected (Add Enforcement Override - Adult/Youth)',
      { tags: ['@JIRA-TEST-KEY:PO-4418'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.addOverrideButton).click();
        cy.get(ENF_OVR.errorSummary)
          .should('exist')
          .contains('There is a problem')
          .next()
          .should('contain.text', 'Select an enforcement override');
      },
    );

    it('AC4b. Error when no enforcer is selected', { tags: ['@JIRA-TEST-KEY:PO-4419'] }, () => {
      mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

      cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
      cy.get(ENF_OVR.enfOverrideDropdown).click().type('BW');
      cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('exist');
      cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('exist');
      cy.get(ENF_OVR.dropdownOptions).contains('BWTD').click();
      cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'BWTD');
      cy.get(ENF_OVR.enforcerDropdown).should('exist');

      cy.get(ENF_OVR.addOverrideButton).click();
      cy.get(ENF_OVR.errorSummary)
        .should('exist')
        .contains('There is a problem')
        .next()
        .should('contain.text', 'Select an enforcer');
    });

    it('AC4c. Error when no LJA is selected', { tags: ['@JIRA-TEST-KEY:PO-4420'] }, () => {
      mountAddEnforcementOverrideForm('177A - Mr Robert THOMSON');

      cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
      cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
      cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');
      cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
      cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
      cy.get(ENF_OVR.localJusticeAreaDropdown).should('exist');

      cy.get(ENF_OVR.addOverrideButton).click();
      cy.get(ENF_OVR.errorSummary)
        .should('exist')
        .contains('There is a problem')
        .next()
        .should('contain.text', 'Select a Local Justice Area');
    });

    it(
      'AC5. Valid submission returns to Enforcement tab with success banner and new override panel',
      { tags: ['@JIRA-TEST-KEY:PO-4421'] },
      () => {
        const { accountId } = commonSetup();
        const updatedEnforcementMock = structuredClone(
          OPAL_FINES_ACCOUNT_DEFENDANT_DETAILS_ENFORCEMENT_TAB_REF_DATA_MOCK,
        );

        updatedEnforcementMock.enforcement_override!.enforcement_override_result = {
          enforcement_override_result_id: 'TFOOUT',
          enforcement_override_result_name: 'Transfer of Fine Order to a Court in England or Wales',
        };
        updatedEnforcementMock.enforcement_override!.enforcer = {
          enforcer_id: 0,
          enforcer_name: '',
        };
        updatedEnforcementMock.enforcement_override!.lja = {
          lja_id: 4165,
          lja_name: "Bedfordshire Magistrates' Court",
        };

        interceptEnforcementStatus(accountId, updatedEnforcementMock, '124');

        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');

        cy.get(ENF_OVR.localJusticeAreaDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains("Bedfordshire Magistrates' Court (4165)").click();
        cy.get(ENF_OVR.localJusticeAreaDropdown).should('contain.value', "Bedfordshire Magistrates' Court (4165)");

        cy.get(ENF_OVR.addOverrideButton).click();

        cy.wait('@patchDefendantAccount')
          .its('request.body.enforcement_override')
          .should('deep.equal', {
            enforcement_override_result: {
              enforcement_override_result_id: 'TFOOUT',
            },
            enforcer: null,
            lja: {
              lja_id: 4165,
            },
          });

        cy.wait('@getEnforcementStatus');

        cy.get(ENF.tabName).should('exist').and('contain.text', 'Enforcement');

        cy.get(VERSION_CONTROL.successBanner).should('exist');
        cy.get(VERSION_CONTROL.bannerText).should('contain', 'Enforcement override added');

        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement override');
        cy.get(ENF.enforcementOverride).should('exist').and('contain.text', 'Enforcement override');
        cy.get(ENF.enforcementOverrideValue).and(
          'contain.text',
          'Transfer of Fine Order to a Court in England or Wales (TFOOUT)',
        );
        cy.get(ENF.localJusticeArea).should('exist').and('contain.text', 'Local Justice Area (LJA)');
        cy.get(ENF.localJusticeAreaValue).should('exist').and('contain.text', "Bedfordshire Magistrates' Court(4165)");
      },
    );

    it(
      'AC6a. Cancel without changes returns away from the add override page without confirmation',
      { tags: ['@JIRA-TEST-KEY:PO-4422'] },
      () => {
        commonSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');

        cy.window().then((win) => {
          cy.stub(win, 'confirm').as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('not.have.been.called');
        cy.get(ENF.headingName).should('contain.text', '177A Mr Robert THOMSON');
        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement overview');
        cy.get(ENF_OVR.enfOverrideDropdown).should('not.exist');
      },
    );

    it(
      'AC6b. Cancel after selecting a value shows confirmation before navigating away (Add Enforcement Override - Adult/Youth)',
      { tags: ['@JIRA-TEST-KEY:PO-4423'] },
      () => {
        commonSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT').blur();

        cy.window().then((win) => {
          cy.stub(win, 'confirm')
            .callsFake((message: string) => {
              expect(message.replace(/\s+/g, ' ')).to.match(/unsaved changes/i);
              return true;
            })
            .as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('have.been.calledOnce');
        cy.get(ENF.headingName).should('contain.text', '177A Mr Robert THOMSON');
        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement overview');
        cy.get(ENF_OVR.enfOverrideDropdown).should('not.exist');
      },
    );

    it(
      'AC6c. Cancel after selecting a value and dismissing the confirmation keeps the user on the page',
      { tags: ['@JIRA-TEST-KEY:PO-4424'] },
      () => {
        commonSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT').blur();

        cy.window().then((win) => {
          cy.stub(win, 'confirm')
            .callsFake((message: string) => {
              expect(message.replace(/\s+/g, ' ')).to.match(/unsaved changes/i);
              return false;
            })
            .as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('have.been.calledOnce');
        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
      },
    );
  },
);

describe(
  'Add Enforcement Override - Company',
  { tags: ['@JIRA-STORY:PO-1867', '@JIRA-EPIC:PO-1675', '@JIRA-LABEL:account-enquiry'] },
  () => {
    it('AC1a, AC1b. Should render the form with company title', { tags: ['@JIRA-TEST-KEY:PO-4425'] }, () => {
      mountAddEnforcementOverrideForm('177A - Test Org Ltd');

      cy.get(ENF_OVR.title).should('contain.text', '177A - Test Org Ltd');
      cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
    });

    it(
      'Should support forward keyboard navigation across the company add enforcement override form',
      { tags: ['@JIRA-LABEL:accessibility', '@JIRA-TEST-KEY:PO-4426'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Test Org Ltd');

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('be.visible').focus();
        cy.get(ENF_OVR.enfOverrideDropdown).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.get(ENF_OVR.addOverrideButton).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.contains('a.govuk-link', /^Cancel$/i).should('have.focus');
      },
    );
  },
);

describe(
  'Add Enforcement Override - Parent/Guardian',
  { tags: ['@JIRA-STORY:PO-1866', '@JIRA-LABEL:account-enquiry'] },
  () => {
    it(
      'AC1a, AC1b. Should render the form with title (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4427'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.title).should('contain.text', '177A - Mr Roberto THOMSON');
        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
      },
    );

    it(
      'AC1c, AC1d. Select an enforcement override dropdown, add override button and cancel link (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4428'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains('ABDC').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('AEOC').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CLAMPO').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CWN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('DW').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('FSN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('MAN').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('NBWT').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('REGF').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('SUMA').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');

        cy.get(ENF_OVR.addOverrideButton).should('exist');
        cy.get(ENF_OVR.cancelLink).should('exist');
      },
    );

    it(
      'Should support forward keyboard navigation across the add enforcement override form (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4429'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('be.visible').focus();
        cy.get(ENF_OVR.enfOverrideDropdown).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.get(ENF_OVR.addOverrideButton).should('have.focus');

        cy.press(Cypress.Keyboard.Keys.TAB);
        cy.contains('a.govuk-link', /^Cancel$/i).should('have.focus');
      },
    );

    it(
      'AC2. Enforcer dropdown for valid override (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4430'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('AB');
        cy.get(ENF_OVR.dropdownOptions).contains('ABDC').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('AEOC').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CLAMPO').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('CWN').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('DW').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('FSN').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('MAN').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('NBWT').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('REGF').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('SUMA').should('not.exist');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('not.exist');

        cy.get(ENF_OVR.dropdownOptions).contains('ABDC').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'ABDC');

        cy.get(ENF_OVR.enforcerDropdown).should('exist');
        cy.get(ENF_OVR.enforcerDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains('The DWP (3)').should('exist');
      },
    );

    it(
      'AC3. LJA dropdown for valid override (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4431'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');

        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
        cy.get(ENF_OVR.localJusticeAreaDropdown).should('exist');
        cy.get(ENF_OVR.localJusticeAreaDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains("Bedfordshire Magistrates' Court (4165)").should('exist');
      },
    );

    it(
      'AC4a. Error when no enforcement override is selected (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4432'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.addOverrideButton).click();
        cy.get(ENF_OVR.errorSummary)
          .should('exist')
          .contains('There is a problem')
          .next()
          .should('contain.text', 'Select an enforcement override');
      },
    );

    it(
      'AC4b. Error when no enforcer is selected (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4433'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('BW');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTD').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTU').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('BWTD').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'BWTD');
        cy.get(ENF_OVR.enforcerDropdown).should('exist');

        cy.get(ENF_OVR.addOverrideButton).click();
        cy.get(ENF_OVR.errorSummary)
          .should('exist')
          .contains('There is a problem')
          .next()
          .should('contain.text', 'Select an enforcer');
      },
    );

    it(
      'AC4c. Error when no LJA is selected (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4434'] },
      () => {
        mountAddEnforcementOverrideForm('177A - Mr Roberto THOMSON');

        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').should('exist');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
        cy.get(ENF_OVR.localJusticeAreaDropdown).should('exist');

        cy.get(ENF_OVR.addOverrideButton).click();
        cy.get(ENF_OVR.errorSummary)
          .should('exist')
          .contains('There is a problem')
          .next()
          .should('contain.text', 'Select a Local Justice Area');
      },
    );

    it(
      'AC5. Valid submission returns to Enforcement tab with success banner and new override panel (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4435'] },
      () => {
        const { accountId } = parentGuardianSetup();
        const updatedEnforcementMock = structuredClone(
          OPAL_FINES_ACCOUNT_DEFENDANT_DETAILS_ENFORCEMENT_TAB_REF_DATA_MOCK,
        );

        updatedEnforcementMock.enforcement_override!.enforcement_override_result = {
          enforcement_override_result_id: 'TFOOUT',
          enforcement_override_result_name: 'Transfer of Fine Order to a Court in England or Wales',
        };
        updatedEnforcementMock.enforcement_override!.enforcer = {
          enforcer_id: 0,
          enforcer_name: '',
        };
        updatedEnforcementMock.enforcement_override!.lja = {
          lja_id: 4165,
          lja_name: "Bedfordshire Magistrates' Court",
        };

        interceptEnforcementStatus(accountId, updatedEnforcementMock, '124');

        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');

        cy.get(ENF_OVR.localJusticeAreaDropdown).click();
        cy.get(ENF_OVR.dropdownOptions).contains("Bedfordshire Magistrates' Court (4165)").click();
        cy.get(ENF_OVR.localJusticeAreaDropdown).should('contain.value', "Bedfordshire Magistrates' Court (4165)");

        cy.get(ENF_OVR.addOverrideButton).click();

        cy.wait('@patchDefendantAccount')
          .its('request.body.enforcement_override')
          .should('deep.equal', {
            enforcement_override_result: {
              enforcement_override_result_id: 'TFOOUT',
            },
            enforcer: null,
            lja: {
              lja_id: 4165,
            },
          });

        cy.wait('@getEnforcementStatus');

        cy.get(ENF.tabName).should('exist').and('contain.text', 'Enforcement');

        cy.get(VERSION_CONTROL.successBanner).should('exist');
        cy.get(VERSION_CONTROL.bannerText).should('contain', 'Enforcement override added');

        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement override');
        cy.get(ENF.enforcementOverride).should('exist').and('contain.text', 'Enforcement override');
        cy.get(ENF.enforcementOverrideValue).and(
          'contain.text',
          'Transfer of Fine Order to a Court in England or Wales (TFOOUT)',
        );
        cy.get(ENF.localJusticeArea).should('exist').and('contain.text', 'Local Justice Area (LJA)');
        cy.get(ENF.localJusticeAreaValue).should('exist').and('contain.text', "Bedfordshire Magistrates' Court(4165)");
      },
    );

    it(
      'AC6a. Cancel without changes returns away from the add override page without confirmation (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4436'] },
      () => {
        parentGuardianSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('exist');

        cy.window().then((win) => {
          cy.stub(win, 'confirm').as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('not.have.been.called');
        cy.get(ENF.headingName).should('contain.text', '177A Mr Roberto THOMSON');
        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement overview');
        cy.get(ENF_OVR.enfOverrideDropdown).should('not.exist');
      },
    );

    it(
      'AC6b. Cancel after selecting a value shows confirmation before navigating away (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4437'] },
      () => {
        parentGuardianSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT').blur();

        cy.window().then((win) => {
          cy.stub(win, 'confirm')
            .callsFake((message: string) => {
              expect(message.replace(/\s+/g, ' ')).to.match(/unsaved changes/i);
              return true;
            })
            .as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('have.been.calledOnce');
        cy.get(ENF.headingName).should('contain.text', '177A Mr Roberto THOMSON');
        cy.get(ENF.tableTitle).should('contain.text', 'Enforcement overview');
        cy.get(ENF_OVR.enfOverrideDropdown).should('not.exist');
      },
    );

    it(
      'AC6c. Cancel after selecting a value and dismissing the confirmation keeps the user on the page (Add Enforcement Override - Parent/Guardian)',
      { tags: ['@JIRA-EPIC:PO-1675', '@JIRA-TEST-KEY:PO-4438'] },
      () => {
        parentGuardianSetup();

        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).click().type('TFO');
        cy.get(ENF_OVR.dropdownOptions).contains('TFOOUT').click();
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT').blur();

        cy.window().then((win) => {
          cy.stub(win, 'confirm')
            .callsFake((message: string) => {
              expect(message.replace(/\s+/g, ' ')).to.match(/unsaved changes/i);
              return false;
            })
            .as('confirm');
        });

        cy.contains('a.govuk-link', /^Cancel$/i).click();

        cy.get('@confirm').should('have.been.calledOnce');
        cy.get(ENF_OVR.title).should('contain.text', 'Add enforcement override');
        cy.get(ENF_OVR.enfOverrideDropdown).should('contain.value', 'TFOOUT');
      },
    );
  },
);
