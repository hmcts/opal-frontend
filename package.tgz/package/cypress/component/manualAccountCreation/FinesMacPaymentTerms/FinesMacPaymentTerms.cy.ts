import { mount } from 'cypress/angular';
import { FinesMacPaymentTermsComponent } from '../../../../src/app/flows/fines/fines-mac/fines-mac-payment-terms/fines-mac-payment-terms.component';
import { ActivatedRoute } from '@angular/router';
import { FINES_PAYMENT_TERMS_MOCK } from './mocks/fines-payment-terms-mock';
import {
  ERROR_MESSAGES,
  LUMPSUM_ERRORS,
  INSTALMENT_ERRORS,
  ENFORCEMENT_ERRORS,
} from './constants/fines_mac_payment_terms_errors';
import { MacPaymentTermsLocators as DOM_ELEMENTS } from '../../../shared/selectors/manual-account-creation/mac.payment-terms.locators';
import { FinesMacStore } from 'src/app/flows/fines/fines-mac/stores/fines-mac.store';
import { OpalFines } from '../../../../src/app/flows/fines/services/opal-fines-service/opal-fines.service';
import { PermissionsService } from '@hmcts/opal-frontend-common/services/permissions-service';
import { PAYMENT_TERMS_SESSION_USER_STATE_MOCK } from './mocks/fines-payment-terms-session-user-mock';
import { GlobalStore } from '@hmcts/opal-frontend-common/stores/global';
import { of } from 'rxjs';

const MANUAL_ACCOUNT_CREATION_JIRA_LABEL = '@JIRA-LABEL:manual-account-creation';

const buildTags = (...tags: string[]) => [...tags, MANUAL_ACCOUNT_CREATION_JIRA_LABEL];

describe('FinesMacPaymentTermsComponent', () => {
  const date = new Date();
  const defendantTypes = ['adultOrYouthOnly', 'pgToPay', 'company'];
  type FinesMacPaymentTermsState = typeof FINES_PAYMENT_TERMS_MOCK;
  type ConfigureState = (state: FinesMacPaymentTermsState) => void;

  const createFinesMacState = (configureState?: ConfigureState): FinesMacPaymentTermsState => {
    const finesMacState = structuredClone(FINES_PAYMENT_TERMS_MOCK);
    configureState?.(finesMacState);
    return finesMacState;
  };

  const setBusinessUnitPermission = (state: FinesMacPaymentTermsState, businessUnitId: number = 17) => {
    state.accountDetails.formData.fm_create_account_business_unit_id = businessUnitId;
    state.businessUnit.business_unit_id = businessUnitId;
  };

  const setDateOfBirth = (state: FinesMacPaymentTermsState, dob: string) => {
    state.personalDetails.formData.fm_personal_details_dob = dob;
  };

  const setPayInFull = (state: FinesMacPaymentTermsState, payByDate: string) => {
    state.paymentTerms.formData.fm_payment_terms_payment_terms = 'payInFull';
    state.paymentTerms.formData.fm_payment_terms_pay_by_date = payByDate;
  };

  const setInstalmentsOnly = (state: FinesMacPaymentTermsState, instalmentAmount: number | null, startDate: string) => {
    state.paymentTerms.formData.fm_payment_terms_payment_terms = 'instalmentsOnly';
    state.paymentTerms.formData.fm_payment_terms_instalment_amount = instalmentAmount;
    state.paymentTerms.formData.fm_payment_terms_start_date = startDate;
  };

  const setLumpSumPlusInstalments = (
    state: FinesMacPaymentTermsState,
    lumpSumAmount: number | null,
    instalmentAmount: number | null,
    startDate: string,
  ) => {
    state.paymentTerms.formData.fm_payment_terms_payment_terms = 'lumpSumPlusInstalments';
    state.paymentTerms.formData.fm_payment_terms_lump_sum_amount = lumpSumAmount;
    state.paymentTerms.formData.fm_payment_terms_instalment_amount = instalmentAmount;
    state.paymentTerms.formData.fm_payment_terms_start_date = startDate;
  };

  const setCollectionOrderPreviouslyMade = (state: FinesMacPaymentTermsState, collectionOrderDate: string) => {
    state.paymentTerms.formData.fm_payment_terms_collection_order_made = true;
    state.paymentTerms.formData.fm_payment_terms_collection_order_date = collectionOrderDate;
  };

  const setCollectionOrderMadeToday = (state: FinesMacPaymentTermsState) => {
    state.paymentTerms.formData.fm_payment_terms_collection_order_made = false;
    state.paymentTerms.formData.fm_payment_terms_collection_order_made_today = true;
  };

  const setupComponent = (
    defendantTypeMock: string | undefined = '',
    mockSetAccountCommentsNote: any | undefined = null,
    configureState?: ConfigureState,
  ) => {
    const finesMacState = createFinesMacState(configureState);

    mount(FinesMacPaymentTermsComponent, {
      providers: [
        OpalFines,
        PermissionsService,
        GlobalStore,
        {
          provide: GlobalStore,
          useFactory: () => {
            const store = new GlobalStore();
            store.setUserState(PAYMENT_TERMS_SESSION_USER_STATE_MOCK);
            return store;
          },
        },
        {
          provide: FinesMacStore,
          useFactory: () => {
            const store = new FinesMacStore();
            store.setFinesMacStore(finesMacState);
            store.setAccountCommentsNotes = mockSetAccountCommentsNote;
            return store;
          },
        },
        {
          provide: ActivatedRoute,
          useValue: {
            parent: of('manual-account-creation'),
          },
        },
      ],
      componentProperties: {
        defendantType: defendantTypeMock,
      },
    });
  };

  it(
    '(AC.1) should render the component (FinesMacPaymentTermsComponent)',
    { tags: [...buildTags('@JIRA-STORY:PO-566'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5113'] },
    () => {
      setupComponent('adultOrYouthOnly');
      cy.get(DOM_ELEMENTS['finesMacPaymentTermsForm']).should('exist');
    },
  );
  //Dom-Elements check for each defendant type

  it(
    '(AC.1,AC.3,AC.4,)should load all elements on the screen correctly for adult or youth defendant types',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-566', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-471'),
        '@JIRA-EPIC:PO-272',
        '@JIRA-TEST-KEY:PO-5114',
      ],
    },
    () => {
      setupComponent('adultOrYouthOnly');

      cy.get(DOM_ELEMENTS.pageTitle).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('exist');
      cy.get(DOM_ELEMENTS.payInFullLabel).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyLabel).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalmentsLabel).should('exist');
      cy.get(DOM_ELEMENTS.addEnforcementActionLabel).should('exist');
      cy.get(DOM_ELEMENTS.payInFull).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).should('exist');
      cy.get(DOM_ELEMENTS.submitButton).should('exist');
      cy.get(DOM_ELEMENTS.addEnforcementAction).should('exist');
      // pay in full
      cy.get(DOM_ELEMENTS.payInFull).click();
      cy.get(DOM_ELEMENTS.payByDateLabel).should('contain', 'Enter pay by date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.payByDate).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerPayByDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      // instalments only
      cy.get(DOM_ELEMENTS.instalmentsOnly).click();
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      //lump plus instalments

      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).click();
      cy.get(DOM_ELEMENTS.lumpSumAmountLabel).should('contain', 'Lump sum');
      cy.get(DOM_ELEMENTS.lumpSumAmount).should('exist');
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      // enforcement action PRIS

      cy.get(DOM_ELEMENTS.addEnforcementAction).click();
      cy.get(DOM_ELEMENTS.prisLabel).should('exist');
      cy.get(DOM_ELEMENTS.pris).should('exist');
      cy.get(DOM_ELEMENTS.pris).click();
      cy.get(DOM_ELEMENTS.earliestReleaseDateLabel).should('contain', 'Earliest release date (EDR)');
      cy.get(DOM_ELEMENTS.earliestReleaseDate).should('exist');
      cy.get(DOM_ELEMENTS.prisonAndPrisonNumberLabel).should('contain', 'Prison and prison number');
      cy.get(DOM_ELEMENTS.prisonAndPrisonNumber).should('exist');
      cy.get(DOM_ELEMENTS.prisHint).should('contain', 'Held as enforcement comment');
      cy.get(DOM_ELEMENTS.characterCountHint).should('contain', 'You have 28 characters remaining');

      // enforcement action NOENF

      cy.get(DOM_ELEMENTS.noenfLabel).should('exist');
      cy.get(DOM_ELEMENTS.noenf).should('exist');
      cy.get(DOM_ELEMENTS.noenf).click();
      cy.get(DOM_ELEMENTS.reasonAccountIsOnNoenfLabel).should('contain', 'Reason account is on NOENF');
      cy.get(DOM_ELEMENTS.reasonAccountIsOnNoenf).should('exist');
      cy.get(DOM_ELEMENTS.characterCountHint).should('contain', 'You have 28 characters remaining');

      // collection order
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionNo).should('exist');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionYesLabel).should('contain', 'Yes');
      cy.get(DOM_ELEMENTS.collectionNoLabel).should('contain', 'No');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
      cy.get(DOM_ELEMENTS.collectionOrderDate).should('exist');
      cy.get(DOM_ELEMENTS.collectionOrderDateLabel).should('contain', 'Date of collection order');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
    },
  );

  it(
    'has legend text for enforcement action fieldset',
    { tags: [...buildTags('@JIRA-STORY:PO-2783'), '@JIRA-EPIC:PO-50', '@JIRA-TEST-KEY:PO-5115'] },
    () => {
      setupComponent('adultOrYouthOnly');
      cy.get(DOM_ELEMENTS.addEnforcementAction).click();

      cy.get(DOM_ELEMENTS.enforcementActionFieldset)
        .find(DOM_ELEMENTS.enforcementActionLegend)
        .should('contain.text', 'Select enforcement action')
        .and('have.class', 'govuk-visually-hidden')
        .and('have.class', 'govuk-fieldset__legend--s');

      //No aria-label applied to the individual radio buttons
      cy.get(DOM_ELEMENTS.enforcementActionFieldset)
        .find(DOM_ELEMENTS.enforcementActionRadios)
        .should('have.length.greaterThan', 0)
        .each(($radio) => {
          cy.wrap($radio).should('not.have.attr', 'aria-label');
        });
    },
  );

  it(
    '(AC.1,AC.3,AC.4)Should load all elements on the screen correctly for AYPG defendant types',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-566', '@JIRA-STORY:PO-587', '@JIRA-STORY:PO-649'),
        '@JIRA-EPIC:PO-344',
        '@JIRA-TEST-KEY:PO-5116',
      ],
    },
    () => {
      setupComponent('pgToPay');

      cy.get(DOM_ELEMENTS.pageTitle).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('exist');
      cy.get(DOM_ELEMENTS.payInFullLabel).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyLabel).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalmentsLabel).should('exist');
      cy.get(DOM_ELEMENTS.addEnforcementActionLabel).should('exist');
      cy.get(DOM_ELEMENTS.payInFull).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).should('exist');
      cy.get(DOM_ELEMENTS.submitButton).should('exist');
      cy.get(DOM_ELEMENTS.addEnforcementAction).should('exist');
      // pay in full
      cy.get(DOM_ELEMENTS.payInFull).click();
      cy.get(DOM_ELEMENTS.payByDateLabel).should('contain', 'Enter pay by date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.payByDate).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerPayByDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      // instalments only
      cy.get(DOM_ELEMENTS.instalmentsOnly).click();
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      //lump plus instalments

      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).click();
      cy.get(DOM_ELEMENTS.lumpSumAmountLabel).should('contain', 'Lump sum');
      cy.get(DOM_ELEMENTS.lumpSumAmount).should('exist');
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      // collection order
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionNo).should('exist');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionYesLabel).should('contain', 'Yes');
      cy.get(DOM_ELEMENTS.collectionNoLabel).should('contain', 'No');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
      cy.get(DOM_ELEMENTS.collectionOrderDate).should('exist');
      cy.get(DOM_ELEMENTS.collectionOrderDateLabel).should('contain', 'Date of collection order');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
    },
  );

  it(
    '(AC.1,AC.3,AC.4)Should load all elements for company defendant type',
    { tags: [...buildTags('@JIRA-STORY:PO-566', '@JIRA-STORY:PO-592'), '@JIRA-EPIC:PO-345', '@JIRA-TEST-KEY:PO-5117'] },
    () => {
      setupComponent('company');

      cy.get(DOM_ELEMENTS.pageTitle).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('exist');
      cy.get(DOM_ELEMENTS.payInFullLabel).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyLabel).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalmentsLabel).should('exist');
      cy.get(DOM_ELEMENTS.payInFull).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).should('exist');
      cy.get(DOM_ELEMENTS.submitButton).should('exist');

      // pay in full
      cy.get(DOM_ELEMENTS.payInFull).click();
      cy.get(DOM_ELEMENTS.payByDateLabel).should('contain', 'Enter pay by date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.payByDate).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerPayByDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      // instalments only
      cy.get(DOM_ELEMENTS.instalmentsOnly).click();
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.instalmentsOnlyFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');

      //lump plus instalments

      cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).click();
      cy.get(DOM_ELEMENTS.lumpSumAmountLabel).should('contain', 'Lump sum');
      cy.get(DOM_ELEMENTS.lumpSumAmount).should('exist');
      cy.get(DOM_ELEMENTS.instalmentAmountLabel).should('contain', 'Instalment');
      cy.get(DOM_ELEMENTS.instalmentAmount).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Frequency');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeeklyLabel).should('contain', 'Weekly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightlyLabel).should('contain', 'Fortnightly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthlyLabel).should('contain', 'Monthly');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyFortnightly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyMonthly).should('exist');
      cy.get(DOM_ELEMENTS.lumpSumFrequencyWeekly).should('exist');
      cy.get(DOM_ELEMENTS.startDate).should('exist');
      cy.get(DOM_ELEMENTS.startDateLabel).should('contain', 'Start date');
      cy.get(DOM_ELEMENTS.hint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).filter(':visible').first().click();
      cy.get(DOM_ELEMENTS.datePickerStartDateElement).should('exist');
      cy.get(DOM_ELEMENTS.datePickerSubmitButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerCancelButton).should('exist');
      cy.get(DOM_ELEMENTS.datePickerDialogHead).should('exist');
    },
  );
  //Collection order tests
  it(
    '(AC.1) should only load collection order for adult over 18 years old',
    { tags: [...buildTags('@JIRA-STORY:PO-471'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-5118'] },
    () => {
      setupComponent('adultOrYouthOnly', null, (state) => {
        setDateOfBirth(state, '01/01/2000');
      });

      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionNo).should('exist');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('exist');
      cy.get(DOM_ELEMENTS.collectionYesLabel).should('contain', 'Yes');
      cy.get(DOM_ELEMENTS.collectionNoLabel).should('contain', 'No');
    },
  );

  it(
    '(AC.3) Should load make a new collection order for correct permission for AYPG and AY',
    {
      tags: [...buildTags('@JIRA-STORY:PO-471', '@JIRA-STORY:PO-649'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5119'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            setBusinessUnitPermission(state);
          });
          cy.get(DOM_ELEMENTS.collectionNo).click();
          cy.get(DOM_ELEMENTS.makeCollection).should('exist');
          cy.get(DOM_ELEMENTS.makeCollectionLabel).should('contain', 'Make collection order today');
        });
      }
    },
  );

  it(
    '(AC.1) should not load collection order for adult or youth under 18 years old',
    { tags: [...buildTags('@JIRA-STORY:PO-471'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-5120'] },
    () => {
      setupComponent('adultOrYouthOnly', null, (state) => {
        setDateOfBirth(state, '01/01/2020');
      });

      cy.get(DOM_ELEMENTS.collectionNo).should('not.exist');
      cy.get(DOM_ELEMENTS.collectionOrder.yes).should('not.exist');
    },
  );
  //collection order validation check
  it(
    '(AC.1, AC.2)should prefill date of sentence in date of collection order field',
    { tags: [...buildTags('@JIRA-STORY:PO-853'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5121'] },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            setDateOfBirth(state, '01/01/2000');
          });
          cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
          cy.get(DOM_ELEMENTS.collectionOrderDate).should('have.value', '01/10/2022');
        });
      }
    },
  );

  it(
    '(AC.1)should have error handling with date of sentence and collection order date to ensure date cannot be before date of sentence',
    { tags: [...buildTags('@JIRA-STORY:PO-796'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5122'] },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);
          cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.collectionOrderDate).type('01/02/2004', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionDatePast);
        });
      }
    },
  );

  it(
    '(AC.4)should throw error if no collection order field is selected and user presses submit or return',
    {
      tags: [...buildTags('@JIRA-STORY:PO-471', '@JIRA-STORY:PO-649'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5123'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionError);
        });
      }
    },
  );

  it(
    '(AC.5)If a user selects yes to collection order and does not enter a date, an error should be thrown',
    {
      tags: [...buildTags('@JIRA-STORY:PO-471', '@JIRA-STORY:PO-649'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5124'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionDateError);
        });
      }
    },
  );

  it(
    '(AC.6)Should throw error for collection date validation',
    {
      tags: [...buildTags('@JIRA-STORY:PO-471', '@JIRA-STORY:PO-649'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5125'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.collectionOrder.yes).click();
          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.collectionOrderDate).type('32/01/2022', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validDate);

          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.collectionOrderDate).type('01.13.2022', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionDateFormat);

          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.collectionOrderDate).type('20/11/2060', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionDateFuture);

          cy.get(DOM_ELEMENTS.collectionOrderDate).clear();
          cy.get(DOM_ELEMENTS.collectionOrderDate).type('01/11/2001', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.collectionDatePast);
        });
      }
    },
  );

  //Checking pay by date, instalment option and lump sum flow checks and error handling
  it(
    '(AC.2a) should allow payByDate to be entered via date picker for all defendant types',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5126',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        setupComponent(defendantType);

        cy.get(DOM_ELEMENTS.payInFull).click();
        cy.get(DOM_ELEMENTS.payByDate).closest('.moj-datepicker').find(DOM_ELEMENTS.datePickerButton).click();
        cy.get(DOM_ELEMENTS.datePickerPayByDateElement).filter(':visible').last().should('be.visible');
        cy.get(DOM_ELEMENTS.datePickerPayByDateElement)
          .filter(':visible')
          .last()
          .find(DOM_ELEMENTS.testDate)
          .first()
          .click();
        cy.get(DOM_ELEMENTS.payByDate).should(
          'have.value',
          `${date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}`,
        );
      });
    },
  );

  it(
    '(AC.3c) should allow startDate to be entered via date picker for all defendant types',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5127',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        setupComponent(defendantType);

        cy.get(DOM_ELEMENTS.instalmentsOnly).click();
        cy.get(DOM_ELEMENTS.startDate).closest('.moj-datepicker').find(DOM_ELEMENTS.datePickerButton).click();
        cy.get(DOM_ELEMENTS.datePickerStartDateElement).filter(':visible').last().should('be.visible');
        cy.get(DOM_ELEMENTS.datePickerStartDateElement)
          .filter(':visible')
          .last()
          .find(DOM_ELEMENTS.testDate)
          .first()
          .click();
        cy.get(DOM_ELEMENTS.startDate).should(
          'have.value',
          `${date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}`,
        );
      });
    },
  );

  it(
    '(AC.16a) should load button for next page for adultOrYouthOnly Defendant',
    { tags: [...buildTags('@JIRA-STORY:PO-429'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-5128'] },
    () => {
      setupComponent('adultOrYouthOnly');

      cy.get(DOM_ELEMENTS.submitButton).should('contain', 'Add account comments and notes');
    },
  );

  it(
    '(AC.16a) should load button for next page for AYPG Defendant',
    { tags: [...buildTags('@JIRA-STORY:PO-429'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5129'] },
    () => {
      setupComponent('pgToPay');

      cy.get(DOM_ELEMENTS.submitButton).should('contain', 'Add account comments and notes');
    },
  );

  it(
    '(AC.17a) should load button for next page for Company Defendant',
    { tags: [...buildTags('@JIRA-STORY:PO-592'), '@JIRA-EPIC:PO-345', '@JIRA-TEST-KEY:PO-5130'] },
    () => {
      setupComponent('company');

      cy.get(DOM_ELEMENTS.submitButton).should('contain', 'Add account comments and notes');
    },
  );

  it(
    '(AC.3ci))should handle "Pay in full" with past dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5131',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setPayInFull(state, '01/01/2022');
          });

          cy.get(DOM_ELEMENTS.mojTicketPanel).should('contain', ERROR_MESSAGES.dateInPast);
        });
      });
    },
  );

  it(
    '(AC.3cii)should handle "Pay in full" with future dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592', '@JIRA-STORY:PO-2983'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5132',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setPayInFull(state, '01/01/2033');
          });

          cy.get(DOM_ELEMENTS.mojTicketPanel)
            .should('contain', ERROR_MESSAGES.dateInFuture)
            .and('contain', ERROR_MESSAGES.dateInFutureMessage);
        });
      });
    },
  );

  it(
    '(AC.4ci) should handle "Instalments only" with past dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5133',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setInstalmentsOnly(state, 1000, '01/01/2022');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.mojTicketPanel).should('contain', ERROR_MESSAGES.startDateInPast);
        });
      });
    },
  );

  it(
    '(AC.4cii) should handle "Instalments only" with future dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5134',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setInstalmentsOnly(state, 1000, '01/01/2030');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.mojTicketPanel).should('contain', ERROR_MESSAGES.startDateInFuture);
        });
      });
    },
  );

  it(
    '(AC.3Ci) should handle "Lump sum plus instalments" with past dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5135',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, 500, 1000, '01/01/2022');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.mojTicketPanel).should('contain', ERROR_MESSAGES.startDateInPast);
        });
      });
    },
  );

  it(
    '(AC.3Cii) should handle "Lump sum plus instalments" with future dates',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5136',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, 500, 1000, '01/01/2030');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.mojTicketPanel).should('contain', ERROR_MESSAGES.startDateInFuture);
        });
      });
    },
  );

  it(
    '(AC.7,AC.8)should handle empty data for Pay by date',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5137',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType);

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.paymentTerms);

          cy.get(DOM_ELEMENTS.payInFull).first().click();
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.payByDate);
          cy.get(DOM_ELEMENTS.payInFull).first().click();
        });
      });
    },
  );

  it(
    '(AC.5)should round lumpsum amount and instalment amount to .2 decimal place values',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5138',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType);

          cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).click();
          cy.get(DOM_ELEMENTS.lumpSumAmount).type('100.5', { delay: 0 });
          cy.get(DOM_ELEMENTS.instalmentAmount).filter(':visible').type('100.5', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).first().click();

          cy.get(DOM_ELEMENTS.lumpSumAmount).should('have.value', '100.50');
          cy.get(DOM_ELEMENTS.instalmentAmount).filter(':visible').should('have.value', '100.50');
        });
      });
    },
  );

  it(
    '(AC.11)should handle date Format error for pay in full',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5139',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setPayInFull(state, '01,01.2022');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validDateFormat);
        });
      });
    },
  );

  it(
    '(AC.11)should handle valid date Error for Pay in full',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5140',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setPayInFull(state, '32/01/2022');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validDate);
        });
      });
    },
  );

  it(
    '(AC.9)should handle errors for Instalment',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5141',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType);

          cy.get(DOM_ELEMENTS.instalmentsOnly).click({ multiple: true });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });

          for (const [, value] of Object.entries(INSTALMENT_ERRORS)) {
            cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', value);
          }
        });
      });
    },
  );

  it(
    '(AC.13)should handle valid instalmentAmount error for instalment',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5142',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setInstalmentsOnly(state, -1, '');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validInstalmentAmount);
        });
      });
    },
  );

  it(
    '(AC.12) should handle valid InstalmentDateFormat error for instalment',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5143',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setInstalmentsOnly(state, null, '01/21/12212');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validInstalmentDateFormat);
        });
      });
    },
  );

  it(
    '(AC.12) should handle valid date error for instalment',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5144',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setInstalmentsOnly(state, null, '32/09/2025');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validDate);
        });
      });
    },
  );

  it(
    '(AC.10)should handle errors for Lump sum plus Instalment',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5145',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType);

          cy.get(DOM_ELEMENTS.lumpSumPlusInstalments).click({ multiple: true });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });

          for (const [, value] of Object.entries(LUMPSUM_ERRORS)) {
            cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', value);
          }
        });
      });
    },
  );

  it(
    '(AC.14) should have validations in place for validLumpSumAmount',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5146',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, -1, null, '');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validLumpSumAmount);
        });
      });
    },
  );

  it(
    '(AC.14) should have validations in place for validLumpSumInstalmentAmount',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5147',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, null, -1, '');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validInstalmentAmount);
        });
      });
    },
  );

  it(
    '(AC.12) should have validations in place for validLumpSumStartDateFormat',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5148',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, null, null, '32/09/202555');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validInstalmentDateFormat);
        });
      });
    },
  );

  it(
    '(AC.12) should have validations in place for validLumpSumStartDate',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-587', '@JIRA-STORY:PO-429', '@JIRA-STORY:PO-592'),
        '@JIRA-EPIC:PO-545',
        '@JIRA-TEST-KEY:PO-5149',
      ],
    },
    () => {
      defendantTypes.forEach((defendantType) => {
        cy.then(() => {
          setupComponent(defendantType, null, (state) => {
            setLumpSumPlusInstalments(state, null, null, '32/09/2025');
          });

          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.validDate);
        });
      });
    },
  );

  //Days in default tests
  it(
    '(AC.1,AC.2,AC.3) should load days in default for adult or youth over 18 only',
    { tags: [...buildTags('@JIRA-STORY:PO-432'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-5150'] },
    () => {
      setupComponent('adultOrYouthOnly', null, (state) => {
        setDateOfBirth(state, '01/01/2000');
      });

      cy.get(DOM_ELEMENTS.hasDaysInDefault).should('exist');
      cy.get(DOM_ELEMENTS.hasDaysInDefault).click();
      cy.get(DOM_ELEMENTS.hasDaysInDefault).should('be.checked');
      cy.get(DOM_ELEMENTS.hasDaysInDefaultLabel).should('contain', 'There are days in default');
      cy.get(DOM_ELEMENTS.suspendedCommittalDate).should('exist');
      cy.get(DOM_ELEMENTS.defaultDaysInJail).should('exist');
      cy.get(DOM_ELEMENTS.datePickerButton).should('exist');
      cy.get(DOM_ELEMENTS.suspendedCommittalDateLabel).should('contain', 'Date days in default were imposed');
      cy.get(DOM_ELEMENTS.hint).should(
        'contain',
        'This should be whichever date is most recent - the sentencing date or the date of the suspended committal order.',
      );
      cy.get(DOM_ELEMENTS.defaultDaysInJailLabel).should('contain', 'Enter days in default');
    },
  );

  it(
    '(AC.1) should not load days in default for adult or youth under 18 years old',
    { tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-5151'] },
    () => {
      setupComponent('adultOrYouthOnly', null, (state) => {
        setDateOfBirth(state, '01/01/2010');
      });
      cy.get(DOM_ELEMENTS.hasDaysInDefault).should('not.exist');
    },
  );

  it(
    '(AC.4) Validation check to ensure only 5 integers can be inputted to the days in default field Adult or youth, AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5152'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            setDateOfBirth(state, '01/01/2000');
          });
          cy.get(DOM_ELEMENTS.hasDaysInDefault).click();
          cy.get(DOM_ELEMENTS.defaultDaysInJail).type('123456', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.daysInDefaultLength);
        });
      }
    },
  );

  it(
    '(AC.10a,AC.10c) should have validations in place for days in default enter valid data Adult or youth ,AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5153'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            state.paymentTerms.formData.fm_payment_terms_has_days_in_default = true;
            state.paymentTerms.formData.fm_payment_terms_suspended_committal_date = '32/09/2025';
          });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage)
            .should('contain', ERROR_MESSAGES.validDate)
            .should('contain', ERROR_MESSAGES.defaultDays);
        });
      }
    },
  );

  it(
    '(AC.10b) should have validations in place for days in default future date Adult or youth ,AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5154'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            state.paymentTerms.formData.fm_payment_terms_has_days_in_default = true;
            state.paymentTerms.formData.fm_payment_terms_suspended_committal_date = '20/09/2200';
          });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.futureDate);
        });
      }
    },
  );
  it(
    '(AC.5,AC.6)should have all elements in the calculate days in default panel for AYPG, Adult or Youth Only and calculate days accurately',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5155'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.hasDaysInDefault).click();
          cy.get(DOM_ELEMENTS.suspendedCommittalDate).type('01/01/2022', { delay: 0 });
          cy.get(DOM_ELEMENTS.defaultDaysInJail).type('10', { delay: 0 });
          cy.get(DOM_ELEMENTS.calculateLink).first().click();
          cy.get(DOM_ELEMENTS.panel).should('exist');
          cy.get(DOM_ELEMENTS.calculateHeading).should('contain', 'Calculate days in default');
          cy.get(DOM_ELEMENTS.days).should('exist');
          cy.get(DOM_ELEMENTS.weeks).should('exist');
          cy.get(DOM_ELEMENTS.months).should('exist');
          cy.get(DOM_ELEMENTS.years).should('exist');
          cy.get(DOM_ELEMENTS.daysLabel).should('contain', 'Days');
          cy.get(DOM_ELEMENTS.weeksLabel).should('contain', 'Weeks');
          cy.get(DOM_ELEMENTS.monthsLabel).should('contain', 'Months');
          cy.get(DOM_ELEMENTS.yearsLabel).should('contain', 'Years');

          cy.get(DOM_ELEMENTS.days).type('10', { delay: 0 });
          cy.get(DOM_ELEMENTS.weeks).type('1', { delay: 0 });
          cy.get(DOM_ELEMENTS.months).type('1', { delay: 0 });
          cy.get(DOM_ELEMENTS.years).type('1', { delay: 0 });

          cy.get(DOM_ELEMENTS.calculatedDays).should('contain', '413 days');
        });
      }
    },
  );

  it(
    '(AC.7) should not allow the user to calculate days until date has been filled out for days in default, AYPG, Adult or Youth Only',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5156'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.hasDaysInDefault).click();
          cy.get(DOM_ELEMENTS.calculateLink).first().click();
          cy.get(DOM_ELEMENTS.calculatedDays).should('contain', 'Cannot calculate total time in days');
          cy.get(DOM_ELEMENTS.calculatedDays).should('contain', 'You must enter a date days in default were imposed');

          setupComponent('pgToPay');
          cy.get(DOM_ELEMENTS.calculatedDays).should('contain', 'Cannot calculate total time in days');
          cy.get(DOM_ELEMENTS.calculatedDays).should('contain', 'You must enter a date days in default were imposed');
        });
      }
    },
  );

  it(
    '(AC.10d) should have validations in place for days in default invalid date date Adult or youth ,AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-432', '@JIRA-STORY:PO-588'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5157'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        setupComponent(defendantTypes[i], null, (state) => {
          state.paymentTerms.formData.fm_payment_terms_has_days_in_default = true;
          state.paymentTerms.formData.fm_payment_terms_default_days_in_jail = -1;
        });
        cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
        cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.defaultDaysTypeCheck);
      }
    },
  );
  //Enforcement action tests

  it(
    '(AC.1,AC.2,AC.3)should load enforcement action PRIS and NOENF for Adult or youth and APYG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-548', '@JIRA-STORY:PO-590'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5158'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.addEnforcementAction).click();
          cy.get(DOM_ELEMENTS.prisLabel).should('exist');
          cy.get(DOM_ELEMENTS.pris).should('exist');
          cy.get(DOM_ELEMENTS.pris).click();
          cy.get(DOM_ELEMENTS.earliestReleaseDateLabel).should('contain', 'Earliest release date (EDR)');
          cy.get(DOM_ELEMENTS.earliestReleaseDate).should('exist');
          cy.get(DOM_ELEMENTS.prisonAndPrisonNumberLabel).should('contain', 'Prison and prison number');
          cy.get(DOM_ELEMENTS.prisonAndPrisonNumber).should('exist');
          cy.get(DOM_ELEMENTS.prisHint).should('contain', 'Held as enforcement comment');
          cy.get(DOM_ELEMENTS.characterCountHint).should('contain', 'You have 28 characters remaining');

          cy.get(DOM_ELEMENTS.noenfLabel).should('exist');
          cy.get(DOM_ELEMENTS.noenf).should('exist');
          cy.get(DOM_ELEMENTS.noenf).click();
          cy.get(DOM_ELEMENTS.reasonAccountIsOnNoenfLabel).should('contain', 'Reason account is on NOENF');
          cy.get(DOM_ELEMENTS.reasonAccountIsOnNoenf).should('exist');
          cy.get(DOM_ELEMENTS.characterCountHint).should('contain', 'You have 28 characters remaining');
        });
      }
    },
  );

  it(
    '(AC.4)should provide error for selection enforcement action panel but not selecting any enforcement action',
    {
      tags: [...buildTags('@JIRA-STORY:PO-548', '@JIRA-STORY:PO-590'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5159'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i]);

          cy.get(DOM_ELEMENTS.addEnforcementAction).click();
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.enforcementActionReason);
        });
      }
    },
  );

  it(
    '(AC.5,AC.6)should have validations in place for enforcement action (pris)',
    {
      tags: [...buildTags('@JIRA-STORY:PO-548', '@JIRA-STORY:PO-590'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5160'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            state.paymentTerms.formData.fm_payment_terms_add_enforcement_action = true;
            state.paymentTerms.formData.fm_payment_terms_enforcement_action = 'PRIS';
            state.paymentTerms.formData.fm_payment_terms_prison_and_prison_number = 'HMP:Example-Prison';
          });
          cy.get(DOM_ELEMENTS.earliestReleaseDate).type('32/09/2025', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });

          for (const [, value] of Object.entries(ENFORCEMENT_ERRORS)) {
            cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', value);
          }

          cy.get(DOM_ELEMENTS.earliestReleaseDate).clear().type('29/09/2021', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.futureDateMust);

          cy.get(DOM_ELEMENTS.earliestReleaseDate).clear().type('29,09.2021', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.prisonDateFormat);
        });
      }
    },
  );

  it(
    '(AC.7) Should provide error if (NOENF) field is left empty',
    {
      tags: [...buildTags('@JIRA-STORY:PO-548', '@JIRA-STORY:PO-590'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5161'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            state.paymentTerms.formData.fm_payment_terms_add_enforcement_action = true;
            state.paymentTerms.formData.fm_payment_terms_enforcement_action = 'NOENF';
          });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.noenfReason);
        });
      }
    },
  );

  it(
    '(AC.8) should have validations in place for enforcement action (NOENF)',
    {
      tags: [...buildTags('@JIRA-STORY:PO-548', '@JIRA-STORY:PO-590'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5162'],
    },
    () => {
      for (let i = 0; i < 2; i++) {
        cy.then(() => {
          setupComponent(defendantTypes[i], null, (state) => {
            state.paymentTerms.formData.fm_payment_terms_add_enforcement_action = true;
            state.paymentTerms.formData.fm_payment_terms_enforcement_action = 'NOENF';
          });
          cy.get(DOM_ELEMENTS.reasonAccountIsOnNoenf).type('@', { delay: 0 });
          cy.get(DOM_ELEMENTS.submitButton).click({ multiple: true });
          cy.get(DOM_ELEMENTS.govukErrorMessage).should('contain', ERROR_MESSAGES.noenfTypeCheck);
        });
      }
    },
  );

  it(
    '(AC.1,4,5a) correct system note for a leap-day collection order - AY',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-NFR:PO-2325', '@JIRA-TEST-KEY:PO-6350'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('adultOrYouthOnly', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderPreviouslyMade(state, '29/02/2024');
        setPayInFull(state, '01/03/2024');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        expect(systemNote).to.equal(
          'A collection order was previously made on 29/02/2024 prior to this account creation',
        );
      });
    },
  );
  it(
    '(AC.1,4,5b) correct system note for a bank-holiday collection order - AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-NFR:PO-2325', '@JIRA-TEST-KEY:PO-6351'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderPreviouslyMade(state, '25/12/2025');
        setPayInFull(state, '26/12/2025');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        expect(systemNote).to.equal(
          'A collection order was previously made on 25/12/2025 prior to this account creation',
        );
      });
    },
  );
  it(
    '(AC.2,4,5a) correct system note - Make collection order today - AY',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5165'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('adultOrYouthOnly', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderMadeToday(state);
        setPayInFull(state, '01/01/2023');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });
    },
  );

  it(
    '(AC.2,4,5b) correct system note - Make collection order today - AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5166'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();
      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderMadeToday(state);
        setPayInFull(state, '01/01/2023');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();
      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });
    },
  );

  it(
    '(AC3a,c,4,5a) update system note using the DST short-day boundary date - AY',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-NFR:PO-2325', '@JIRA-TEST-KEY:PO-6352'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('adultOrYouthOnly', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderMadeToday(state);
        setPayInFull(state, '01/01/2023');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });

      cy.get(DOM_ELEMENTS.collectionOrder.yes).check();
      cy.get(DOM_ELEMENTS.collectionOrderDate).clear().type('30/03/2025', { delay: 0, force: true });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal(
          'A collection order was previously made on 30/03/2025 prior to this account creation',
        );
      });
    },
  );

  it(
    '(AC3a,c,4,5b) update system note using the DST long-day boundary date - AYPG',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-NFR:PO-2325', '@JIRA-TEST-KEY:PO-6353'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderMadeToday(state);
        setPayInFull(state, '01/01/2023');
      });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });

      cy.get(DOM_ELEMENTS.collectionOrder.yes).check();
      cy.get(DOM_ELEMENTS.collectionOrderDate).clear().type('26/10/2025', { delay: 0, force: true });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal(
          'A collection order was previously made on 26/10/2025 prior to this account creation',
        );
      });
    },
  );

  it(
    '(AC3b,d,4,5a) update system note - Previously made - Made today - AY',
    {
      tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5169'],
    },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('adultOrYouthOnly', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderPreviouslyMade(state, '05/01/2023');
        setPayInFull(state, '01/01/2023');
      });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal(
          'A collection order was previously made on 05/01/2023 prior to this account creation',
        );
      });

      cy.get(DOM_ELEMENTS.collectionNo).check();
      cy.get(DOM_ELEMENTS.makeCollection).check();

      cy.get(DOM_ELEMENTS.payInFull).check();
      cy.get(DOM_ELEMENTS.payByDate).clear().type('01/01/2023', { delay: 0, force: true });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });
    },
  );

  it(
    '(AC3b,d,4,5b) update system note - Previously made - Made today - AYPG',
    { tags: [...buildTags('@JIRA-STORY:PO-651'), '@JIRA-EPIC:PO-545', '@JIRA-TEST-KEY:PO-5170'] },
    () => {
      const setAccountCommentsNotesSpy = Cypress.sinon.spy();

      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderPreviouslyMade(state, '05/01/2023');
        setPayInFull(state, '01/01/2023');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal(
          'A collection order was previously made on 05/01/2023 prior to this account creation',
        );
      });

      cy.get(DOM_ELEMENTS.collectionNo).check();
      cy.get(DOM_ELEMENTS.makeCollection).check();

      cy.get(DOM_ELEMENTS.payInFull).check();
      cy.get(DOM_ELEMENTS.payByDate).clear().type('01/01/2023', { delay: 0, force: true });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });
    },
  );

  it(
    '(AC1b, 1e) Update system note - Previously made → Criteria not met',
    { tags: [...buildTags('@JIRA-STORY:PO-1592'), '@JIRA-EPIC:PO-50', '@JIRA-TEST-KEY:PO-5171'] },
    () => {
      const setAccountCommentsNotesSpy = cy.spy().as('setAccountCommentsNotesSpy');

      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderPreviouslyMade(state, '05/01/2023');
        setPayInFull(state, '01/01/2023');
      });
      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal(
          'A collection order was previously made on 05/01/2023 prior to this account creation',
        );
      });

      cy.get(DOM_ELEMENTS.collectionNo).check();
      cy.get(DOM_ELEMENTS.makeCollection).uncheck();

      cy.get(DOM_ELEMENTS.payInFull).check();
      cy.get(DOM_ELEMENTS.payByDate).clear().type('01/01/2023', { delay: 0, force: true });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        cy.log('Arg:', arg);
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.be.null;
      });
    },
  );

  it(
    '(AC1b, 1e) Update system note - Made today → Criteria not met',
    { tags: [...buildTags('@JIRA-STORY:PO-1592'), '@JIRA-EPIC:PO-50', '@JIRA-TEST-KEY:PO-5172'] },
    () => {
      const setAccountCommentsNotesSpy = cy.spy().as('setAccountCommentsNotesSpy');

      setupComponent('pgToPay', setAccountCommentsNotesSpy, (state) => {
        setDateOfBirth(state, '01/01/2000');
        setBusinessUnitPermission(state);
        setCollectionOrderMadeToday(state);
        setPayInFull(state, '01/01/2023');
      });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledOnce');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[0][0];
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.equal('A collection order has been made by Timmy Test using Authorised Functions');
      });

      cy.get(DOM_ELEMENTS.collectionNo).check();
      cy.get(DOM_ELEMENTS.makeCollection).uncheck();

      cy.get(DOM_ELEMENTS.payInFull).check();
      cy.get(DOM_ELEMENTS.payByDate).clear().type('01/01/2023', { delay: 0, force: true });

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      cy.wrap(setAccountCommentsNotesSpy).should('have.been.calledTwice');
      cy.wrap(setAccountCommentsNotesSpy).then((calls: any) => {
        cy.log('Calls:', calls);
        const arg = calls.args[1][0];
        cy.log('Arg:', arg);
        const systemNote = arg.formData.fm_account_comments_notes_system_notes;
        cy.log('System note:', systemNote);
        expect(systemNote).to.be.null;
      });
    },
  );
});
