import { FinesMacPersonalDetailsComponent } from '../../../../src/app/flows/fines/fines-mac/fines-mac-personal-details/fines-mac-personal-details.component';
import { FINES_MAC_STATE_MOCK } from '../../../../src/app/flows/fines/fines-mac/mocks/fines-mac-state.mock';
import {
  FORMAT_CHECK,
  MAIN_PERSONAL_DETAILS,
  ALIAS_ALLOWED_CHARACTER_VALIDATION,
  ALIAS_PERSONAL_DETAILS,
  LENGTH_VALIDATION,
  CORRECTION_TEST_MESSAGES,
  VEHICLE_DETAILS_ERRORS,
} from './constants/fines_mac_personal_details_errors';
import {
  MacPersonalDetailsLocators as DOM_ELEMENTS,
  getAliasFirstName,
  getAliasLastName,
} from '../../../shared/selectors/manual-account-creation/mac.personal-details.locators';
import { calculateDOB } from 'cypress/support/utils/dateUtils';
import { mountMacStoreComponent } from '../support/mountMacStoreComponent';

const MANUAL_ACCOUNT_CREATION_JIRA_LABEL = '@JIRA-LABEL:manual-account-creation';

const buildTags = (...tags: string[]) => [...tags, MANUAL_ACCOUNT_CREATION_JIRA_LABEL];

describe('FinesMacPersonalDetailsComponent', () => {
  type FinesMacPersonalDetailsState = typeof FINES_MAC_STATE_MOCK;

  const buildFinesMacPersonalDetailsState = (
    defendantTypeMock: string = '',
    configure?: (finesMacState: FinesMacPersonalDetailsState) => void,
  ): FinesMacPersonalDetailsState => {
    const finesMacState = structuredClone(FINES_MAC_STATE_MOCK);
    finesMacState.accountDetails.formData.fm_create_account_defendant_type = defendantTypeMock;
    configure?.(finesMacState);
    return finesMacState;
  };

  const setupComponent = (
    formSubmit?: any,
    defendantTypeMock: string = '',
    configure?: (finesMacState: FinesMacPersonalDetailsState) => void,
  ) =>
    mountMacStoreComponent({
      component: FinesMacPersonalDetailsComponent,
      componentProperties: {
        defendantType: defendantTypeMock,
      },
      formSubmit,
      initialState: buildFinesMacPersonalDetailsState(defendantTypeMock, configure),
      submitHandlerName: 'handlePersonalDetailsSubmit',
    });

  it(
    '(AC.1a) should load all elements on the screen correctly',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3970'] },
    () => {
      setupComponent(null);

      cy.get(DOM_ELEMENTS.pageTitle).should('contain', 'Personal details');

      cy.get(DOM_ELEMENTS.firstNamesInput).should('exist');
      cy.get(DOM_ELEMENTS.lastNameInput).should('exist');
      cy.get(DOM_ELEMENTS.dateOfBirthInput).should('exist');
      cy.get(DOM_ELEMENTS.addressLine1Input).should('exist');
      cy.get(DOM_ELEMENTS.addressLine2Input).should('exist');
      cy.get(DOM_ELEMENTS.addressLine3Input).should('exist');
      cy.get(DOM_ELEMENTS.postcodeInput).should('exist');
      cy.get(DOM_ELEMENTS.niNumberInput).should('exist');

      cy.get(DOM_ELEMENTS.firstNameLabel).should('contain', 'First names');
      cy.get(DOM_ELEMENTS.lastNameLabel).should('contain', 'Last name');
      cy.get(DOM_ELEMENTS.dobLabel).should('contain', 'Date of birth');
      cy.get(DOM_ELEMENTS.addressLine1Label).should('contain', 'Address line 1');
      cy.get(DOM_ELEMENTS.addressLine2Label).should('contain', 'Address line 2');
      cy.get(DOM_ELEMENTS.addressLine3Label).should('contain', 'Address line 3');
      cy.get(DOM_ELEMENTS.postcodeLabel).should('contain', 'Postcode');
      cy.get(DOM_ELEMENTS.niNumberLabel).should('contain', 'National Insurance number');
      cy.get(DOM_ELEMENTS.firstNameHint).should('contain', 'Include their middle names');
      cy.get(DOM_ELEMENTS.DateHint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Address');

      cy.get(DOM_ELEMENTS.cancelLink).should('exist');
      cy.get(DOM_ELEMENTS.aliasAdd).should('exist');
    },
  );

  it(
    '(AC.1) should load button for next page for adultOrYouthOnly Defendant (FinesMacPersonalDetailsComponent)',
    { tags: [...buildTags('@JIRA-STORY:PO-433'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3971'] },
    () => {
      setupComponent(null, 'adultOrYouthOnly');

      cy.get(DOM_ELEMENTS.submitButton).should('contain', 'Add contact details');
    },
  );

  it(
    '(AC.2) should load button for next page for AYPG Defendant',
    { tags: [...buildTags('@JIRA-STORY:PO-369'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-3972'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.submitButton).should('contain', 'Add offence details');
    },
  );

  it(
    '(AC.2, AC.3) should display validation error when mandatory fields are missing',
    {
      tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-NFR:PO-2323', '@JIRA-TEST-KEY:PO-3973'],
    },
    () => {
      setupComponent(null);

      cy.get(DOM_ELEMENTS.submitButton).click();

      for (const [, value] of Object.entries(MAIN_PERSONAL_DETAILS)) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
      }
    },
  );

  it(
    '(AC.1b) should not have any asterisks in address lines',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3974'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = 'asja*';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_2 = 'asja*';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_3 = 'asja*';
      });
      cy.get(DOM_ELEMENTS.submitButton).click();

      for (let i = 1; i <= 3; i++) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK[`addressLine${i}ContainsSpecialCharacters`]);
      }
    },
  );

  it(
    '(AC.1a) should not allow first names,last names and Address lines 1,2 & 3 to have more than max characters',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3975'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_forenames =
          'John Smithy Michael John Smithy Michael long';
        finesMacState.personalDetails.formData.fm_personal_details_surname = 'Astridge Lamsden Langley Treen long';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = 'a'.repeat(31);
        finesMacState.personalDetails.formData.fm_personal_details_address_line_2 = 'a'.repeat(31);
        finesMacState.personalDetails.formData.fm_personal_details_address_line_3 = 'a'.repeat(31);
      });

      cy.get(DOM_ELEMENTS.submitButton).click();

      for (const [, value] of Object.entries(LENGTH_VALIDATION)) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
      }
    },
  );
  it(
    '(AC.4) should validate the functionality of the Add Aliases tick box',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3976'] },
    () => {
      setupComponent(null);

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 1');

      cy.get(getAliasFirstName(0)).should('exist');
      cy.get(getAliasLastName(0)).should('exist');

      cy.get(DOM_ELEMENTS.aliasAddButton).should('exist');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('not.exist');
    },
  );

  it(
    '(AC.5, AC.6, AC.7) should have working alias workflow and remove button',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3977'] },
    () => {
      setupComponent(null);

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.aliasAddButton).click();

      cy.get(getAliasFirstName(0)).should('exist');
      cy.get(getAliasLastName(0)).should('exist');

      cy.get(getAliasFirstName(1)).should('exist');
      cy.get(getAliasLastName(1)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 2');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(2)).should('exist');
      cy.get(getAliasLastName(2)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 3');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(3)).should('exist');
      cy.get(getAliasLastName(3)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 4');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(4)).should('exist');
      cy.get(getAliasLastName(4)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 5');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(4)).should('not.exist');
      cy.get(getAliasLastName(4)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 5');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(3)).should('not.exist');
      cy.get(getAliasLastName(3)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 4');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(2)).should('not.exist');
      cy.get(getAliasLastName(2)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 3');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(1)).should('not.exist');
      cy.get(getAliasLastName(1)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 2');
    },
  );

  it(
    '(AC.8) should validate unticking add aliases removes all aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3978'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          [`fm_personal_details_alias_forenames_${0}`]: 'AliasFNAME1',
          [`fm_personal_details_alias_surname_${0}`]: 'AliasLNAME1',
        });
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          [`fm_personal_details_alias_forenames_${1}`]: 'AliasFNAME2',
          [`fm_personal_details_alias_surname_${1}`]: 'AliasLNAME2',
        });
      });
      cy.get(DOM_ELEMENTS.aliasAdd).check();
      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(0)).should('have.value', 'AliasFNAME1');
      cy.get(getAliasLastName(0)).should('have.value', 'AliasLNAME1');
      cy.get(getAliasFirstName(1)).should('have.value', 'AliasFNAME2');
      cy.get(getAliasLastName(1)).should('have.value', 'AliasLNAME2');

      cy.get(DOM_ELEMENTS.aliasAdd).uncheck();
      cy.get(DOM_ELEMENTS.aliasAdd).check();
      cy.get(getAliasFirstName(0)).should('have.value', '');
      cy.get(getAliasLastName(0)).should('have.value', '');

      cy.get(getAliasFirstName(1)).should('not.exist');
      cy.get(getAliasLastName(1)).should('not.exist');
    },
  );

  it(
    '(AC.10) should show error for missing alias',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3979'] },
    () => {
      setupComponent(null);

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasFirstNameOne);
    },
  );

  it(
    '(AC.10) should show error for missing alias last name',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3980'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_add_alias = true;
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_surname_0: 'Smith',
        });
      });
      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasFirstNameOne);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne);
    },
  );

  it(
    '(AC.10) should show error for missing alias first name',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3981'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_add_alias = true;
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_forenames_0: 'John',
        });
      });
      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', ALIAS_PERSONAL_DETAILS.missingAliasFirstNameOne);
    },
  );

  it(
    '(AC.10) should show error for missing additional alias first name',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3982'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_add_alias = true;
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_forenames_0: 'John',
          fm_personal_details_alias_surname_0: 'Smith',
        });
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_surname_1: 'Smith',
        });
      });
      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(DOM_ELEMENTS.submitButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameTwo}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameThree}`);
    },
  );

  it(
    '(AC.10) should show error for missing additional alias last name',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3983'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_add_alias = true;
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_forenames_0: 'John',
          fm_personal_details_alias_surname_0: 'Smith',
        });
        finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
          fm_personal_details_alias_forenames_1: 'John',
        });
      });
      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(DOM_ELEMENTS.submitButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameTwo}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFirstNameThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameThree}`);
    },
  );

  it(
    '(AC.9) should show error for future date of birth',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3984'] },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_title = 'Mrs';
        finesMacState.personalDetails.formData.fm_personal_details_forenames = 'Smith';
        finesMacState.personalDetails.formData.fm_personal_details_dob = '01/01/3000';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = '123 fake street';
      });
      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', 'Enter a valid date of birth in the past');
    },
  );

  it(
    '(AC.9) should show error for a non-leap-year date of birth',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-360'),
        '@JIRA-EPIC:PO-272',
        '@JIRA-NFR:PO-2323',
        '@JIRA-NFR:PO-2325',
        '@JIRA-TEST-KEY:PO-6354',
      ],
    },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_title = 'Mrs';
        finesMacState.personalDetails.formData.fm_personal_details_forenames = 'Smith';
        finesMacState.personalDetails.formData.fm_personal_details_dob = '29/02/2023';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = '123 fake street';
      });
      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK['dateOfBirthNotValid']);
    },
  );

  it(
    '(AC.11) should not accept national insurance number in the incorrect format',
    {
      tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-NFR:PO-2323', '@JIRA-TEST-KEY:PO-3986'],
    },
    () => {
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_title = 'Mrs';
        finesMacState.personalDetails.formData.fm_personal_details_forenames = 'Smith';
        finesMacState.personalDetails.formData.fm_personal_details_dob = '01/01/3000';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = '123 fake street';
        finesMacState.personalDetails.formData.fm_personal_details_national_insurance_number = 'AB1234565C';
      });

      cy.get(DOM_ELEMENTS.submitButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK['validNationalInsuranceNumber']);
    },
  );

  it(
    '(AC.12) should show errors for invalid mandatory fields and allow corrections',
    { tags: [...buildTags('@JIRA-STORY:PO-360'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3987'] },
    () => {
      const formSubmitSpy = Cypress.sinon.spy();

      setupComponent(formSubmitSpy, 'adultOrYouthOnly', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_forenames =
          'Stuart Philips aarogyam Guuci Coach VII';
        finesMacState.personalDetails.formData.fm_personal_details_surname =
          'Chicago bulls Burberry RedBull 2445 PizzaHut';
        finesMacState.personalDetails.formData.fm_personal_details_address_line_1 = 'test Road *12';
      });

      cy.get(DOM_ELEMENTS.submitButton).contains('Return to account details').click();

      for (const [, value] of Object.entries(CORRECTION_TEST_MESSAGES)) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
      }

      cy.get(DOM_ELEMENTS.titleSelect).select('Mr');
      cy.get(DOM_ELEMENTS.firstNamesInput).clear().type('f', { delay: 0 });
      cy.get(DOM_ELEMENTS.lastNameInput).clear().type('s', { delay: 0 });
      cy.get(DOM_ELEMENTS.addressLine1Input).clear().type('addr', { delay: 0 });

      cy.get(DOM_ELEMENTS.submitButton).contains('Return to account details').click();
      cy.get(DOM_ELEMENTS.errorSummary).should('not.exist');

      cy.wrap(formSubmitSpy).should('have.been.calledOnce');
    },
  );

  it(
    '(AC.5) should render vehicle details for adultOrYouthOnly defendant type and validate max length of data',
    { tags: [...buildTags('@JIRA-STORY:PO-502'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3988'] },
    () => {
      setupComponent(null, 'adultOrYouthOnly', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_vehicle_make = 'a'.repeat(51);
        finesMacState.personalDetails.formData.fm_personal_details_vehicle_registration_mark = 'a'.repeat(24);
      });

      // Verify the vehicle details section is rendered
      cy.get(DOM_ELEMENTS.vehicleRegistrationMarkLabel).should('contain', 'Registration number');
      cy.get(DOM_ELEMENTS.vehicleMakeLabel).should('contain', 'Make and model');
      cy.get(DOM_ELEMENTS.vehicleMakeInput).should('exist');
      cy.get(DOM_ELEMENTS.vehicleRegistrationInput).should('exist');

      cy.get(DOM_ELEMENTS.submitButton).first().click();

      for (const [, value] of Object.entries(VEHICLE_DETAILS_ERRORS)) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
      }
    },
  );
  it(
    '(AC.2) should display age panel when entering a valid age for youth',
    { tags: [...buildTags('@JIRA-STORY:PO-502'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3989'] },
    () => {
      const age = 17;
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_dob = calculateDOB(age);
      });
      cy.get('.moj-ticket-panel').should('exist');
      cy.get('opal-lib-moj-ticket-panel').find('strong').should('contain.text', age);
      cy.get('.moj-ticket-panel').find('p').should('contain.text', 'Youth');
    },
  );
  it(
    '(AC.3) should display age panel when entering a valid age for adult',
    { tags: [...buildTags('@JIRA-STORY:PO-502'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3990'] },
    () => {
      const age = 18;
      setupComponent(null, '', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_dob = calculateDOB(age);
      });
      cy.get('.moj-ticket-panel').should('exist');
      cy.get('opal-lib-moj-ticket-panel').find('strong').should('contain.text', age);
      cy.get('.moj-ticket-panel').find('p').should('contain.text', 'Adult');
    },
  );

  it(
    '(AC.5) should not render vehicle details for AY-PG defendant type',
    { tags: [...buildTags('@JIRA-STORY:PO-505'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-3991'] },
    () => {
      setupComponent(null, 'pgToPay');

      // Verify the vehicle details section is not rendered
      cy.get(DOM_ELEMENTS.vehicleRegistrationMarkLabel).should('not.exist');
      cy.get(DOM_ELEMENTS.vehicleMakeLabel).should('not.exist');
      cy.get(DOM_ELEMENTS.vehicleMakeInput).should('not.exist');
      cy.get(DOM_ELEMENTS.vehicleRegistrationInput).should('not.exist');
    },
  );

  it(
    '(AC.1) Personal details should capitalise - AYPG',
    { tags: [...buildTags('@JIRA-STORY:PO-1449'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-3992'] },
    () => {
      const formSubmitSpy = Cypress.sinon.spy();
      setupComponent(formSubmitSpy, 'pgToPay');

      cy.get(DOM_ELEMENTS.titleSelect).select('Mr');
      cy.get(DOM_ELEMENTS.firstNamesInput).clear().type('fname', { delay: 0 });
      cy.get(DOM_ELEMENTS.addressLine1Input).clear().type('addr', { delay: 0 });

      cy.get(DOM_ELEMENTS.lastNameInput).type('lname', { delay: 0 });
      cy.get(DOM_ELEMENTS.lastNameInput).blur();
      cy.get(DOM_ELEMENTS.postcodeInput).type('sl86et', { delay: 0 });
      cy.get(DOM_ELEMENTS.postcodeInput).blur();
      cy.get(DOM_ELEMENTS.niNumberInput).type('ab712348b', { delay: 0 });
      cy.get(DOM_ELEMENTS.niNumberInput).blur();

      cy.get(DOM_ELEMENTS.lastNameInput).should('have.value', 'LNAME');
      cy.get(DOM_ELEMENTS.postcodeInput).should('have.value', 'SL86ET');
      cy.get(DOM_ELEMENTS.niNumberInput).should('have.value', 'AB712348B');
      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(getAliasFirstName(0)).type('alias0fname');
      cy.get(getAliasLastName(0)).type('alias0lname').should('have.value', 'ALIAS0LNAME');

      // Add the remaining four aliases using loop
      for (let i = 1; i < 5; i++) {
        cy.get(DOM_ELEMENTS.aliasAddButton).click();
        cy.get(getAliasFirstName(i)).type(`alias${i + 1}fname`);
        cy.get(getAliasLastName(i))
          .type(`alias${i + 1}lname`)
          .should('have.value', `ALIAS${i + 1}LNAME`);
      }

      cy.get(DOM_ELEMENTS.submitButton).contains('Return to account details').click();
    },
  );

  it(
    '(AC.1) should convert specified fields to uppercase on user input',
    { tags: [...buildTags('@JIRA-STORY:PO-1448'), '@JIRA-EPIC:PO-272', '@JIRA-TEST-KEY:PO-3993'] },
    () => {
      setupComponent(null, 'adultOrYouthOnly');

      cy.get(DOM_ELEMENTS.lastNameInput).type('smith', { delay: 0 }).should('have.value', 'SMITH');
      cy.get(DOM_ELEMENTS.postcodeInput).type('ab12 3cd', { delay: 0 }).should('have.value', 'AB12 3CD');
      cy.get(DOM_ELEMENTS.vehicleRegistrationInput).type('xy12 abc', { delay: 0 }).should('have.value', 'XY12 ABC');
      cy.get(DOM_ELEMENTS.niNumberInput).type('ab123456c', { delay: 0 }).should('have.value', 'AB123456C');

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(getAliasLastName(0)).type('alias1', { delay: 0 }).should('have.value', 'ALIAS1');

      // Add the remaining four aliases using a loop
      for (let i = 1; i < 5; i++) {
        cy.get(DOM_ELEMENTS.aliasAddButton).click();
        cy.get(getAliasLastName(i))
          .type(`alias${i + 1}`, { delay: 0 })
          .should('have.value', `ALIAS${i + 1}`);
      }
    },
  );

  it(
    '(AC.1, 2, 3, 8) Defendant first & last name allows single-byte ASCII characters',
    {
      tags: [
        ...buildTags('@JIRA-EPIC:PO-2219', '@JIRA-STORY:PO-3415', '@JIRA-LABEL:populate-and-submit'),
        '@JIRA-TEST-KEY:PO-3994',
      ],
    },
    () => {
      setupComponent(null, 'adultOrYouthOnly');
      cy.get(DOM_ELEMENTS.lastNameInput).clear().type(" Aa0'!#$%&()*+,-./<>");
      cy.get(DOM_ELEMENTS.firstNamesInput).clear().type(" Aa0'!#$%&()*+,-./<>");

      cy.get(DOM_ELEMENTS.addContactDetailsButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should(
        'not.contain',
        "Defendant's first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas",
      );
      cy.get(DOM_ELEMENTS.firstNameError).should('not.exist');

      cy.get(DOM_ELEMENTS.errorSummary).should(
        'not.contain',
        "Defendant's last name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas",
      );
      cy.get(DOM_ELEMENTS.lastNameError).should('not.exist');
    },
  );

  it(
    '(AC.1, 2, 3, 8) should validate type check to ensure name fields does not allow non-single-byte ASCII characters',
    {
      tags: [
        ...buildTags(
          '@JIRA-EPIC:PO-345',
          '@JIRA-EPIC:PO-2219',
          '@JIRA-STORY:PO-365',
          '@JIRA-STORY:PO-3415',
          '@JIRA-LABEL:populate-and-submit',
        ),
        '@JIRA-KEY:POT-7337',
        '@JIRA-TEST-KEY:PO-3995',
      ],
    },
    () => {
      setupComponent(null, 'adultOrYouthOnly', (finesMacState) => {
        finesMacState.personalDetails.formData.fm_personal_details_forenames = '©µ±ö€•';
        finesMacState.personalDetails.formData.fm_personal_details_surname = '©µ±ö€•';
        finesMacState.personalDetails.formData.fm_personal_details_add_alias = true;

        cy.get(DOM_ELEMENTS.aliasAdd).should('be.checked');

        for (let i = 0; i < 5; i++) {
          finesMacState.personalDetails.formData.fm_personal_details_aliases.push({
            [`fm_personal_details_alias_forenames_${i}`]: '©µ±ö€•',
            [`fm_personal_details_alias_surname_${i}`]: '©µ±ö€•',
          });
        }

        cy.get(DOM_ELEMENTS.submitButton).first().click();

        for (const [, value] of Object.entries(ALIAS_ALLOWED_CHARACTER_VALIDATION)) {
          cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
        }
      });
    },
  );
});
