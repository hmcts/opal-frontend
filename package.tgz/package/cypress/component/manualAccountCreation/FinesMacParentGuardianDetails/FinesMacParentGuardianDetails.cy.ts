import { mount } from 'cypress/angular';
import { OpalFines } from '../../../../src/app/flows/fines/services/opal-fines-service/opal-fines.service';
import { ActivatedRoute } from '@angular/router';
import { FINES_MAC_STATE_MOCK } from '../../../../src/app/flows/fines/fines-mac/mocks/fines-mac-state.mock';
import { FinesMacParentGuardianDetailsComponent } from '../../../../src/app/flows/fines/fines-mac/fines-mac-parent-guardian-details/fines-mac-parent-guardian-details.component';
import {
  MacParentGuardianDetailsLocators as DOM_ELEMENTS,
  getAliasFirstName,
  getAliasLastName,
} from '../../../shared/selectors/manual-account-creation/mac.parent-guardian-details.locators';
import {
  MAIN_PERSONAL_DETAILS,
  ALIAS_PERSONAL_DETAILS,
  LENGTH_VALIDATION,
  FORMAT_CHECK,
  CORRECTION_TEST_MESSAGES,
  ALIAS_LENGTH_VALIDATION,
  ALIAS_ALPHABETIC_VALIDATION,
} from './constants/fines_mac_parent_guardian_details_errors';
import { FinesMacStore } from 'src/app/flows/fines/fines-mac/stores/fines-mac.store';
import { nonPermittedSpecialCharacters } from './constants/fines_mac_parent_guardian_details_character_check';
import { of } from 'rxjs';

const MANUAL_ACCOUNT_CREATION_JIRA_LABEL = '@JIRA-LABEL:manual-account-creation';

const buildTags = (...tags: string[]) => [...tags, MANUAL_ACCOUNT_CREATION_JIRA_LABEL];

describe('FinesMacParentGuardianDetailsComponent', () => {
  let finesMacStateTemplate = structuredClone(FINES_MAC_STATE_MOCK);
  let finesMacState = finesMacStateTemplate;

  beforeEach(() => {
    finesMacStateTemplate = structuredClone(FINES_MAC_STATE_MOCK);
    finesMacState = finesMacStateTemplate;
  });

  const setupComponent = (formSubmit?: any, mockDefendantType: string = '') => {
    finesMacState = structuredClone(finesMacStateTemplate);
    finesMacState.accountDetails.formData.fm_create_account_defendant_type = mockDefendantType;

    return mount(FinesMacParentGuardianDetailsComponent, {
      providers: [
        OpalFines,
        {
          provide: FinesMacStore,
          useFactory: () => {
            const store = new FinesMacStore();
            store.setFinesMacStore(finesMacState);
            return store;
          },
        },
        {
          provide: ActivatedRoute,
          useValue: {
            parent: of('manual-account-creation'),
          },
        },
      ],
      componentProperties: {
        defendantType: mockDefendantType,
      },
    }).then(({ fixture }) => {
      if (!formSubmit) {
        return;
      }

      const comp: any = fixture.componentInstance as any;

      if (comp?.handleParentGuardianDetailsSubmit?.subscribe) {
        comp.handleParentGuardianDetailsSubmit.subscribe((...args: any[]) => (formSubmit as any)(...args));
      } else if (typeof comp?.handleParentGuardianDetailsSubmit === 'function') {
        comp.handleParentGuardianDetailsSubmit = formSubmit;
      }

      fixture.detectChanges();
    });
  };

  it(
    'should render the ParentGuardianDetails component',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-364', '@JIRA-STORY:PO-436', '@JIRA-STORY:PO-569'),
        '@JIRA-EPIC:PO-344',
        '@JIRA-TEST-KEY:PO-5080',
      ],
    },
    () => {
      setupComponent(null, 'pgToPay');
      cy.get(DOM_ELEMENTS.app).should('exist');
    },
  );

  it(
    '(AC.1) should load all elements on the screen correctly (FinesMacParentGuardianDetailsComponent)',
    {
      tags: [
        ...buildTags('@JIRA-STORY:PO-364', '@JIRA-STORY:PO-436', '@JIRA-STORY:PO-569'),
        '@JIRA-EPIC:PO-344',
        '@JIRA-TEST-KEY:PO-5081',
      ],
    },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.pageTitle).should('contain', 'Parent or guardian details');

      cy.get(DOM_ELEMENTS.firstNameInput).should('exist');
      cy.get(DOM_ELEMENTS.lastNameInput).should('exist');
      cy.get(DOM_ELEMENTS.dobInput).should('exist');
      cy.get(DOM_ELEMENTS.addressLine1Input).should('exist');
      cy.get(DOM_ELEMENTS.addressLine2Input).should('exist');
      cy.get(DOM_ELEMENTS.addressLine3Input).should('exist');
      cy.get(DOM_ELEMENTS.postcodeInput).should('exist');
      cy.get(DOM_ELEMENTS.vehicle_makeInput).should('exist');
      cy.get(DOM_ELEMENTS.vehicle_registration_markInput).should('exist');
      cy.get(DOM_ELEMENTS.niNumberInput).should('exist');

      cy.get(DOM_ELEMENTS.firstNameLabel).should('contain', 'First names');
      cy.get(DOM_ELEMENTS.lastNameLabel).should('contain', 'Last name');
      cy.get(DOM_ELEMENTS.dobLabel).should('contain', 'Date of birth');
      cy.get(DOM_ELEMENTS.addressLine1Label).should('contain', 'Address line 1');
      cy.get(DOM_ELEMENTS.addressLine2Label).should('contain', 'Address line 2');
      cy.get(DOM_ELEMENTS.addressLine3Label).should('contain', 'Address line 3');
      cy.get(DOM_ELEMENTS.postcodeLabel).should('contain', 'Postcode');
      cy.get(DOM_ELEMENTS.vehicleMakeLabel).should('contain', 'Make and model');
      cy.get(DOM_ELEMENTS.vehicleRegistrationMarkLabel).should('contain', 'Registration number');
      cy.get(DOM_ELEMENTS.niNumberLabel).should('contain', 'National Insurance number');
      cy.get(DOM_ELEMENTS.firstNameHint).should('contain', 'Include their middle names');
      cy.get(DOM_ELEMENTS.DateHint).should('contain', 'For example, 31/01/2023');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Parent or guardian vehicle details');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Parent or guardian address');

      cy.get(DOM_ELEMENTS.cancelLink).should('exist');
      cy.get(DOM_ELEMENTS.aliasAdd).should('exist');
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).should('exist');
      cy.get(DOM_ELEMENTS.addContactDetailsButton).should('exist');
    },
  );

  it(
    '(AC.1) should have length validation on first name field',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5082'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_forenames = 'a'.repeat(31);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.firstNameTooLong);
    },
  );
  it(
    '(AC.1) should not permit special characters on first name field',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5083'] },
    () => {
      cy.wrap(nonPermittedSpecialCharacters).each((character: string) => {
        cy.then(() => {
          finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_forenames = character;
          setupComponent(null, 'pgToPay');
        });
        cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.invalidFirstNames);
      });
    },
  );
  it(
    '(AC.1) should have length validation on last name field',
    {
      tags: [
        ...buildTags(
          '@JIRA-EPIC:PO-344',
          '@JIRA-EPIC:PO-2219',
          '@JIRA-STORY:PO-569',
          '@JIRA-STORY:PO-3415',
          '@JIRA-LABEL:populate-and-submit',
        ),
        '@JIRA-KEY:POT-7486',
        '@JIRA-TEST-KEY:PO-5084',
      ],
    },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_surname = 'a'.repeat(31);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.lastNameTooLong);
    },
  );

  it(
    '(AC.1) should not permit special characters on last name field',
    {
      tags: [
        ...buildTags(
          '@JIRA-EPIC:PO-344',
          '@JIRA-EPIC:PO-2219',
          '@JIRA-STORY:PO-569',
          '@JIRA-STORY:PO-3415',
          '@JIRA-LABEL:populate-and-submit',
        ),
        '@JIRA-KEY:POT-7487',
        '@JIRA-TEST-KEY:PO-5085',
      ],
    },
    () => {
      cy.wrap(nonPermittedSpecialCharacters).each((character: string) => {
        cy.then(() => {
          finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_surname = character;
          setupComponent(null, 'pgToPay');
        });
        cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.invalidLastNames);
      });
    },
  );

  it(
    '(AC.2) should require first name field input',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5086'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', MAIN_PERSONAL_DETAILS.missingFirstName);
    },
  );

  it(
    '(AC.2) should require last name field input',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5087'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', MAIN_PERSONAL_DETAILS.missingLastName);
    },
  );

  it(
    '(AC.3) should validate the functionality of the Add Aliases tick box',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5088'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 1');

      cy.get(getAliasFirstName(0)).should('exist');
      cy.get(getAliasLastName(0)).should('exist');

      cy.get(DOM_ELEMENTS.aliasAddButton).should('exist');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('not.exist');
    },
  );

  it(
    '(AC.4, AC.5, AC.6) should have working alias workflow and remove button',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5089'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.aliasAddButton).click();

      cy.get(getAliasFirstName(0)).should('exist');
      cy.get(getAliasLastName(0)).should('exist');

      cy.get(getAliasFirstName(1)).should('exist');
      cy.get(getAliasLastName(1)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 2');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(2)).should('exist');
      cy.get(getAliasLastName(2)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 3');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(3)).should('exist');
      cy.get(getAliasLastName(3)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 4');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      cy.get(getAliasFirstName(4)).should('exist');
      cy.get(getAliasLastName(4)).should('exist');
      cy.get(DOM_ELEMENTS.legend).should('contain', 'Alias 5');
      cy.get(DOM_ELEMENTS.aliasRemoveButton).should('exist').and('not.have.attr', 'aria-label');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(4)).should('not.exist');
      cy.get(getAliasLastName(4)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 5');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(3)).should('not.exist');
      cy.get(getAliasLastName(3)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 4');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(2)).should('not.exist');
      cy.get(getAliasLastName(2)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 3');

      cy.get(DOM_ELEMENTS.aliasRemoveButton).click();
      cy.get(getAliasFirstName(1)).should('not.exist');
      cy.get(getAliasLastName(1)).should('not.exist');
      cy.get(DOM_ELEMENTS.legend).should('not.contain', 'Alias 2');
    },
  );

  it(
    '(AC.7) should validate unticking add aliases removes all aliases',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5090'] },
    () => {
      setupComponent(null, 'pgToPay');
      cy.get(DOM_ELEMENTS.aliasAdd).check();
      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        [`fm_parent_guardian_details_alias_forenames_${0}`]: 'AliasFNAME1',
        [`fm_parent_guardian_details_alias_surname_${0}`]: 'AliasLNAME1',
      });
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        [`fm_parent_guardian_details_alias_forenames_${1}`]: 'AliasFNAME2',
        [`fm_parent_guardian_details_alias_surname_${1}`]: 'AliasLNAME2',
      });
      cy.get(getAliasFirstName(0)).should('have.value', 'AliasFNAME1');
      cy.get(getAliasLastName(0)).should('have.value', 'AliasLNAME1');
      cy.get(getAliasFirstName(1)).should('have.value', 'AliasFNAME2');
      cy.get(getAliasLastName(1)).should('have.value', 'AliasLNAME2');

      cy.get(DOM_ELEMENTS.aliasAdd).uncheck();
      cy.get(DOM_ELEMENTS.aliasAdd).check();
      cy.get(getAliasFirstName(0)).should('have.value', '');
      cy.get(getAliasLastName(0)).should('have.value', '');

      cy.get(getAliasFirstName(1)).should('not.exist');
      cy.get(getAliasLastName(1)).should('not.exist');
    },
  );

  it(
    '(AC.8) should show error for missing alias',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5091'] },
    () => {
      setupComponent(null, 'pgToPay');

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasOne);
    },
  );

  it(
    '(AC.8) should show error for missing alias last name',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5092'] },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_surname_0: 'Smith',
      });
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasOne);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne);
    },
  );

  it(
    '(AC.8) should show error for missing alias first name',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5093'] },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_0: 'John',
      });
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', ALIAS_PERSONAL_DETAILS.missingAliasOne);
    },
  );

  it(
    '(AC.8) should show error for missing additional alias first name',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5094'] },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_0: 'John',
        fm_parent_guardian_details_alias_surname_0: 'Smith',
      });
      Cypress._.times(3, () => {
        cy.get(DOM_ELEMENTS.aliasAddButton).click();
      });
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_surname_1: 'Smith',
      });
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasTwo}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameThree}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFour}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameFour}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasFive}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameFive}`);
    },
  );

  it(
    '(AC.8) should show error for missing additional alias last name',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5095'] },
    () => {
      (setupComponent(null), 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_0: 'John',
        fm_parent_guardian_details_alias_surname_0: 'Smith',
      });
      cy.get(DOM_ELEMENTS.aliasAddButton).click();
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_1: 'John',
      });
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('not.contain', `${ALIAS_PERSONAL_DETAILS.missingAliasTwo}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_PERSONAL_DETAILS.missingAliasLastNameThree}`);
    },
  );

  it(
    'Should show error for too many characters for alias first and last name',
    {
      tags: [
        ...buildTags(
          '@JIRA-STORY:PO-1679',
          '@JIRA-STORY:PO-3415',
          '@JIRA-LABEL:populate-and-submit',
          '@JIRA-EPIC:PO-344',
          '@JIRA-EPIC:PO-2219',
        ),
        '@JIRA-KEY:POT-7498',
        '@JIRA-TEST-KEY:PO-5096',
      ],
    },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_0: 'a'.repeat(21),
        fm_parent_guardian_details_alias_surname_0: 'a'.repeat(31),
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_1: 'a'.repeat(21),
        fm_parent_guardian_details_alias_surname_1: 'a'.repeat(31),
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_2: 'a'.repeat(21),
        fm_parent_guardian_details_alias_surname_2: 'a'.repeat(31),
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_3: 'a'.repeat(21),
        fm_parent_guardian_details_alias_surname_3: 'a'.repeat(31),
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_4: 'a'.repeat(21),
        fm_parent_guardian_details_alias_surname_4: 'a'.repeat(31),
      });

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasLastNameThree}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasFour}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasLastNameFour}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasFive}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_LENGTH_VALIDATION.tooLongAliasLastNameFive}`);
    },
  );

  it(
    'Should show error for non-single-byte ASCII characters for alias first and last name',
    {
      tags: [...buildTags('@JIRA-STORY:PO-1679', '@JIRA-EPIC:PO-344'), '@JIRA-KEY:POT-7499', '@JIRA-TEST-KEY:PO-5097'],
    },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_add_alias = true;
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_0: 'Aliasfname©µ±ö€•',
        fm_parent_guardian_details_alias_surname_0: 'Aliaslname©µ±ö€•',
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_1: 'Fnametwo©µ±ö€•',
        fm_parent_guardian_details_alias_surname_1: 'Lnametwo©µ±ö€•',
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_2: 'Fname-three©µ±ö€•',
        fm_parent_guardian_details_alias_surname_2: 'Lname_three©µ±ö€•',
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_3: 'Fname@four©µ±ö€•',
        fm_parent_guardian_details_alias_surname_3: 'Lnamefour©µ±ö€•',
      });

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_aliases.push({
        fm_parent_guardian_details_alias_forenames_4: 'Fname/five©µ±ö€•',
        fm_parent_guardian_details_alias_surname_4: 'Lnamefive©µ±ö€•',
      });

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasLastNameOne}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasOne}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasLastNameTwo}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasThree}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasLastNameThree}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasFour}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasLastNameFour}`);

      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasFive}`);
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', `${ALIAS_ALPHABETIC_VALIDATION.nonAlphaAliasLastNameFive}`);
    },
  );

  it(
    '(AC.3) should display validation error when date of birth is in the future',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5098'] },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_dob = '01/01/3000';
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK['dateOfBirthInFuture']);
    },
  );

  it(
    '(AC.3) should display validation error when the date of birth is a non-leap-year date',
    {
      tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-NFR:PO-2325', '@JIRA-TEST-KEY:PO-6349'],
    },
    () => {
      setupComponent(null, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_dob = '29/02/2023';
      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK['dateOfBirthNotValid']);
    },
  );

  it(
    '(AC.4) should not accept national insurance number in the incorrect format',
    { tags: [...buildTags('@JIRA-STORY:PO-436'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5100'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_national_insurance_number = 'AB1234565C';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.validNationalInsuranceNumber);
    },
  );

  it(
    '(AC.1) should have max length validation for address line 1',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5101'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_1 = 'a'.repeat(31);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.addressLine1TooLong);
    },
  );

  it(
    '(AC.1) should not permit asterisks in address line 1',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5102'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_1 = 'addr1*';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.addressLine1ContainsSpecialCharacters);
    },
  );
  it(
    '(AC.1) should have max length validation for address line 2',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5103'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_2 = 'a'.repeat(31);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.addressLine2TooLong);
    },
  );

  it(
    '(AC.1) should not permit asterisks in address line 2',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5104'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_2 = 'addr2*';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.addressLine2ContainsSpecialCharacters);
    },
  );
  it(
    '(AC.9) should have max length validation for address line 3',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5105'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_3 = 'a'.repeat(14);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.addressLine3TooLong);
    },
  );

  it(
    '(AC.1) should not permit asterisks in address line 3',
    { tags: [...buildTags('@JIRA-STORY:PO-436'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5106'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_3 = 'addr3*';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', FORMAT_CHECK.addressLine3ContainsSpecialCharacters);
    },
  );
  it(
    '(AC.1) should have max length validation for postcode',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5107'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_post_code = 'a'.repeat(9);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.postcodeTooLong);
    },
  );

  it(
    '(AC.10) should have max length validation for make and model field',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5108'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_vehicle_make = 'a'.repeat(31);

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.vehicleMakeTooLong);
    },
  );
  it(
    '(AC.10) should have max length validation for registration number field',
    { tags: [...buildTags('@JIRA-STORY:PO-569'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5109'] },
    () => {
      setupComponent(null, 'pgToPay');
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_vehicle_registration_mark = 'a'.repeat(
        12,
      );

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('contain', LENGTH_VALIDATION.vehicleRegistrationTooLong);
    },
  );

  it(
    '(AC.5) should show errors for invalid mandatory fields and allow corrections and submit form',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5110'] },
    () => {
      const formSubmitSpy = Cypress.sinon.spy();

      setupComponent(formSubmitSpy, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_forenames =
        'John Jacob Jingleheimer Schmidt Jingleheimer';
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_surname =
        'smith Johnson Alexander Williams Brown Davis';
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_1 = '120 street*';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();

      for (const [, value] of Object.entries(CORRECTION_TEST_MESSAGES)) {
        cy.get(DOM_ELEMENTS.errorSummary).should('contain', value);
      }

      cy.get(DOM_ELEMENTS.firstNameInput).clear().focus().type('Coca Cola', { delay: 0 });
      cy.get(DOM_ELEMENTS.lastNameInput).clear().focus().type('Cola Family', { delay: 0 });
      cy.get(DOM_ELEMENTS.addressLine1Input).clear().focus().type('Pepsi Road', { delay: 0 });

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('not.exist');

      cy.wrap(formSubmitSpy).should('have.been.calledOnce');
    },
  );

  it(
    '(AC.6) should show errors for invalid mandatory fields and allow corrections and submit form',
    { tags: [...buildTags('@JIRA-STORY:PO-364'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5111'] },
    () => {
      const formSubmitSpy = Cypress.sinon.spy();

      setupComponent(formSubmitSpy, 'pgToPay');

      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_forenames = 'FNAME';
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_surname = 'LNAME';
      finesMacState.parentGuardianDetails.formData.fm_parent_guardian_details_address_line_1 = 'ADDR1';

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.get(DOM_ELEMENTS.errorSummary).should('not.exist');

      cy.wrap(formSubmitSpy).should('have.been.calledOnce');
    },
  );

  it(
    '(AC.1) Parent or guardian details should capitalise - AYPG',
    { tags: [...buildTags('@JIRA-STORY:PO-1449'), '@JIRA-EPIC:PO-344', '@JIRA-TEST-KEY:PO-5112'] },
    () => {
      const formSubmitSpy = Cypress.sinon.spy();
      setupComponent(formSubmitSpy, 'pgToPay');

      cy.get(DOM_ELEMENTS.firstNameInput).type('fname', { delay: 0 });
      cy.get(DOM_ELEMENTS.firstNameInput).blur();

      cy.get(DOM_ELEMENTS.lastNameInput).type('lname', { delay: 0 });
      cy.get(DOM_ELEMENTS.lastNameInput).blur();

      cy.get(DOM_ELEMENTS.addressLine1Input).type('12 avenue', { delay: 0 });
      cy.get(DOM_ELEMENTS.addressLine1Input).blur();

      cy.get(DOM_ELEMENTS.postcodeInput).type('sl86et', { delay: 0 });
      cy.get(DOM_ELEMENTS.postcodeInput).blur();

      cy.get(DOM_ELEMENTS.niNumberInput).type('ab712348b', { delay: 0 });
      cy.get(DOM_ELEMENTS.niNumberInput).blur();

      cy.get(DOM_ELEMENTS.vehicle_registration_markInput).type('ap12 slu', { delay: 0 });
      cy.get(DOM_ELEMENTS.vehicle_registration_markInput).blur();

      cy.get(DOM_ELEMENTS.aliasAdd).click();
      cy.get(getAliasFirstName(0)).type('aliasfname');
      cy.get(getAliasLastName(0)).type('aliaslname').should('have.value', 'ALIASLNAME');
      cy.get(DOM_ELEMENTS.lastNameInput).should('have.value', 'LNAME');
      cy.get(DOM_ELEMENTS.postcodeInput).should('have.value', 'SL86ET');
      cy.get(DOM_ELEMENTS.niNumberInput).should('have.value', 'AB712348B');
      cy.get(DOM_ELEMENTS.vehicle_registration_markInput).should('have.value', 'AP12 SLU');

      const aliasNumber = ['one', 'two', 'three', 'four', 'five'];

      // Add the remaining four aliases using loop
      for (let i = 1; i < 5; i++) {
        cy.get(DOM_ELEMENTS.aliasAddButton).click();
        cy.get(getAliasFirstName(i)).type(`alias${aliasNumber[i]}fname`);
        cy.get(getAliasLastName(i))
          .type(`alias${aliasNumber[i]}lname`)
          .should('have.value', `ALIAS${aliasNumber[i].toUpperCase()}LNAME`);
      }

      cy.get(DOM_ELEMENTS.returnToAccountDetailsButton).click();
      cy.wrap(formSubmitSpy).should('have.been.calledOnce');
    },
  );
});
