export const FORMAT_CHECK = {
  invalidFirstNames:
    "Parent or guardian's first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)",
  invalidLastNames:
    "Parent or guardian's last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)",
  dateOfBirthInFuture: 'Enter a valid date of birth in the past',
  dateOfBirthInvalid: 'Enter date of birth in the format DD/MM/YYYY',
  dateOfBirthNotValid: 'Enter a valid date of birth',
  addressLine1ContainsSpecialCharacters: 'Address line 1 must only contain letters or numbers',
  addressLine2ContainsSpecialCharacters: 'Address line 2 must only contain letters or numbers',
  addressLine3ContainsSpecialCharacters: 'Address line 3 must only contain letters or numbers',
  validNationalInsuranceNumber: 'Enter a National Insurance number in the format AANNNNNNA',
};

export const MAIN_PERSONAL_DETAILS = {
  missingFirstName: "Enter parent or guardian's first name(s)",
  missingLastName: "Enter parent or guardian's last name",
  missingAddressLine1: 'Enter address line 1, typically the building and street',
};

export const ALIAS_PERSONAL_DETAILS = {
  missingAliasOne: 'Enter alias 1 first name(s)',
  missingAliasTwo: 'Enter alias 2 first name(s)',
  missingAliasThree: 'Enter alias 3 first name(s)',
  missingAliasFour: 'Enter alias 4 first name(s)',
  missingAliasFive: 'Enter alias 5 first name(s)',
  missingAliasLastNameOne: 'Enter alias 1 last name',
  missingAliasLastNameTwo: 'Enter alias 2 last name',
  missingAliasLastNameThree: 'Enter alias 3 last name',
  missingAliasLastNameFour: 'Enter alias 4 last name',
  missingAliasLastNameFive: 'Enter alias 5 last name',
};

export const ALIAS_LENGTH_VALIDATION = {
  tooLongAliasOne: 'Alias 1 first name(s) must be 20 characters or fewer',
  tooLongAliasTwo: 'Alias 2 first name(s) must be 20 characters or fewer',
  tooLongAliasThree: 'Alias 3 first name(s) must be 20 characters or fewer',
  tooLongAliasFour: 'Alias 4 first name(s) must be 20 characters or fewer',
  tooLongAliasFive: 'Alias 5 first name(s) must be 20 characters or fewer',
  tooLongAliasLastNameOne: 'Alias 1 last name must be 30 characters or fewer',
  tooLongAliasLastNameTwo: 'Alias 2 last name must be 30 characters or fewer',
  tooLongAliasLastNameThree: 'Alias 3 last name must be 30 characters or fewer',
  tooLongAliasLastNameFour: 'Alias 4 last name must be 30 characters or fewer',
  tooLongAliasLastNameFive: 'Alias 5 last name must be 30 characters or fewer',
};

export const ALIAS_ALPHABETIC_VALIDATION = {
  nonAlphaAliasOne:
    'Alias 1 first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasTwo:
    'Alias 2 first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasThree:
    'Alias 3 first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasFour:
    'Alias 4 first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasFive:
    'Alias 5 first name(s) must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasLastNameOne:
    'Alias 1 last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasLastNameTwo:
    'Alias 2 last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasLastNameThree:
    'Alias 3 last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasLastNameFour:
    'Alias 4 last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
  nonAlphaAliasLastNameFive:
    'Alias 5 last name must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)',
};

export const LENGTH_VALIDATION = {
  firstNameTooLong: "Parent or guardian's first name(s) must be 20 characters or fewer",
  lastNameTooLong: "Parent or guardian's last name must be 30 characters or fewer",
  addressLine1TooLong: 'Address line 1 must be 25 characters or fewer',
  addressLine2TooLong: 'Address line 2 must be 25 characters or fewer',
  addressLine3TooLong: 'Address line 3 must be 13 characters or fewer',
  postcodeTooLong: 'Postcode must be 8 characters or fewer',
  vehicleRegistrationTooLong: 'Registration number must be 11 characters or fewer',
  vehicleMakeTooLong: 'Make and model must be 30 characters or fewer',
};

export const CORRECTION_TEST_MESSAGES = {
  firstNameTooLong: "Parent or guardian's first name(s) must be 20 characters or fewer",
  lastNameTooLong: "Parent or guardian's last name must be 30 characters or fewer",
  addressLine1ContainsSpecialCharacters: 'Address line 1 must only contain letters or numbers',
};
