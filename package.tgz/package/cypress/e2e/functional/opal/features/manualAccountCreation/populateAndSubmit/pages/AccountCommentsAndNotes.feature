@JIRA-LABEL:manual-account-creation
@ManualAccountCreation @AccountCommentsAndNotes @JIRA-EPIC:PO-272 @JIRA-STORY:PO-469 @JIRA-STORY:PO-499 @JIRA-STORY:PO-500
Feature: Manual account creation - Account Comments and Notes
  #This feature file contains tests for the Account Comments and Notes page of the Manual Account Creation journey that cannot be exercised in the component tests #
  #Validation tests are primarily contained in the AccountCommentsAndNotesComponent.cy.ts component tests
  #Tests for conditional rendering (different defendant types) are contained in the AccountCommentsAndNotesComponent.cy.ts component tests

  Background:
    Given I am logged in with email "opal-test@dev.platform.hmcts.net"

  @JIRA-TEST-KEY:PO-5395
  Scenario: Providing account comments and notes updates the task status and persists the data [@PO-272, @PO-344, @PO-345, @PO-469, @PO-499, @PO-500]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    Then the "Account comments and notes" task status is "Not provided"
    When I provide account comments "Test comments" and notes "Test notes"
    And returning to account details the "Account comments and notes" task the status is "Provided"
    When I view the "Account comments and notes" task
    Then the manual account comment and note fields show "Test comments" and "Test notes"

  @JIRA-TEST-KEY:PO-5396
  Scenario: A new manual account starts with comments and notes not provided [@PO-272, @PO-344, @PO-345, @PO-469, @PO-499, @PO-500]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    Then the "Account comments and notes" task status is "Not provided"
    When I view the "Account comments and notes" task
    Then the manual account comment and note fields show "" and ""

  @JIRA-DEFECT:PO-3713 @JIRA-TEST-KEY:PO-5397
  Scenario: Account comments and notes accept commas in both fields [@PO-3713]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    When I provide account comments "O'Neil, note-1." and notes "Account, note-1. O'Neil ok"
    And returning to account details the "Account comments and notes" task the status is "Provided"
    When I view the "Account comments and notes" task
    Then the manual account comment and note fields show "O'Neil, note-1." and "Account, note-1. O'Neil ok"

  @JIRA-DEFECT:PO-3713
  Scenario Outline: Account comments and notes accept commas in each field [@PO-3713]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    When I provide account comments "<comment>" and notes "<note>"
    And returning to account details the "Account comments and notes" task the status is "Provided"
    When I view the "Account comments and notes" task
    Then the manual account comment and note fields show "<comment>" and "<note>"

    @JIRA-TEST-KEY:PO-5398
    Examples:
      | comment            | note                       |
      | O'Neil, comment-1. | Plain note                 |
    @JIRA-TEST-KEY:PO-5399
    Examples:
      | comment            | note                       |
      | Plain comment      | Account, note-1. O'Neil ok |

  @JIRA-DEFECT:PO-3713 @JIRA-TEST-KEY:PO-5400 @JIRA_NFR:PO-2549
  Scenario: Account comments and notes show updated allowed character error messages [@PO-3713, @PO-3415]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    When I provide account comments "Invalid ©µ±ö€" and notes "Invalid ©µ±ö€"
    And I return to account details
    Then the manual account comment validation error is "Add comment must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)"
    And the manual account note validation error is "Add account note must only include letters a to z, numbers 0-9 and certain special characters (such as hyphens, spaces, apostrophes and commas)"

  @JIRA-KEY:POT-5029 @JIRA-TEST-KEY:PO-5401
  Scenario: Unsaved account comments can be kept or discarded [@PO-272, @PO-344, @PO-345, @PO-469, @PO-499, @PO-500]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    And I provide account comments "Test comments" and notes "Test notes"
    And I choose "Cancel" on the unsaved changes prompt for account comments
    Then the manual account comment field shows "Test comments"
    And the manual account note field shows "Test notes"
    When I choose "Ok" on the unsaved changes prompt for account comments
    Then the "Account comments and notes" task status is "Not provided"
    When I view the "Account comments and notes" task
    Then the manual account comment and note fields show "" and ""

  @JIRA-TEST-KEY:PO-5402
  Scenario: Task navigation allows review after all sections are provided [@PO-272, @PO-469, @PO-499, @PO-500]
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    Then the "Account comments and notes" task status is "Not provided"

    And I view the "Court details" task
    And I complete manual court details:
      | LJA               | Avon              |
      | PCR               | 1234              |
      | enforcement court | West London VPFPO |

    And I return to account details
    And I provide manual personal details from account details:
      | field          | value |
      | title          | Mr    |
      | first names    | FNAME |
      | last name      | LNAME |
      | address line 1 | Addr1 |

    And I return to account details
    And I have provided offence details from account details:
      | field          | value               |
      | offence date   | 2 weeks in the past |
      | offence code   | TP11003             |
      | result code    | Fine (FO)           |
      | amount imposed | 200                 |
      | amount paid    | 100                 |

    And I return to account details
    And I have provided manual payment terms:
      | field                 | value                  |
      | collection order      | Yes                    |
      | collection order date | 1 weeks ago            |
      | pay in full by        | 28 weeks in the future |

    And I return to account details
    Then the task statuses are:
      | task             | status   |
      | Court details    | Provided |
      | Personal details | Provided |
      | Offence details  | Provided |
      | Payment terms    | Provided |

    And I view the "Account comments and notes" task
    Then I can proceed to review account details from comments and notes and see the header "Check account details"

  @JIRA-TEST-KEY:PO-5403
  Scenario: Account Comments and Notes - Axe Core
    Given I start a fine manual account for business unit "West London" with defendant type "Adult or youth" and originator type "New"
    When I view the "Account comments and notes" task
    Then I check the page for accessibility
