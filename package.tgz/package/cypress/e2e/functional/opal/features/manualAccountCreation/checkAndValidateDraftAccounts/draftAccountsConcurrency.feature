@JIRA-LABEL:manual-account-creation
@api @concurrency @JIRA-STORY:PO-2117
Feature: Draft Accounts — ETag/If-Match Concurrency

  Background:
    Given I am logged in with email "opal-test@dev.platform.hmcts.net"
    Then I should be on the dashboard


  @JIRA-STORY:PO-2117 @JIRA-EPIC:PO-2220 @JIRA-TEST-KEY:PO-5473
  Scenario: Successful update returns a new strong ETag
    Given a "adultOrYouthOnly" draft account exists with:
      | account_status              | Submitted |
      | account.defendant.forenames | Dave      |
      | account.defendant.surname   | Tag{uniq} |
    Then I am logged in with email "opal-test-10@dev.platform.hmcts.net"
    When I set the last created draft account status to "Publishing Pending"
    Then the last draft update should return a new strong ETag


  @JIRA-STORY:PO-2117 @JIRA-EPIC:PO-2220 @JIRA-TEST-KEY:PO-5474
  Scenario: Stale If-Match results in 409 Conflict
    Given a "adultOrYouthOnly" draft account exists with:
      | account_status              | Submitted      |
      | account.defendant.forenames | Jim            |
      | account.defendant.surname   | Conflict{uniq} |
    Then I am logged in with email "opal-test-10@dev.platform.hmcts.net"

    When I attempt a stale If-Match update on the last draft account with status "Publishing Pending"
    Then the stale If-Match update should return a conflict
