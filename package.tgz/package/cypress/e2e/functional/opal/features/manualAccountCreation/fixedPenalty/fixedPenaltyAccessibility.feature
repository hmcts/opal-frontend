@JIRA-LABEL:manual-account-creation
@JIRA-NFR:PO-2322
Feature: Accessibility Tests for Fixed Penalty Screens
  # This feature file ensures that all screens related to fixed penalty account creation meet accessibility standards using Axe-Core.

  ## Review account screen is covered in the Populate and Submit accessibility tests.

  Background:
    Given I am logged in with email "opal-test@dev.platform.hmcts.net"
    Then I should be on the dashboard

  Scenario Outline: Fixed Penalty details page is accessible for <defendant_type>
    When I start a fixed penalty account for business unit "West London", defendant type "<defendant_type>" and originator type "New"
    Then I check the page for accessibility
    @JIRA-EPIC:PO-2472 @JIRA-TEST-KEY:PO-5309
    Examples: Adult or youth only
      | defendant_type      |
      | Adult or youth only |

    @JIRA-EPIC:PO-2472 @JIRA-TEST-KEY:PO-5310
    Examples: Company
      | defendant_type |
      | Company        |
