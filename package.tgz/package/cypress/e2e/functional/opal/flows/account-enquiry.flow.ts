import { AccountSearchIndividualsActions } from '../actions/search/search.individuals.actions';
import { AccountSearchCompanyActions } from '../actions/search/search.companies.actions';
import { AccountSearchCommonActions } from '../actions/search/search.common.actions';
import { AccountSearchNavActions } from '../actions/search/search.nav.actions';
import { AccountDetailsNotesActions } from '../actions/account-details/details.notes.actions';
import { ResultsActions } from '../actions/search/search.results.actions';
import { AccountDetailsDefendantActions } from '../actions/account-details/details.defendant.actions';
import { AccountDetailsNavActions } from '../actions/account-details/details.nav.actions';
import { AccountDetailsCommentsActions } from '../actions/account-details/details.comments.actions';
import { AccountDetailsAtAGlanceActions } from '../actions/account-details/details.at-a-glance.actions';
import { AccountDetailsParentGuardianActions } from '../actions/account-details/details.parent.guardian.actions';
import { AccountDetailsMinorCreditorActions } from '../actions/account-details/details.minor-creditor.actions';
import { AccountDetailsPaymentTermsActions } from '../actions/account-details/details.payment-terms.actions';
import { AccountDetailsFixedPenaltyActions } from '../actions/account-details/details.fixed-penalty.actions';
import { AccountSearchIndividualsLocators as L } from '../../../../shared/selectors/account-search/account.search.individuals.locators';
import { AccountSearchCompaniesLocators as C } from '../../../../shared/selectors/account-search/account.search.companies.locators';
import { ForceSingleTabNavigation } from '../../../../support/utils/navigation';
import { CommonActions } from '../actions/common/common.actions';
import { EditDefendantDetailsActions } from '../actions/account-details/edit.defendant-details.actions';
import { EditCompanyDetailsActions } from '../actions/account-details/edit.company-details.actions';
import { EditParentGuardianDetailsActions } from '../actions/account-details/edit.parent-guardian-details.actions';
import { EditMinorCreditorDetailsActions } from '../actions/account-details/edit.minor-creditor-details.actions';
import { AccountConvertActions } from '../actions/account-details/convert.account.actions';
import { AccountDetailsEnforcementActions } from '../actions/account-details/details.enforcement.actions';
import { RemoveParentGuardianActions } from '../actions/account-details/remove.parent-guardian.actions';
import { createScopedLogger, createScopedSyncLogger } from '../../../../support/utils/log.helper';
import { EtagUpdate } from '../actions/draft-account/draft-account.api';
import { MINOR_CREDITOR_AMEND_ELEMENTS } from '../../../../shared/selectors/account-enquiry/account.enquiry.minor-creditor-amend.locators';

const logAE = createScopedLogger('AccountEnquiryFlow');
const logAESync = createScopedSyncLogger('AccountEnquiryFlow');

type MinorCreditorAmendmentSearchResult = {
  amendments: Array<Record<string, unknown>>;
  count: number | undefined;
  recordType: string;
};

/**
 * @file AccountEnquiryFlow
 * @description High-level workflow for searching accounts (individuals/companies),
 *              opening the latest result, and asserting/editing details.
 *
 * This flow composes lower-level *Actions* (Page Objects) and keeps tests concise by
 * encapsulating navigation + assertions.
 *
 * @remarks
 * - All public methods include structured logging.
 * - Navigation is forced into a single tab to avoid Cypress multi-window issues.
 * - Results waits & open helpers are centralised in {@link ResultsActions}.
 */
export class AccountEnquiryFlow {
  /** Default timeout (ms) for key waits in this flow. */
  private static readonly WAIT_MS = 15_000;
  /** Timeout (ms) for route transitions back to the defendant details shell. */
  private static readonly DETAILS_NAV_WAIT_MS = 45_000;
  private static readonly BASE_API_PATH = '/opal-fines-service';

  /** Waits for the account header summary call to succeed and the At a glance tab to render. */
  private waitForHeaderSummaryAndAtAGlance(): void {
    cy.wait('@headerSummary', { timeout: AccountEnquiryFlow.WAIT_MS }).then((res) => {
      if (res?.response?.statusCode !== 200) {
        cy.reload();
        cy.wait('@headerSummary', { timeout: AccountEnquiryFlow.WAIT_MS }).its('response.statusCode').should('eq', 200);
      }
    });

    cy.get('app-fines-acc-defendant-details-at-a-glance-tab', { timeout: AccountEnquiryFlow.WAIT_MS }).should(
      'be.visible',
    );
  }

  private readonly searchIndividuals = new AccountSearchIndividualsActions();
  private readonly searchCompany = new AccountSearchCompanyActions();
  private readonly searchNav = new AccountSearchNavActions();
  private readonly searchCommon = new AccountSearchCommonActions();
  private readonly results = new ResultsActions();
  private readonly defendantDetails = new AccountDetailsDefendantActions();
  private readonly parentGuardianDetails = new AccountDetailsParentGuardianActions();
  private readonly minorCreditorDetails = new AccountDetailsMinorCreditorActions();
  private readonly fixedPenaltyDetails = new AccountDetailsFixedPenaltyActions();
  private readonly companyDetails = new EditCompanyDetailsActions();
  private readonly detailsNav = new AccountDetailsNavActions();
  private readonly notes = new AccountDetailsNotesActions();
  private readonly comments = new AccountDetailsCommentsActions();
  private readonly common = new CommonActions();
  private readonly atAGlanceDetails = new AccountDetailsAtAGlanceActions();
  private readonly editDefendantDetailsActions = new EditDefendantDetailsActions();
  private readonly editCompanyDetailsActions = new EditCompanyDetailsActions();
  private readonly editParentGuardianActions = new EditParentGuardianDetailsActions();
  private readonly editMinorCreditorActions = new EditMinorCreditorDetailsActions();
  private readonly paymentTerms = new AccountDetailsPaymentTermsActions();
  private readonly accountConvert = new AccountConvertActions();
  private readonly enforcement = new AccountDetailsEnforcementActions();
  private readonly removeParentGuardian = new RemoveParentGuardianActions();

  /**
   * Ensures the test is on the Individuals Account Search page.
   * If not, it navigates via the dashboard.
   */
  private ensureOnIndividualSearchPage(): void {
    logAE('method', 'ensureOnIndividualSearchPage()');
    cy.get('body').then(($b) => {
      const onSearch = $b.find(L.root).length > 0;
      if (!onSearch) {
        logAE('navigate', 'Returning to Search landing page via HMCTS link (Individuals)');
        this.common.clickHmctsHomeLink();
        this.searchIndividuals.assertOnSearchLandingPage();
      }
    });
  }

  /**
   * Pulls the current `accountNumber` from alias `@etagUpdate` if present.
   * The alias is expected to have a shape like `{ accountNumber: string }`.
   *
   * @returns Chainable resolving to a trimmed account number or `null` when absent/empty.
   */
  private resolveAccountNumberFromAlias(): Cypress.Chainable<string | null> {
    return cy
      .get('@etagUpdate', { timeout: 0 })
      .then((etag: any) => (etag ? (etag.accountNumber ?? null) : null))
      .then((n: string | null) => (n && String(n).trim() ? String(n).trim() : null));
  }

  /**
   * Resolves the current published account id from `@etagUpdate`.
   *
   * @returns Chainable resolving to the numeric account id.
   */
  private resolveAccountIdFromAlias(): Cypress.Chainable<number> {
    return cy.get<EtagUpdate>('@etagUpdate').then((etag) => {
      const accountId = Number(etag?.accountId);
      if (!Number.isFinite(accountId)) {
        throw new Error('Expected @etagUpdate to contain a numeric accountId for direct account navigation.');
      }
      return accountId;
    });
  }

  /**
   * Performs an Individuals search by last name.
   *
   * @param surname - Surname to search for.
   */
  public searchByLastName(surname: string): void {
    logAE('method', 'searchByLastName()');
    logAE('search', 'Searching by last name', { surname });
    this.ensureOnIndividualSearchPage();
    this.searchIndividuals.searchByLastName(surname);
  }

  /**
   * Clicks the latest published account from the current results page.
   *
   * Behaviour:
   *  - If `@etagUpdate` has an `accountNumber` and it's visible on the current page → click it.
   *  - Otherwise → open the first row via {@link ResultsActions.openLatestPublished}.
   *  - If the @etagUpdate account number is not on the current page, we paginate to find it.
   */
  public clickLatestPublishedFromResultsOrAcrossPages(): void {
    logAE('method', 'clickLatestPublishedFromResultsOrAcrossPages()');
    logAE('click', 'Click latest published account or matching @etagUpdate (current page only)');

    cy.intercept('GET', '**/defendant-accounts/**/header-summary').as('headerSummary');
    ForceSingleTabNavigation();
    this.results.waitForResultsTable();

    this.resolveAccountNumberFromAlias().then((accOrNull) => {
      if (!accOrNull) {
        logAE('fallback', 'No @etagUpdate found → opening latest row');
        this.results.openLatestPublished();
        this.waitForHeaderSummaryAndAtAGlance();
        return;
      }

      const acc = accOrNull;
      logAE('match', 'Opening account by number from @etagUpdate', { accountNumber: acc });

      // Wait for the specific account we just created; traverse pagination if needed.
      this.results.openByAccountNumberAcrossPages(acc);
      this.waitForHeaderSummaryAndAtAGlance();
    });
  }

  /**
   * Convenience flow: search by surname (no automatic click).
   *
   * @param surname - Surname to search for.
   */
  public searchBySurname(surname: string): void {
    logAE('method', 'searchBySurname()');
    logAE('flow', 'Search by surname', { surname });
    this.searchByLastName(surname);
  }

  /**
   * Convenience flow: search by surname then open the latest matching account.
   *
   * @param surname - Surname to search for.
   */
  public searchAndClickLatestBySurnameOpenLatestResult(surname: string): void {
    logAE('method', 'searchAndClickLatestBySurnameOpenLatestResult()');
    logAE('flow', 'Search and open latest by surname', { surname });
    this.searchBySurname(surname);
    this.clickLatestPublishedFromResultsOrAcrossPages();
  }

  /**
   * Searches by surname, opens the latest result, and asserts the header text.
   * @param surname - Surname to search for.
   * @param expectedHeader - Expected header text after opening.
   */
  public searchOpenLatestAndAssertHeader(surname: string, expectedHeader: string): void {
    logAE('method', 'searchOpenLatestAndAssertHeader()', { surname, expectedHeader });
    this.searchBySurname(surname);
    this.openLatestAndAssertHeader(expectedHeader);
  }

  /**
   * Opens the latest published account and asserts the header text.
   * @param expectedHeader - Expected header text to match (already resolved for {uniq}).
   */
  public openLatestAndAssertHeader(expectedHeader: string): void {
    logAE('method', 'openLatestAndAssertHeader()', { expectedHeader });
    this.clickLatestPublishedFromResultsOrAcrossPages();
    this.atAGlanceDetails.assertHeaderContains(expectedHeader);
  }

  /**
   * Opens the most recent account from the results (top row) and asserts navigation.
   */
  public openMostRecentFromResults(): void {
    logAE('method', 'openMostRecentFromResults()');
    logAE('open', 'Opening most recent account from results');

    ForceSingleTabNavigation();
    this.results.waitForResultsTable();
    this.results.openLatestPublished();
  }

  /**
   * Opens the most recent account from the Companies results tab and asserts navigation.
   */
  public openMostRecentFromCompaniesResults(): void {
    logAE('method', 'openMostRecentFromCompaniesResults()');
    logAE('open', 'Opening most recent account from Companies results');

    ForceSingleTabNavigation();
    this.results.waitForResultsTable();
    this.results.selectCompaniesTab();
    this.results.assertCompaniesTabSelected();
    this.results.openLatestPublished();
  }

  /**
   * Visits the last created published defendant account details route directly.
   */
  public visitLastCreatedPublishedAccountDetails(): void {
    logAE('method', 'visitLastCreatedPublishedAccountDetails()');
    this.resolveAccountIdFromAlias().then((accountId) => {
      const path = `/fines/account/defendant/${accountId}/details`;
      logAE('navigate', 'Visiting published account details directly', { accountId, path });
      cy.visit(path);
    });
  }

  /**
   * Navigates to the Defendant tab and asserts a specific section header.
   *
   * @param headerText - Expected section header text.
   */
  public goToDefendantDetailsAndAssert(headerText: string): void {
    logAE('method', 'goToDefendantDetailsAndAssert()');
    logAE('navigate', 'Navigating to Defendant tab and asserting section header', { headerText });
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader(headerText);
  }

  /**
   * Asserts the Defendant tab shows the convert-to-company action.
   */
  public assertConvertToCompanyActionVisible(): void {
    logAE('method', 'assertConvertToCompanyActionVisible()');
    this.defendantDetails.assertConvertToCompanyActionVisible();
  }

  /**
   * Asserts the Defendant tab shows the convert-to-individual action.
   */
  public assertConvertToIndividualActionVisible(): void {
    logAE('method', 'assertConvertToIndividualActionVisible()');
    this.defendantDetails.assertConvertToIndividualActionVisible();
  }

  /**
   * Asserts the Defendant tab shows the add parent or guardian action.
   */
  public assertAddParentGuardianActionVisible(): void {
    logAE('method', 'assertAddParentGuardianActionVisible()');
    this.defendantDetails.assertAddParentGuardianActionVisible();
  }

  /**
   * Asserts the Defendant tab does not show the convert-to-company action.
   */
  public assertConvertToCompanyActionNotPresent(): void {
    logAE('method', 'assertConvertToCompanyActionNotPresent()');
    this.defendantDetails.assertConvertToCompanyActionNotPresent();
  }

  /**
   * Asserts the visible convert action is not the company-convert label.
   */
  public assertConvertToCompanyActionTextNotPresent(): void {
    logAE('method', 'assertConvertToCompanyActionTextNotPresent()');
    this.defendantDetails.assertConvertToCompanyActionTextNotPresent();
  }

  /**
   * Opens the convert-to-company confirmation page from the Defendant tab.
   */
  public openConvertToCompanyConfirmation(): void {
    logAE('method', 'openConvertToCompanyConfirmation()');
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.startConvertToCompanyAccount();
  }

  /**
   * Opens the convert-to-individual confirmation page from the Defendant tab.
   */
  public openConvertToIndividualConfirmation(): void {
    logAE('method', 'openConvertToIndividualConfirmation()');
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.startConvertToIndividualAccount();
  }

  /**
   * Opens the add parent or guardian form from the Defendant tab.
   */
  public openAddParentGuardianDetails(): void {
    logAE('method', 'openAddParentGuardianDetails()');
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader('Defendant');
    this.defendantDetails.startAddParentGuardianDetails();
  }

  /**
   * Opens the remove parent or guardian confirmation page from the Parent or guardian tab.
   */
  public openRemoveParentGuardianDetails(): void {
    logAE('method', 'openRemoveParentGuardianDetails()');
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.assertSectionHeader('Parent or guardian details');
    this.parentGuardianDetails.startRemoveParentGuardianDetails();
  }

  /**
   * Asserts the convert-to-company confirmation page.
   *
   * @param expectedCaptionName - Expected defendant name shown in the caption.
   */
  public assertOnConvertToCompanyConfirmation(expectedCaptionName: string): void {
    logAE('method', 'assertOnConvertToCompanyConfirmation()', { expectedCaptionName });
    this.accountConvert.assertOnConvertToCompanyConfirmation(expectedCaptionName);
  }

  /**
   * Confirms the convert-to-company action.
   */
  public confirmConvertToCompanyAccount(): void {
    logAE('method', 'confirmConvertToCompanyAccount()');
    this.accountConvert.confirmConvertToCompany();
  }

  /**
   * Cancels the convert-to-company action.
   */
  public cancelConvertToCompanyAccount(): void {
    logAE('method', 'cancelConvertToCompanyAccount()');
    this.accountConvert.cancelConvertToCompany();
  }

  /**
   * Asserts the convert-to-individual confirmation page.
   *
   * @param expectedCaptionName - Expected company name shown in the caption.
   */
  public assertOnConvertToIndividualConfirmation(expectedCaptionName: string): void {
    logAE('method', 'assertOnConvertToIndividualConfirmation()', { expectedCaptionName });
    this.accountConvert.assertOnConvertToIndividualConfirmation(expectedCaptionName);
  }

  /**
   * Confirms the convert-to-individual action.
   */
  public confirmConvertToIndividualAccount(): void {
    logAE('method', 'confirmConvertToIndividualAccount()');
    this.accountConvert.confirmConvertToIndividual();
  }

  /**
   * Cancels the convert-to-individual action.
   */
  public cancelConvertToIndividualAccount(): void {
    logAE('method', 'cancelConvertToIndividualAccount()');
    this.accountConvert.cancelConvertToIndividual();
  }

  /**
   * Asserts the Company details form contains the expected pre-populated values.
   *
   * @param expectedFieldValues - Key/value map of ticket field labels to expected values.
   */
  public assertCompanyDetailsPrefilledValues(expectedFieldValues: Record<string, string>): void {
    logAE('method', 'assertCompanyDetailsPrefilledValues()', expectedFieldValues);
    this.editCompanyDetailsActions.assertPrefilledFieldValues(expectedFieldValues);
  }

  /**
   * Asserts the convert flow lands on the Company details convert route.
   */
  public assertOnCompanyDetailsConvertRoute(): void {
    logAE('method', 'assertOnCompanyDetailsConvertRoute()');
    this.editCompanyDetailsActions.assertOnConvertRoute();
  }

  /**
   * Asserts the convert flow lands on the Defendant details convert route.
   */
  public assertOnDefendantDetailsConvertRoute(): void {
    logAE('method', 'assertOnDefendantDetailsConvertRoute()');
    this.editDefendantDetailsActions.assertOnConvertRoute();
  }

  /**
   * Asserts the Defendant details form contains the expected pre-populated values.
   *
   * @param expectedFieldValues - Key/value map of ticket field labels to expected values.
   */
  public assertDefendantDetailsPrefilledValues(expectedFieldValues: Record<string, string>): void {
    logAE('method', 'assertDefendantDetailsPrefilledValues()', expectedFieldValues);
    this.editDefendantDetailsActions.assertPrefilledFieldValues(expectedFieldValues);
  }

  /**
   * Completes the convert-to-company form by providing a company name and saving the form.
   *
   * @param companyName - Company name to use for the converted account.
   */
  public completeConvertToCompany(companyName: string): void {
    logAE('method', 'completeConvertToCompany()', { companyName });
    this.editCompanyDetailsActions.editCompanyName(companyName);
    this.editCompanyDetailsActions.saveChanges();
  }

  /**
   * Completes the convert-to-individual form by filling the required personal details and saving.
   *
   * @param details - Title and name fields required for the converted individual account.
   * @param details.title - Title to select for the converted individual account.
   * @param details.firstName - First name to enter for the converted individual account.
   * @param details.lastName - Last name to enter for the converted individual account.
   */
  public completeConvertToIndividual(details: { title: string; firstName: string; lastName: string }): void {
    logAE('method', 'completeConvertToIndividual()', details);
    this.editDefendantDetailsActions.selectTitle(details.title);
    this.editDefendantDetailsActions.updateFirstName(details.firstName);
    this.editDefendantDetailsActions.updateSurname(details.lastName);
    this.editDefendantDetailsActions.saveChanges();
  }

  /**
   * Asserts the account details success banner contains the expected conversion message.
   *
   * @param expected - Expected banner text.
   */
  public assertAccountConversionSuccessMessage(expected: string): void {
    logAE('method', 'assertAccountConversionSuccessMessage()', { expected });
    this.detailsNav.assertSuccessBannerText(expected);
  }

  /**
   * Asserts the company summary card is visible in the Defendant tab.
   */
  public assertCompanySummaryVisible(): void {
    logAE('method', 'assertCompanySummaryVisible()');
    this.editCompanyDetailsActions.assertCompanySummaryVisible();
  }

  /**
   * Asserts the company summary card is not visible in the Defendant tab.
   */
  public assertCompanySummaryNotPresent(): void {
    logAE('method', 'assertCompanySummaryNotPresent()');
    this.editCompanyDetailsActions.assertCompanySummaryNotPresent();
  }

  /**
   * Asserts the defendant summary card is visible in the Defendant tab.
   */
  public assertDefendantSummaryVisible(): void {
    logAE('method', 'assertDefendantSummaryVisible()');
    this.defendantDetails.assertDefendantSummaryVisible();
  }

  /**
   * Asserts the defendant summary card is not visible in the Defendant tab.
   */
  public assertDefendantSummaryNotPresent(): void {
    logAE('method', 'assertDefendantSummaryNotPresent()');
    this.defendantDetails.assertDefendantSummaryNotPresent();
  }

  /**
   * Asserts the primary email address shown in the contact card contains the expected value.
   *
   * @param expected - Expected email text.
   */
  public assertPrimaryEmailContains(expected: string): void {
    logAE('method', 'assertPrimaryEmailContains()', { expected });
    this.defendantDetails.assertPrimaryEmailContains(expected);
  }

  /**
   * Navigates to the Parent/Guardian tab and asserts a specific section header.
   *
   * @param headerText - Expected section header text.
   */
  public goToParentGuardianDetailsAndAssert(headerText: string): void {
    logAE('method', 'goToParentGuardianDetailsAndAssert()');
    logAE('navigate', 'Navigating to Parent/Guardian tab and asserting section header', { headerText });
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.assertSectionHeader(headerText);
  }

  /**
   * Asserts the add parent or guardian route is active and the information banner is shown.
   */
  public assertOnAddParentGuardianDetailsPage(): void {
    logAE('method', 'assertOnAddParentGuardianDetailsPage()');
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.assertInformationBannerText(
      'These details are for information only. The youth defendant still pays.',
    );
  }

  /**
   * Asserts the Parent or guardian tab shows the remove action.
   */
  public assertRemoveParentGuardianActionVisible(): void {
    logAE('method', 'assertRemoveParentGuardianActionVisible()');
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.assertRemoveParentGuardianActionVisible();
  }

  /**
   * Asserts the remove parent or guardian confirmation page is visible.
   *
   * @param expectedIdentifierText - Expected account identifier text fragment.
   */
  public assertOnRemoveParentGuardianPage(expectedIdentifierText: string): void {
    logAE('method', 'assertOnRemoveParentGuardianPage()', { expectedIdentifierText });
    this.removeParentGuardian.assertOnRemoveParentGuardianConfirmation(expectedIdentifierText);
  }
  /**
   * Asserts the amend parent or guardian route is active and the information banner is shown.
   */
  public assertOnAmendParentGuardianDetailsPage(): void {
    logAE('method', 'assertOnAmendParentGuardianDetailsPage()');
    this.editParentGuardianActions.assertHeader({ route: 'amend' });
    this.editParentGuardianActions.assertInformationBannerText(
      'These details are for information only. The youth defendant still pays.',
    );
  }

  /**
   * Navigates to the Fixed penalty tab and asserts a specific section header.
   *
   * @param headerText - Expected section header text.
   */
  public goToFixedPenaltyDetailsAndAssert(headerText: string): void {
    logAE('method', 'goToFixedPenaltyDetailsAndAssert()');
    logAE('navigate', 'Navigating to Fixed penalty tab and asserting section header', { headerText });
    this.detailsNav.goToFixedPenaltyTab();
    this.fixedPenaltyDetails.assertSectionHeader(headerText);
  }

  /**
   * Navigates to the Payment terms tab and asserts it is active.
   */
  public goToPaymentTermsTab(): void {
    logAE('method', 'goToPaymentTermsTab()');
    logAE('navigate', 'Navigating to Payment terms tab');
    this.detailsNav.goToPaymentTermsTab();
    this.detailsNav.assertPaymentTermsTabIsActive();
  }

  /**
   * Navigates to the Creditor tab and asserts it is active.
   */
  public goToCreditorTab(): void {
    logAE('method', 'goToCreditorTab()');
    logAE('navigate', 'Navigating to Creditor tab');
    this.detailsNav.goToCreditorTab();
    this.detailsNav.assertCreditorTabIsActive();
  }

  /**
   * Asserts the amend minor creditor route is active and the form heading is shown.
   */
  public assertOnAmendMinorCreditorDetailsPage(): void {
    logAE('method', 'assertOnAmendMinorCreditorDetailsPage()');
    this.editMinorCreditorActions.assertHeader({ route: 'amend' });
  }

  /**
   * Asserts the Payment terms tab is active.
   */
  public assertPaymentTermsTabIsActive(): void {
    logAE('method', 'assertPaymentTermsTabIsActive()');
    this.detailsNav.assertPaymentTermsTabIsActive();
  }

  /**
   * Opens the amend payment terms form from the Payment terms tab.
   */
  public openPaymentTermsAmendForm(): void {
    logAE('method', 'openPaymentTermsAmendForm()');
    this.paymentTerms.openChangeLink();
    this.paymentTerms.assertAmendFormVisible();
  }

  /**
   * Navigates to the Enforcement tab and asserts it is active.
   */
  public goToEnforcementTab(): void {
    logAE('method', 'goToEnforcementTab()');
    logAE('navigate', 'Navigating to Enforcement tab');
    this.detailsNav.goToEnforcementTab();
    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Opens the add enforcement override form from the Enforcement tab.
   */
  public openAddEnforcementOverrideForm(): void {
    logAE('method', 'openAddEnforcementOverrideForm()');
    this.enforcement.openAddEnforcementOverrideForm();
    this.enforcement.assertAddEnforcementOverrideFormVisible();
  }

  /**
   * Opens the add enforcement action form from the Enforcement tab.
   */
  public openAddEnforcementActionForm(): void {
    logAE('method', 'openAddEnforcementActionForm()');
    this.enforcement.openAddEnforcementActionForm();
    this.enforcement.assertAddEnforcementActionFormVisible();
  }

  /**
   * Asserts the add enforcement action form is visible.
   */
  public assertAddEnforcementActionFormVisible(): void {
    logAE('method', 'assertAddEnforcementActionFormVisible()');
    this.enforcement.assertAddEnforcementActionFormVisible();
  }

  /**
   * Asserts the add enforcement action form is visible.
   */
  public assertAddNewEnforcementActionFormVisible(): void {
    logAE('method', 'assertAddNewEnforcementActionFormVisible()');
    this.enforcement.assertAddNewEnforcementActionFormVisible();
  }

  /**
   * Opens the remove enforcement hold form from the Enforcement tab.
   */
  public openRemoveEnforcementHoldForm(): void {
    logAE('method', 'openRemoveEnforcementHoldForm()');
    this.enforcement.openRemoveEnforcementHoldForm();
    this.enforcement.assertRemoveEnforcementHoldFormVisible();
  }

  /**
   * Asserts the remove enforcement hold account identifier.
   *
   * @param expected - Expected account identifier caption text.
   */
  public assertRemoveEnforcementHoldAccountIdentifier(expected: string): void {
    logAE('method', 'assertRemoveEnforcementHoldAccountIdentifier()', { expected });
    this.enforcement.assertRemoveEnforcementHoldAccountIdentifier(expected);
  }

  /**
   * Submits the add enforcement action form.
   */
  public submitAddEnforcementActionForm(): void {
    logAE('method', 'submitAddEnforcementActionForm()');
    this.enforcement.submitAddEnforcementActionForm();
  }

  /**
   * Opens the Change Collection Order status form from the Enforcement tab.
   */
  public openChangeCollectionOrderForm(): void {
    logAE('method', 'openChangeCollectionOrderForm()');
    this.enforcement.openChangeCollectionOrderForm();
  }

  /**
   * Asserts the Change Collection Order status form is visible.
   */
  public assertChangeCollectionOrderFormVisible(): void {
    logAE('method', 'assertChangeCollectionOrderFormVisible()');
    this.enforcement.assertChangeCollectionOrderFormVisible();
  }

  /**
   * Asserts the account identifier shown on the Change Collection Order status page.
   *
   * @param expected - Expected account identifier text.
   */
  public assertChangeCollectionOrderAccountIdentifier(expected: string): void {
    logAE('method', 'assertChangeCollectionOrderAccountIdentifier()', { expected });
    this.enforcement.assertChangeCollectionOrderAccountIdentifier(expected);
  }

  /**
   * Selects a Collection Order status option on the change form.
   *
   * @param option - Visible radio label to select.
   */
  public selectChangeCollectionOrderStatus(option: string): void {
    logAE('method', 'selectChangeCollectionOrderStatus()', { option });
    this.enforcement.selectCollectionOrderStatus(option);
  }

  /**
   * Submits the Change Collection Order status form.
   */
  public submitChangeCollectionOrderForm(): void {
    logAE('method', 'submitChangeCollectionOrderForm()');
    this.enforcement.submitChangeCollectionOrderForm();
  }

  /**
   * Cancels the Change Collection Order status form without making changes.
   */
  public cancelChangeCollectionOrderFormWithoutChanges(): void {
    logAE('method', 'cancelChangeCollectionOrderFormWithoutChanges()');
    this.enforcement.cancelChangeCollectionOrderForm();
    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Cancels the Change Collection Order status form after making changes and chooses to stay on the page.
   */
  public cancelChangeCollectionOrderFormAndStay(): void {
    logAE('method', 'cancelChangeCollectionOrderFormAndStay()');
    this.common.confirmNextUnsavedChanges(false);
    this.enforcement.cancelChangeCollectionOrderForm();
    this.enforcement.assertChangeCollectionOrderFormVisible();
  }

  /**
   * Asserts the Collection Order success banner text.
   *
   * @param expected - Expected success banner message.
   */
  public assertCollectionOrderSuccessBanner(expected: string): void {
    logAE('method', 'assertCollectionOrderSuccessBanner()', { expected });
    this.enforcement.assertCollectionOrderSuccessBannerText(expected);
  }

  /**
   * Asserts the Collection Order summary value on the Enforcement tab.
   *
   * @param expected - Expected Collection Order summary value.
   */
  public assertCollectionOrderSummary(expected: string): void {
    logAE('method', 'assertCollectionOrderSummary()', { expected });
    this.enforcement.assertCollectionOrderSummary(expected);
  }

  /**
   * Selects an enforcement override code on the add form.
   *
   * @param resultCode - Enforcement override result code.
   */
  public selectEnforcementOverride(resultCode: string): void {
    logAE('method', 'selectEnforcementOverride()', { resultCode });
    this.enforcement.selectEnforcementOverride(resultCode);
  }

  /**
   * Selects an enforcement action code on the add form.
   *
   * @param resultCode - Enforcement action result code.
   */
  public selectEnforcementAction(resultCode: string): void {
    logAE('method', 'selectEnforcementAction()', { resultCode });
    this.enforcement.selectEnforcementAction(resultCode);
  }

  /**
   * Enters a reason on the add enforcement action details form.
   *
   * @param reason - Enforcement action reason text.
   */
  public enterEnforcementActionReason(reason: string): void {
    logAE('method', 'enterEnforcementActionReason()', { reason });
    this.enforcement.enterEnforcementActionReason(reason);
  }

  /**
   * Chooses whether to change existing payment terms on the add enforcement action details form.
   *
   * @param option - Visible option text, usually "Yes" or "No".
   */
  public chooseChangeExistingPaymentTerms(option: string): void {
    logAE('method', 'chooseChangeExistingPaymentTerms()', { option });
    this.enforcement.chooseChangeExistingPaymentTerms(option);
  }

  /**
   * Asserts the enforcement action added success banner text.
   *
   * @param expected - Expected success banner message.
   */
  public assertEnforcementActionSuccessBanner(expected: string): void {
    logAE('method', 'assertEnforcementActionSuccessBanner()', { expected });
    this.enforcement.assertSuccessBannerText(expected);
  }

  /**
   * Selects a Local Justice Area on the add form.
   *
   * @param localJusticeArea - Visible LJA option text.
   */
  public selectEnforcementOverrideLocalJusticeArea(localJusticeArea: string): void {
    logAE('method', 'selectEnforcementOverrideLocalJusticeArea()', { localJusticeArea });
    this.enforcement.selectLocalJusticeArea(localJusticeArea);
  }

  /**
   * Selects an enforcer on the add form.
   *
   * @param enforcer - Visible enforcer option text.
   */
  public selectEnforcementOverrideEnforcer(enforcer: string): void {
    logAE('method', 'selectEnforcementOverrideEnforcer()', { enforcer });
    this.enforcement.selectEnforcer(enforcer);
  }

  /**
   * Submits the add enforcement override form and stores the request body for later assertions.
   */
  public submitAddEnforcementOverride(): void {
    logAE('method', 'submitAddEnforcementOverride()');

    this.interceptEnforcementOverrideSave();
    this.enforcement.submitAddEnforcementOverride();

    cy.wait('@enforcementOverrideSave').then(({ request }) => {
      cy.wrap(request.body, { log: false }).as('enforcementOverrideSaveBody');
    });

    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Cancels the add enforcement override form after confirming unsaved changes should be discarded.
   */
  public cancelAddEnforcementOverrideAndDiscardChanges(): void {
    logAE('method', 'cancelAddEnforcementOverrideAndDiscardChanges()');

    this.common.confirmNextUnsavedChanges(true);
    this.enforcement.cancelAddEnforcementOverride();
    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Asserts the Enforcement tab is active and visible.
   */
  public assertEnforcementTabIsActive(): void {
    logAE('method', 'assertEnforcementTabIsActive()');
    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Asserts the enforcement override success banner text.
   *
   * @param expected - Expected success banner message.
   */
  public assertEnforcementOverrideSuccessBanner(expected: string): void {
    logAE('method', 'assertEnforcementOverrideSuccessBanner()', { expected });
    this.enforcement.assertSuccessBannerText(expected);
  }

  /**
   * Asserts the enforcement hold success banner text.
   *
   * @param expected - Expected success banner message.
   */
  public assertEnforcementHoldSuccessBanner(expected: string): void {
    logAE('method', 'assertEnforcementHoldSuccessBanner()', { expected });
    this.enforcement.assertSuccessBannerText(expected);
  }

  /**
   * Opens the change enforcement court form from the Enforcement tab.
   */
  public openChangeEnforcementCourtForm(): void {
    logAE('method', 'openChangeEnforcementCourtForm()');
    this.enforcement.openChangeEnforcementCourtForm();
    this.enforcement.assertChangeEnforcementCourtFormVisible();
  }

  /**
   * Changes the enforcement court to a different available value and returns to the Enforcement tab.
   */
  public changeEnforcementCourtToDifferentValue(): void {
    logAE('method', 'changeEnforcementCourtToDifferentValue()');

    this.enforcement.storeCurrentEnforcementCourtValue('originalEnforcementCourt');
    this.openChangeEnforcementCourtForm();
    this.enforcement.selectDifferentEnforcementCourt('originalEnforcementCourt', 'selectedEnforcementCourt');
    this.enforcement.submitChangeEnforcementCourt();

    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Saves the currently displayed enforcement court value again and returns to the Enforcement tab.
   */
  public saveSameEnforcementCourtValueAgain(): void {
    logAE('method', 'saveSameEnforcementCourtValueAgain()');

    this.enforcement.storeCurrentEnforcementCourtValue('selectedEnforcementCourt');
    this.openChangeEnforcementCourtForm();
    this.enforcement.selectEnforcementCourtFromAlias('selectedEnforcementCourt');
    this.enforcement.submitChangeEnforcementCourt();

    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Selects a different enforcement court value, cancels, and confirms leaving via the route guard.
   */
  public cancelDirtyChangeEnforcementCourtAndDiscardChanges(): void {
    logAE('method', 'cancelDirtyChangeEnforcementCourtAndDiscardChanges()');

    this.enforcement.selectDifferentEnforcementCourt('selectedEnforcementCourt', 'unsavedEnforcementCourt');
    this.common.cancelEditing(true);

    cy.document({ timeout: AccountEnquiryFlow.DETAILS_NAV_WAIT_MS })
      .its('readyState')
      .should('match', /interactive|complete/);

    // If the app didn’t redirect after OK, fall back to going back
    cy.location('href', { timeout: AccountEnquiryFlow.DETAILS_NAV_WAIT_MS }).then((href) => {
      if (href.includes('/enforcement/court/change')) {
        cy.go('back');
      }
    });

    this.detailsNav.assertEnforcementTabIsActive();
    this.enforcement.assertEnforcementTabVisible();
  }

  /**
   * Asserts the enforcement court summary matches the selected value stored during the test.
   */
  public assertSelectedEnforcementCourtSummary(): void {
    logAE('method', 'assertSelectedEnforcementCourtSummary()');
    this.enforcement.assertEnforcementCourtMatchesAlias('selectedEnforcementCourt');
  }

  /**
   * Asserts the enforcement court success banner text.
   *
   * @param expected - Expected success banner message.
   */
  public assertEnforcementCourtSuccessBanner(expected: string): void {
    logAE('method', 'assertEnforcementCourtSuccessBanner()', { expected });
    this.enforcement.assertSuccessBannerText(expected);
  }

  /**
   * Asserts the enforcement success banner is not displayed.
   */
  public assertEnforcementSuccessBannerNotVisible(): void {
    logAE('method', 'assertEnforcementSuccessBannerNotVisible()');
    this.enforcement.assertSuccessBannerNotVisible();
  }

  /**
   * Asserts the intercepted enforcement override save payload.
   *
   * @param expected - Expected payload values.
   * @param expected.overrideId - Expected enforcement override result id.
   * @param expected.enforcerId - Expected enforcer id.
   * @param expected.ljaId - Expected local justice area id.
   */
  public assertEnforcementOverrideSaveRequest(expected: {
    overrideId?: string;
    enforcerId?: string;
    ljaId?: string;
  }): void {
    logAE('method', 'assertEnforcementOverrideSaveRequest()', expected);

    cy.get('@enforcementOverrideSaveBody').then((body: any) => {
      if (expected.overrideId) {
        expect(body).to.have.nested.property(
          'enforcement_override.enforcement_override_result.enforcement_override_result_id',
          expected.overrideId,
        );
      }

      if (expected.ljaId) {
        expect(String(body?.enforcement_override?.lja?.lja_id)).to.eq(expected.ljaId);
      }

      if (expected.enforcerId) {
        expect(String(body?.enforcement_override?.enforcer?.enforcer_id)).to.eq(expected.enforcerId);
      }
    });
  }

  /**
   * Asserts the enforcement override summary card values.
   *
   * @param expected - Expected summary values.
   * @param expected.override - Expected enforcement override display text.
   * @param expected.enforcer - Expected enforcer display text.
   * @param expected.lja - Expected LJA display text.
   */
  public assertEnforcementOverrideSummary(expected: { override?: string; enforcer?: string; lja?: string }): void {
    logAE('method', 'assertEnforcementOverrideSummary()', expected);
    this.enforcement.assertEnforcementOverrideSummary(expected);
  }

  /**
   * Asserts the last enforcement action summary value shown on the Enforcement tab.
   *
   * @param expected - Expected enforcement action text.
   */
  public assertEnforcementActionSummary(expected: string): void {
    logAE('method', 'assertEnforcementActionSummary()', { expected });
    this.enforcement.assertEnforcementActionSummary(expected);
  }

  /**
   * Submits instalments-only payment terms with a payment card request.
   * Stores the POST request body for later assertions.
   */
  public submitInstalmentsOnlyPaymentTermsWithCardRequest(): void {
    logAE('method', 'submitInstalmentsOnlyPaymentTermsWithCardRequest()');

    this.interceptPaymentTermsSave();

    this.paymentTerms.fillInstalmentsOnlyPaymentTerms({
      instalmentAmount: '45',
      frequencyCode: 'M',
      startDate: '15/01/2026',
      reason: 'Updated instalments',
      requestPaymentCard: true,
    });
    this.paymentTerms.submitChanges();

    cy.wait('@paymentTermsSave').then(({ request }) => {
      cy.wrap(request.body, { log: false }).as('paymentTermsSaveBody');
      expect(request.body).to.have.nested.property('payment_terms.payment_terms_type.payment_terms_type_code', 'I');
      expect(request.body).to.have.nested.property('payment_terms.instalment_period.instalment_period_code', 'M');
      expect(request.body).to.have.nested.property('payment_terms.effective_date', '2026-01-15');
      expect(request.body).to.have.property('request_payment_card', true);
      expect(Number(request.body?.payment_terms?.instalment_amount), 'instalment amount').to.equal(45);
    });

    this.detailsNav.assertPaymentTermsTabIsActive();
  }

  /**
   * Cancels payment terms amendments and confirms no save request was sent.
   */
  public cancelPaymentTermsAmendment(): void {
    logAE('method', 'cancelPaymentTermsAmendment()');

    this.interceptPaymentTermsSave();
    this.common.confirmNextUnsavedChanges(true);

    this.paymentTerms.fillInstalmentsOnlyPaymentTerms({
      instalmentAmount: '50',
      frequencyCode: 'M',
      startDate: '20/01/2026',
      reason: 'Cancel changes',
    });
    this.paymentTerms.cancelChanges();

    this.detailsNav.assertPaymentTermsTabIsActive();
    cy.get('@paymentTermsSave.all').should('have.length', 0);
  }

  /**
   * Asserts payment terms summary values for instalments-only payments.
   * @param expected - Expected summary values.
   * @param expected.amount - Instalment amount.
   * @param expected.frequency - Instalment frequency.
   * @param expected.startDate - Instalment start date.
   */
  public assertPaymentTermsInstalmentsSummary(expected: {
    amount: string;
    frequency: string;
    startDate: string;
  }): void {
    logAE('method', 'assertPaymentTermsInstalmentsSummary()', expected);
    this.paymentTerms.assertInstalmentSummary(expected);
  }

  /**
   * Asserts the pay by date value on the payment terms tab.
   * @param expected - Expected pay by date value.
   */
  public assertPaymentTermsPayByDate(expected: string): void {
    logAE('method', 'assertPaymentTermsPayByDate()', { expected });
    this.paymentTerms.assertPayByDate(expected);
  }

  /**
   * Asserts that instalment rows are not present on the payment terms tab.
   */
  public assertPaymentTermsInstalmentsAbsent(): void {
    logAE('method', 'assertPaymentTermsInstalmentsAbsent()');
    this.paymentTerms.assertInstalmentRowsNotPresent();
  }

  /**
   * Asserts the payment terms save request included a payment card request.
   */
  public assertPaymentTermsSaveRequestedPaymentCard(): void {
    logAE('method', 'assertPaymentTermsSaveRequestedPaymentCard()');

    cy.get('@paymentTermsSaveBody').then((body) => {
      expect(body).to.have.property('request_payment_card', true);
    });
  }

  /**
   * Verifies the last enforcement value is cleared after saving payment terms.
   */
  public verifyPaymentTermsLastEnforcementCleared(): void {
    logAE('method', 'verifyPaymentTermsLastEnforcementCleared()');

    this.extractDefendantAccountIdFromUrl().then((defendantAccountId) => {
      cy.request({
        method: 'GET',
        url: `${AccountEnquiryFlow.BASE_API_PATH}/defendant-accounts/${defendantAccountId}/payment-terms/latest`,
        headers: this.getApiHeaders(),
        failOnStatusCode: false,
      }).then((resp) => {
        expect(resp.status, 'GET payment-terms/latest status').to.eq(200);
        expect(resp.body?.last_enforcement, 'last_enforcement should be null').to.be.null;
      });
    });
  }

  /**
   * Starts editing defendant details and changes the first name field.
   *
   * @param value - New first name value.
   */
  public editDefendantAndChangeFirstName(value: string): void {
    logAE('method', 'editDefendantAndChangeFirstName()');
    logAE('edit', 'Editing defendant first name', { value });
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader('Defendant');
    this.defendantDetails.change();
    this.editDefendantDetailsActions.updateFirstName(value);
  }

  /**
   * Opens defendant details edit mode without making any changes.
   */
  public editDefendantWithoutChanges(): void {
    logAE('method', 'editDefendantWithoutChanges()');
    logAE('action', 'Opening defendant details edit mode without making changes');
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader('Defendant');
    this.defendantDetails.change();
    this.editDefendantDetailsActions.assertStillOnEditPage();
  }

  /**
   * Starts editing parent/guardian details and changes the first name field.
   *
   * @param value - New first name value.
   */
  public editParentGuardianAndChangeFirstName(value: string): void {
    logAE('method', 'editParentGuardianAndChangeFirstName()');
    logAE('edit', 'Editing parent/guardian first name', { value });
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.change();
    this.editParentGuardianActions.assertHeader();
    this.editParentGuardianActions.editFirstNames(value);
  }

  /**
   * Opens parent/guardian details edit mode without making any changes.
   */
  public editParentGuardianDetailsWithoutChanges(): void {
    logAE('method', 'editParentGuardianDetailsWithoutChanges()');
    logAE('action', 'Opening parent/guardian details edit mode without making changes');
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.change();
    this.editParentGuardianActions.assertStillOnEditPage();
  }

  /**
   * Opens the non-paying parent/guardian change screen from the Parent or guardian tab.
   */
  public openNonPayingParentGuardianChangeForm(): void {
    logAE('method', 'openNonPayingParentGuardianChangeForm()');
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.change();
    this.assertOnAmendParentGuardianDetailsPage();
  }

  /**
   * Opens the amend minor creditor screen from the Creditor tab.
   */
  public openMinorCreditorChangeForm(): void {
    logAE('method', 'openMinorCreditorChangeForm()');
    this.detailsNav.goToCreditorTab();
    this.minorCreditorDetails.assertSectionHeader('Creditor Details');
    this.minorCreditorDetails.change({ formSelector: MINOR_CREDITOR_AMEND_ELEMENTS.form });
    this.assertOnAmendMinorCreditorDetailsPage();
  }

  /**
   * Enters a first name on the add parent or guardian form.
   *
   * @param value - New first name value.
   */
  public enterAddParentGuardianFirstName(value: string): void {
    logAE('method', 'enterAddParentGuardianFirstName()', { value });
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.editFirstNames(value);
  }

  /**
   * Enters a last name on the add parent or guardian form.
   *
   * @param value - Last name value.
   */
  public enterAddParentGuardianLastName(value: string): void {
    logAE('method', 'enterAddParentGuardianLastName()', { value });
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.editLastName(value);
  }

  /**
   * Enters a first name on the amend parent or guardian form.
   *
   * @param value - New first name value.
   */
  public enterAmendParentGuardianFirstName(value: string): void {
    logAE('method', 'enterAmendParentGuardianFirstName()', { value });
    this.assertOnAmendParentGuardianDetailsPage();
    this.editParentGuardianActions.editFirstNames(value);
  }

  /**
   * Enters a first name on the amend minor creditor form.
   *
   * @param value - New first name value.
   */
  public enterAmendMinorCreditorFirstName(value: string): void {
    logAE('method', 'enterAmendMinorCreditorFirstName()', { value });
    this.assertOnAmendMinorCreditorDetailsPage();
    this.editMinorCreditorActions.editFirstNames(value);
  }

  /**
   * Opens the amend minor creditor form, updates the first name, and saves.
   *
   * @param value - New first name value.
   */
  public amendMinorCreditorFirstNameAndSave(value: string): void {
    logAE('method', 'amendMinorCreditorFirstNameAndSave()', { value });
    this.openMinorCreditorChangeForm();
    this.editMinorCreditorActions.editFirstNames(value);
    this.editMinorCreditorActions.saveChanges();
  }

  /**
   * Opens the amend minor creditor form, updates the first name, and discards the changes.
   *
   * @param value - New first name value.
   */
  public amendMinorCreditorFirstNameAndDiscard(value: string): void {
    logAE('method', 'amendMinorCreditorFirstNameAndDiscard()', { value });
    this.openMinorCreditorChangeForm();
    this.editMinorCreditorActions.editFirstNames(value);
    this.common.cancelEditing(true);
  }

  /**
   * Opens the amend minor creditor form, updates the first name, and attempts to save.
   *
   * @param value - New first name value.
   */
  public attemptToAmendMinorCreditorFirstNameAndSave(value: string): void {
    logAE('method', 'attemptToAmendMinorCreditorFirstNameAndSave()', { value });
    this.openMinorCreditorChangeForm();
    this.editMinorCreditorActions.editFirstNames(value);
    this.editMinorCreditorActions.saveChanges();
  }

  /**
   * Updates the first name on the currently open amend minor creditor form and attempts to save.
   *
   * @param value - New first name value.
   */
  public attemptToSaveCurrentMinorCreditorAmendFormWithFirstName(value: string): void {
    logAE('method', 'attemptToSaveCurrentMinorCreditorAmendFormWithFirstName()', { value });
    this.assertOnAmendMinorCreditorDetailsPage();
    this.editMinorCreditorActions.editFirstNames(value);
    this.editMinorCreditorActions.saveChanges();
  }

  /**
   * Enters a last name on the parent or guardian form.
   *
   * @param value - New last name value.
   */
  public enterParentGuardianLastName(value: string): void {
    logAE('method', 'enterParentGuardianLastName()', { value });
    this.editParentGuardianActions.editLastName(value);
  }

  /**
   * Enters address line 1 on the add parent or guardian form.
   *
   * @param value - Address line 1 value.
   */
  public enterAddParentGuardianAddressLine1(value: string): void {
    logAE('method', 'enterAddParentGuardianAddressLine1()', { value });
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.editAddressLine1(value);
  }

  /**
   * Enters address line 1 on the parent or guardian form.
   *
   * @param value - New address line 1 value.
   */
  public enterParentGuardianAddressLine1(value: string): void {
    logAE('method', 'enterParentGuardianAddressLine1()', { value });
    this.editParentGuardianActions.editAddressLine1(value);
  }

  /**
   * Starts editing company details and changes the company name field.
   *
   * @param value - New company name value.
   */
  public editCompanyDetailsAndChangeName(value: string): void {
    logAE('method', 'editCompanyDetailsAndChangeName()');
    logAE('edit', 'Editing company name', { value });

    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader('Company');
    this.defendantDetails.change();
    this.editCompanyDetailsActions.editCompanyName(value);
  }

  /**
   * Opens company details edit mode without making any changes.
   */
  public editCompanyDetailsWithoutChanges(): void {
    logAE('method', 'editCompanyDetailsWithoutChanges()');
    logAE('action', 'Opening company details edit mode without making changes');
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertSectionHeader('Company');
    this.defendantDetails.change();
    this.editCompanyDetailsActions.assertStillOnEditPage();
  }

  /**
   * Saves the defendant details after editing.
   */
  public saveDefendantDetails(): void {
    logAE('method', 'saveDefendantDetails()');

    this.installDefendantAccountPartyDebugIntercept();

    this.editDefendantDetailsActions.saveChanges();
    this.detailsNav.assertDefendantTabIsActive();
  }

  /**
   * Saves the company details after editing.
   */
  public saveCompanyDetails(): void {
    logAE('method', 'saveCompanyDetails()');

    this.installDefendantAccountPartyDebugIntercept();

    this.editCompanyDetailsActions.saveChanges();
    this.detailsNav.assertDefendantTabIsActive();
  }

  /**
   * Saves the parent/guardian details after editing.
   */
  public saveParentGuardianDetails(): void {
    logAE('method', 'saveParentGuardianDetails()');

    this.installDefendantAccountPartyDebugIntercept();

    this.editParentGuardianActions.saveChanges();
    this.detailsNav.assertParentGuardianTabIsActive();
  }

  /**
   * Saves the minor creditor details after editing.
   */
  public saveMinorCreditorDetails(): void {
    logAE('method', 'saveMinorCreditorDetails()');
    this.editMinorCreditorActions.saveChanges();
  }

  /**
   * Asserts the defendant summary name contains the expected value.
   * @param expected text expected in name field
   */
  public assertDefendantNameContains(expected: string): void {
    logAE('assert', 'assertDefendantNameContains()', { expected });
    this.detailsNav.goToDefendantTab();
    this.defendantDetails.assertDefendantNameContains(expected);
  }

  /**
   * Asserts the parent/guardian summary name contains the expected value.
   * @param expected text expected in name field
   */
  public assertParentGuardianNameContains(expected: string): void {
    logAE('assert', 'assertParentGuardianNameContains()', { expected });
    this.detailsNav.goToParentGuardianTab();
    this.parentGuardianDetails.assertNameContains(expected);
  }

  /**
   * Asserts the minor creditor summary name contains the expected value.
   *
   * @param expected text expected in name field
   */
  public assertMinorCreditorNameContains(expected: string): void {
    logAE('assert', 'assertMinorCreditorNameContains()', { expected });
    this.detailsNav.goToCreditorTab();
    this.minorCreditorDetails.assertNameContains(expected);
  }

  /**
   * Asserts the company summary name contains the expected value.
   * @param expected text expected in name field
   */
  public assertCompanyNameContains(expected: string): void {
    logAE('assert', 'assertCompanyNameContains()', { expected });
    this.detailsNav.goToDefendantTab();
    this.companyDetails.assertCompanyNameContains(expected);
  }

  /**
   * Cancels the edit operation and asserts that we remain on the edit page.
   */
  public cancelEditAndStay(): void {
    logAE('method', 'cancelEditAndStay()');
    logAE('cancel', 'Cancelling edit and staying on edit page');
    this.common.cancelEditing(false);
    this.editDefendantDetailsActions.assertStillOnEditPage();
  }

  /**
   * Cancels the edit operation
   */
  public cancelEditAndLeave(): void {
    logAE('method', 'cancelEditAndLeave()');
    logAE('cancel', 'Cancelling edit and returning to details page');
    this.common.cancelEditing(true);
  }

  /**
   * Cancels the add parent or guardian form without changes and asserts no warning is shown.
   */
  public cancelAddParentGuardianWithoutChanges(): void {
    logAE('method', 'cancelAddParentGuardianWithoutChanges()');

    cy.window().then((win) => {
      cy.stub(win, 'confirm').as('parentGuardianAddConfirm');
    });

    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.clickCancelLink();
    cy.get('@parentGuardianAddConfirm').should('not.have.been.called');
  }

  /**
   * Cancels the add parent or guardian form and chooses to stay on the page.
   */
  public cancelAddParentGuardianAndStay(): void {
    logAE('method', 'cancelAddParentGuardianAndStay()');
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.common.cancelEditing(false);
  }

  /**
   * Cancels the add parent or guardian form and confirms leaving the page.
   */
  public cancelAddParentGuardianAndLeave(): void {
    logAE('method', 'cancelAddParentGuardianAndLeave()');
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.common.cancelEditing(true);
  }

  /**
   * Cancels the amend parent or guardian form without changes and asserts no warning is shown.
   */
  public cancelAmendParentGuardianWithoutChanges(): void {
    logAE('method', 'cancelAmendParentGuardianWithoutChanges()');

    cy.window().then((win) => {
      cy.stub(win, 'confirm').as('parentGuardianAmendConfirm');
    });

    this.assertOnAmendParentGuardianDetailsPage();
    this.editParentGuardianActions.clickCancelLink();
    cy.get('@parentGuardianAmendConfirm').should('not.have.been.called');
  }

  /**
   * Cancels the amend parent or guardian form and chooses to stay on the page.
   */
  public cancelAmendParentGuardianAndStay(): void {
    logAE('method', 'cancelAmendParentGuardianAndStay()');
    this.assertOnAmendParentGuardianDetailsPage();
    this.common.cancelEditing(false);
  }

  /**
   * Cancels the amend parent or guardian form and confirms leaving the page.
   */
  public cancelAmendParentGuardianAndLeave(): void {
    logAE('method', 'cancelAmendParentGuardianAndLeave()');
    this.assertOnAmendParentGuardianDetailsPage();
    this.common.cancelEditing(true);
  }

  /**
   * Cancels the amend minor creditor form and confirms leaving the page.
   */
  public cancelAmendMinorCreditorAndLeave(): void {
    logAE('method', 'cancelAmendMinorCreditorAndLeave()');
    this.assertOnAmendMinorCreditorDetailsPage();
    this.common.cancelEditing(true);
  }

  /**
   * Attempts to save add parent or guardian details.
   */
  public attemptSaveAddParentGuardianDetails(): void {
    logAE('method', 'attemptSaveAddParentGuardianDetails()');
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.saveChanges();
  }

  /**
   * Attempts to save amend parent or guardian details.
   */
  public attemptSaveAmendParentGuardianDetails(): void {
    logAE('method', 'attemptSaveAmendParentGuardianDetails()');
    this.assertOnAmendParentGuardianDetailsPage();
    this.editParentGuardianActions.saveChanges();
  }

  /**
   * Asserts the first name on the add parent or guardian form.
   *
   * @param expected - Expected input value.
   */
  public assertAddParentGuardianFirstName(expected: string): void {
    logAE('method', 'assertAddParentGuardianFirstName()', { expected });
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.verifyFirstName(expected);
  }

  /**
   * Asserts the add parent or guardian error summary contains the expected message.
   *
   * @param expected - Expected error text.
   */
  public assertAddParentGuardianErrorSummaryContains(expected: string): void {
    logAE('method', 'assertAddParentGuardianErrorSummaryContains()', { expected });
    this.editParentGuardianActions.assertHeader({ route: 'add' });
    this.editParentGuardianActions.assertErrorSummaryContains(expected);
  }

  /**
   * Cancels the remove parent or guardian confirmation page.
   */
  public cancelRemoveParentGuardianDetails(): void {
    logAE('method', 'cancelRemoveParentGuardianDetails()');
    this.removeParentGuardian.cancelRemoval();
    this.detailsNav.assertParentGuardianTabIsActive();
    this.parentGuardianDetails.assertSectionHeader('Parent or guardian details');
  }

  /**
   * Confirms removal of the non-paying parent or guardian.
   */
  public confirmRemoveParentGuardianDetails(): void {
    logAE('method', 'confirmRemoveParentGuardianDetails()');
    this.removeParentGuardian.confirmRemoval();
    this.detailsNav.assertDefendantTabIsActive();
    this.defendantDetails.assertSectionHeader('Defendant');
  }

  /**
   * Asserts the account details success banner text.
   *
   * @param expected - Expected success message.
   */
  public assertAccountDetailsSuccessBanner(expected: string): void {
    logAE('method', 'assertAccountDetailsSuccessBanner()', { expected });
    this.detailsNav.assertSuccessBannerText(expected);
  }

  /**
   * Verifies the non-paying parent or guardian has been removed from the account via API.
   */
  public verifyParentGuardianRemovedViaApi(): void {
    logAE('method', 'verifyParentGuardianRemovedViaApi()');

    this.extractDefendantAccountIdFromUrl()
      .then((defendantAccountId) => this.fetchHeaderSummary(defendantAccountId))
      .then((headerBody) => {
        expect(headerBody['parent_guardian_party_id'], 'parent_guardian_party_id should be cleared').to.be.oneOf([
          null,
          undefined,
        ]);
        expect(headerBody['debtor_type'], 'debtor_type should revert to Defendant').to.eq('Defendant');
      });
  }

  /**
   * Asserts the first name on the amend parent or guardian form.
   *
   * @param expected - Expected input value.
   */
  public assertAmendParentGuardianFirstName(expected: string): void {
    logAE('method', 'assertAmendParentGuardianFirstName()', { expected });
    this.assertOnAmendParentGuardianDetailsPage();
    this.editParentGuardianActions.verifyFirstName(expected);
  }

  /**
   * Asserts the first name on the amend minor creditor form.
   *
   * @param expected - Expected input value.
   */
  public assertAmendMinorCreditorFirstName(expected: string): void {
    logAE('method', 'assertAmendMinorCreditorFirstName()', { expected });
    this.assertOnAmendMinorCreditorDetailsPage();
    this.editMinorCreditorActions.verifyFirstName(expected);
  }

  /**
   * Asserts the amend parent or guardian error summary contains the expected message.
   *
   * @param expected - Expected error text.
   */
  public assertAmendParentGuardianErrorSummaryContains(expected: string): void {
    logAE('method', 'assertAmendParentGuardianErrorSummaryContains()', { expected });
    this.assertOnAmendParentGuardianDetailsPage();
    this.editParentGuardianActions.assertErrorSummaryContains(expected);
  }

  /**
   * Asserts the amend minor creditor error summary contains the expected message.
   *
   * @param expected - Expected error text.
   */
  public assertAmendMinorCreditorErrorSummaryContains(expected: string): void {
    logAE('method', 'assertAmendMinorCreditorErrorSummaryContains()', { expected });
    this.assertOnAmendMinorCreditorDetailsPage();
    this.editMinorCreditorActions.assertErrorSummaryContains(expected);
  }

  /**
   * Cancels a company edit and remains on the edit form.
   *
   * @param expectedTempName - Optional temporary value that should remain populated.
   */
  public cancelCompanyEditAndStay(expectedTempName?: string): void {
    logAE('method', 'cancelCompanyEditAndStay()', { expectedTempName });
    logAE('cancel', 'Cancelling company edit and staying on the form');

    this.common.cancelEditing(false);
    this.editCompanyDetailsActions.assertStillOnEditPage();

    if (expectedTempName) {
      this.editCompanyDetailsActions.verifyFieldValue(expectedTempName);
    }
  }

  /**
   * Cancels a company edit, confirms leaving, and asserts the summary header is restored.
   *
   * @param originalName - Company name expected on the summary after discarding changes.
   */
  public discardCompanyEditAndReturn(originalName: string): void {
    logAE('method', 'discardCompanyEditAndReturn()', { originalName });
    logAE('cancel', 'Cancelling company edit and returning to summary');

    this.common.cancelEditing(true);
    this.detailsNav.assertDefendantTabIsActive();
    this.atAGlanceDetails.assertHeaderContains(originalName);
  }

  /**
   * Ensures the test is on the Companies Account Search page.
   * If not, it navigates via the dashboard and Companies tab.
   */
  private ensureOnCompanySearchPage(): void {
    logAE('method', 'ensureOnCompanySearchPage()');
    cy.get('body').then(($b) => {
      const onSearch = $b.find(C.root).length > 0;
      if (!onSearch) {
        logAE('navigate', 'Returning to Search landing page via HMCTS link (Companies)');
        this.common.clickHmctsHomeLink();
        this.searchIndividuals.assertOnSearchLandingPage();
        this.searchNav.goToCompaniesTab();
      }
    });
  }

  /**
   * Debug intercept for defendant account party updates to aid diagnosis when saving.
   */
  private installDefendantAccountPartyDebugIntercept(): void {
    cy.intercept(
      { method: 'PUT', url: '**/defendant-accounts/**/defendant-account-parties/**', middleware: true },
      (req) => {
        const { url, headers, body } = req;
        Cypress.log({ name: 'PUT', message: `url: ${url}` });
        Cypress.log({ name: 'PUT', message: `If-Match: ${headers['if-match'] || headers['If-Match']}` });
        Cypress.log({
          name: 'PUT',
          message: `Business-Unit-Id: ${headers['business-unit-id'] || headers['Business-Unit-Id']}`,
        });
        Cypress.log({ name: 'PUT', message: `Payload party_id: ${body?.party_details?.party_id}` });

        req.continue((res) => {
          console.info('PUT status', res.statusCode);
          console.info('PUT response body', res.body);
        });
      },
    ).as('debugPutDefendantAccountParty');
  }

  /**
   * Intercepts the payment terms save request for later assertions.
   */
  private interceptPaymentTermsSave(): void {
    cy.intercept('POST', '**/defendant-accounts/*/payment-terms').as('paymentTermsSave');
  }

  /**
   * Intercepts the enforcement override save request for later assertions.
   */
  private interceptEnforcementOverrideSave(): void {
    cy.intercept('PATCH', '**/defendant-accounts/*').as('enforcementOverrideSave');
  }

  /**
   * Default headers for Account Enquiry API requests.
   * @returns JSON and accept headers used for API calls.
   */
  private getApiHeaders(): Record<string, string> {
    return { 'Content-Type': 'application/json', Accept: 'application/json' };
  }

  /**
   * Extracts the defendant account ID from the current details page URL.
   * @returns Chainable resolving to the numeric defendant account ID.
   */
  private extractDefendantAccountIdFromUrl(): Cypress.Chainable<number> {
    return cy.location('pathname').then((pathname) => {
      const match = pathname.match(/\/fines\/account\/defendant\/(\d+)\/details/);

      expect(match, `URL should match defendant details pattern: ${pathname}`).to.exist;
      expect(match?.[1], 'Defendant account ID should be captured from URL').to.exist;

      const defendantAccountId = parseInt(match![1], 10);
      logAESync('action', 'Extracted defendant account ID from URL', { defendantAccountId });
      return defendantAccountId;
    });
  }

  /**
   * Extracts the minor creditor account ID from the current route.
   * @returns Chainable resolving to the numeric minor creditor account ID.
   */
  private extractMinorCreditorAccountIdFromUrl(): Cypress.Chainable<number> {
    return cy.location('pathname').then((pathname) => {
      const match = pathname.match(/\/fines\/account\/minor-creditor\/(\d+)(?:\/details|\/amend)?/);

      expect(match, `URL should match minor creditor account pattern: ${pathname}`).to.exist;
      expect(match?.[1], 'Minor creditor account ID should be captured from URL').to.exist;

      const minorCreditorAccountId = parseInt(match![1], 10);
      logAESync('action', 'Extracted minor creditor account ID from URL', { minorCreditorAccountId });
      return minorCreditorAccountId;
    });
  }

  /**
   * Fetches the header summary for a defendant account via API.
   * @param defendantAccountId - ID of the defendant account.
   * @returns Chainable yielding the header summary response body.
   */
  private fetchHeaderSummary(defendantAccountId: number): Cypress.Chainable<Record<string, unknown>> {
    return cy
      .request({
        method: 'GET',
        url: `${AccountEnquiryFlow.BASE_API_PATH}/defendant-accounts/${defendantAccountId}/header-summary`,
        headers: this.getApiHeaders(),
        failOnStatusCode: false,
      })
      .then((headerResp) => {
        expect(headerResp.status, 'GET header-summary status').to.eq(200);
        return headerResp.body as Record<string, unknown>;
      });
  }

  /**
   * Fetches party details for a defendant account via API.
   * @param defendantAccountId - ID of the defendant account.
   * @param partyId - Party ID to fetch.
   * @returns Chainable yielding the party details response body.
   */
  private fetchPartyDetails(defendantAccountId: number, partyId: string): Cypress.Chainable<Record<string, unknown>> {
    logAE('action', `Fetching party details for party ${partyId}`);
    return cy
      .request({
        method: 'GET',
        url: `${AccountEnquiryFlow.BASE_API_PATH}/defendant-accounts/${defendantAccountId}/defendant-account-parties/${partyId}`,
        headers: this.getApiHeaders(),
        failOnStatusCode: false,
      })
      .then((partyResp) => {
        expect(partyResp.status, 'GET party details status').to.eq(200);
        return partyResp.body as Record<string, unknown>;
      });
  }

  /**
   * Fetches the creditor tab payload for a minor creditor account via API.
   *
   * @param minorCreditorAccountId - ID of the minor creditor account.
   * @returns Chainable yielding the account details response body.
   */
  private fetchMinorCreditorAccount(minorCreditorAccountId: number): Cypress.Chainable<Record<string, unknown>> {
    logAE('action', `Fetching minor creditor account details for account ${minorCreditorAccountId}`);
    return cy
      .request({
        method: 'GET',
        url: `${AccountEnquiryFlow.BASE_API_PATH}/minor-creditor-accounts/${minorCreditorAccountId}`,
        headers: this.getApiHeaders(),
        failOnStatusCode: false,
      })
      .then((accountResp) => {
        expect(accountResp.status, 'GET minor creditor account details status').to.eq(200);
        return accountResp.body as Record<string, unknown>;
      });
  }

  /**
   * Searches amendments associated with a defendant account.
   * @param defendantAccountId - ID of the defendant account.
   * @returns Amendments list and optional count.
   */
  private searchAmendmentsForAccount(
    defendantAccountId: number,
  ): Cypress.Chainable<{ amendments: Array<Record<string, unknown>>; count?: number }> {
    const requestBody = {
      associated_record_type: 'defendant_accounts',
      associated_record_id: String(defendantAccountId),
      function_code: 'ACCOUNT_ENQUIRY',
    };

    logAE('action', 'Searching amendments for defendant', { requestBody });

    return cy
      .request({
        method: 'POST',
        url: `${AccountEnquiryFlow.BASE_API_PATH}/amendments/search`,
        headers: this.getApiHeaders(),
        body: requestBody,
        failOnStatusCode: false,
      })
      .then((amendRes) => {
        expect(amendRes.status, 'POST amendments search should succeed').to.eq(200);

        const responseBody = amendRes.body as Record<string, unknown>;
        const amendments = (responseBody?.['searchData'] ?? []) as Array<Record<string, unknown>>;
        const count = responseBody?.['count'] as number | undefined;

        logAESync('info', 'Amendments search result', {
          count,
          searchDataLength: amendments.length,
        });

        return { amendments, count } as { amendments: Array<Record<string, unknown>>; count?: number };
      });
  }

  /**
   * Searches amendments associated with a minor creditor account.
   *
   * @param minorCreditorAccountId - ID of the minor creditor account.
   * @returns Amendments list and optional count.
   */
  private searchAmendmentsForMinorCreditorAccount(
    minorCreditorAccountId: number,
  ): Cypress.Chainable<MinorCreditorAmendmentSearchResult> {
    const recordTypes = ['minor_creditor_accounts', 'minor_creditor_account', 'creditor_accounts', 'creditor_account'];
    const accountId = String(minorCreditorAccountId);

    const searchByRecordType = (index: number): Cypress.Chainable<MinorCreditorAmendmentSearchResult> => {
      const associatedRecordType = recordTypes[index];
      const requestBody = {
        associated_record_type: associatedRecordType,
        associated_record_id: accountId,
        function_code: 'ACCOUNT_ENQUIRY',
      };

      logAE('action', 'Searching amendments for minor creditor account', { requestBody });

      return cy
        .request({
          method: 'POST',
          url: `${AccountEnquiryFlow.BASE_API_PATH}/amendments/search`,
          headers: this.getApiHeaders(),
          body: requestBody,
          failOnStatusCode: false,
        })
        .then((amendRes): Cypress.Chainable<MinorCreditorAmendmentSearchResult> => {
          if (amendRes.status !== 200) {
            logAESync('warn', 'Minor creditor amendments search rejected', {
              associatedRecordType,
              status: amendRes.status,
            });

            if (index < recordTypes.length - 1) {
              return searchByRecordType(index + 1);
            }

            expect(amendRes.status, 'POST minor creditor amendments search should succeed').to.eq(200);
          }

          const responseBody = amendRes.body as Record<string, unknown>;
          const amendments = (responseBody?.['searchData'] ?? []) as Array<Record<string, unknown>>;
          const count = responseBody?.['count'] as number | undefined;

          logAESync('info', 'Minor creditor amendments search result', {
            associatedRecordType,
            count,
            searchDataLength: amendments.length,
          });

          if (amendments.length > 0 || index === recordTypes.length - 1) {
            return cy.wrap({ amendments, count, recordType: associatedRecordType }, { log: false });
          }

          return searchByRecordType(index + 1);
        });
    };

    return searchByRecordType(0);
  }

  /**
   * Asserts core amendment fields are present.
   * @param match - Amendment record to validate.
   */
  private assertAmendmentCoreFields(match: Record<string, unknown> | undefined): void {
    ['amendment_id', 'business_unit_id', 'amended_date', 'amended_by', 'field_code'].forEach((key) => {
      expect(match, `Amendment should have property: ${key}`).to.have.property(key);
    });
  }

  /**
   * Performs a Companies search by company name.
   *
   * @param companyName - Company name to search for.
   */
  public searchByCompanyName(companyName: string): void {
    logAE('method', 'searchByCompanyName()');
    this.ensureOnCompanySearchPage();
    this.searchNav.goToCompaniesTab();
    logAE('search', 'Searching by company name', { companyName });
    this.resolveAccountNumberFromAlias().then((accountNumber) => {
      if (accountNumber) {
        logAE('search', 'Using exact account number for freshly created company account', { accountNumber });
        this.searchCommon.enterAccountNumber(accountNumber);
        this.searchCommon.clickSearchButton();
        this.results.assertOnResults();
        return;
      }

      this.searchCompany.byCompanyName(companyName);
      this.results.assertOnResults();
    });
  }

  /**
   * Opens company account details by name using the Companies tab and selecting the latest.
   *
   * @param companyName - Company name to search and open.
   */
  public openCompanyAccountDetailsByNameAndSelectLatest(companyName: string): void {
    logAE('method', 'openCompanyAccountDetailsByNameAndSelectLatest()');
    this.searchByCompanyName(companyName);
    logAE('results', 'Select Latest published company account from results', { companyName });
    this.clickLatestPublishedFromResultsOrAcrossPages();
  }

  /**
   * Opens the "Add account note" screen and verifies the header.
   *
   */
  public openAddAccountNoteAndVerifyHeader(): void {
    logAE('method', 'openAddAccountNoteAndVerifyHeader()');
    cy.location('pathname').then((pathname) => {
      const alreadyOnAddAccountNotePage = pathname.includes('/note/add');

      if (alreadyOnAddAccountNotePage) {
        logAE('navigate', 'Already on "Add account note" screen');
        return;
      }

      logAE('navigate', 'Opening "Add account note" screen');
      this.detailsNav.clickAddAccountNoteButton();
    });

    this.notes.assertHeaderContains('Add account note');
  }

  /**
   * Opens Notes screen and enters text into its primary field(s).
   * @param text - Text to enter.
   * @throws Error if the screen is not recognised.
   */
  public openNotesScreenAndEnterText(text: string): void {
    logAE('method', 'openNotesScreenAndEnterText()');

    this.openAddAccountNoteAndVerifyHeader();
    logAE('input', 'Typing note text');

    this.notes.enterAccountNote(text);
  }

  /**
   * Enters an account note and saves it (reusing the open+enter helper), ensuring
   * we return to the defendant account details page.
   *
   * @description Saves a note via the Add account note journey and guards the redirect back to details.
   * @param note - The note text to enter.
   *
   * @remarks
   *  - Guards navigation by asserting the defendant details URL after saving.
   *  - Delegates typing to {@link openNotesScreenAndEnterText}.
   *
   * @example
   *  flow.openAccountNoteEnterNoteAndSave('Valid test account note');
   */
  public openAccountNoteEnterNoteAndSave(note: string): void {
    logAE('method', 'openAccountNoteEnterNoteAndSave()');
    logAE('input', 'Preparing to enter and save account note', { length: note?.length });

    this.openNotesScreenAndEnterText(note);

    logAE('save', 'Saving account note');
    this.notes.save();

    cy.location('pathname', { timeout: 20000 }).should('match', /\/fines\/account\/defendant\/\d+\/details$/);
  }

  /**
   * Opens the Add account note view and cancels immediately without entering text.
   *
   * @description Starts the Add account note journey and discards it without entering content.
   * @remarks
   *  - Confirms any unsaved-changes dialog (if shown) and asserts we return to defendant details.
   *  - Uses {@link openAddAccountNoteAndVerifyHeader} for the initial navigation guard.
   *
   * @example
   *  flow.cancelAccountNoteWithoutEntering();
   */
  public cancelAccountNoteWithoutEntering(): void {
    logAE('method', 'cancelAccountNoteWithoutEntering()');
    logAE('flow', 'Open → cancel without changes');

    this.openAddAccountNoteAndVerifyHeader();
    this.notes.assertNoteValueEquals('');

    this.common.cancelEditing(true);

    cy.location('pathname', { timeout: 20000 }).should('match', /\/fines\/account\/defendant\/\d+\/details$/);
  }

  /**
   * Enters an account note and saves it.
   *
   * @description
   *  Automates the process of adding a note to an account record.
   *  Logs each action step for Cypress traceability and debugging.
   *  This method types the provided note text, then triggers the save action.
   *
   * @param note - The text content to be entered into the account note field.
   *
   * @remarks
   *  - Uses `this.notes.enterAccountNote()` to input text.
   *  - Calls `this.notes.save()` to persist the note.
   *  - Includes Cypress logs for method start, input entry, and save confirmation.
   *
   * @example
   *  accountDetailsActions.enterAndSaveNote('Customer requested payment extension.');
   */
  public enterAndSaveNote(note: string): void {
    logAE('method', 'enterAndSaveNote()');
    logAE('input', 'Typing note text');
    this.notes.enterAccountNote(note);
    logAE('save', 'Saving account note');
    this.notes.save();
  }

  /**
   * Saves the provided comment lines and verifies redirect to defendant summary.
   * @param lines - Lines to enter into the Comments form before saving.
   */
  public saveCommentsAndReturnToSummary(lines: readonly string[]): void {
    Cypress.log({
      name: 'flow',
      displayName: 'Save Comments → Summary',
      message: `Saving ${lines.length} line(s) and verifying redirect to summary`,
      consoleProps: () => ({ lines }),
    });

    // Open Comments from summary and verify we're on the page
    this.atAGlanceDetails.openCommentsFromSummary();
    this.comments.assertCommentsHeader();

    // Handles typing + POST + initial redirect wait
    this.comments.enterAndSaveComments(lines);

    // Defensive URL check that we're back on the summary
    cy.location('pathname', this.common.getTimeoutOptions()).should(
      'match',
      /\/fines\/account\/defendant\/\d+\/details$/,
    );
  }

  /**
   * Saves comments, returns to summary, and asserts the header text.
   * @param lines - Comment lines to enter.
   * @param expectedHeader - Expected header text on the summary page.
   */
  public saveCommentsReturnAndAssertHeader(lines: readonly string[], expectedHeader: string): void {
    this.saveCommentsAndReturnToSummary(lines);
    this.atAGlanceDetails.assertHeaderContains(expectedHeader);
  }

  /**
   * Opens the notes screen, enters text, and cancels the edit.
   *
   * @param text - The text to enter before cancelling.
   */
  public openNotesScreenEnterTextAndCancel(text: string): void {
    logAE('method', 'openScreenEnterTextAndCancel()');
    logAE('flow', 'Open → enter text → cancel');

    this.openNotesScreenAndEnterText(text);

    // Ensure the value is present before we cancel (prevents stale element errors)
    this.notes.assertNoteValueEquals(text);

    logAE('cancel', 'Cancelling edit and confirming leave');
    this.common.cancelEditing(true);

    cy.document({ timeout: 20000 })
      .its('readyState')
      .should('match', /interactive|complete/);

    // If the app didn’t redirect after OK, fall back to going back
    cy.location('href', { timeout: 20000 }).then((href) => {
      if (href.includes('/note/add')) {
        cy.go('back');
      }
    });

    // Final expectation (this will retry)
    cy.location('pathname', { timeout: 20000 }).should('include', '/details');
  }

  /**
   * Opens a screen, enters text, triggers browser back, and confirms the unsaved changes warning.
   *
   * @param text - The text to enter before navigating back.
   */
  public openScreenEnterTextAndNavigateBackWithConfirmation(text: string): void {
    logAE('method', 'openScreenEnterTextAndNavigateBackWithConfirmation()');
    logAE('flow', 'Open → enter text → browser back → confirm');

    // 1. Navigate and enter note text
    this.openNotesScreenAndEnterText(text);

    // 2. Simulate browser back and confirm the warning
    this.common.navigateBrowserBackWithChoice('ok', /\/details$/);
  }

  /**
   * Opens the Comments page from the defendant summary, verifies fields + header,
   * clicks Cancel and dismisses (stay), then clicks Cancel and confirms (leave),
   * and finally verifies the account summary header (if provided).
   *
   * @param expectedSummaryHeader - Optional header text to assert on the summary page.
   */
  public openCommentsFromSummaryAndVerifyPageDetails(expectedSummaryHeader?: string): void {
    Cypress.log({
      name: 'flow',
      displayName: 'Comments Page Verification',
      message: 'Open → verify fields & header → cancel(dismiss) → cancel(confirm) → verify summary',
      consoleProps: () => ({ expectedSummaryHeader }),
    });

    // 1) Navigate from summary to Comments (use your nav action for the "Add comments" link)
    this.atAGlanceDetails.openCommentsFromSummary();

    // 2) Verify all fields + controls are present
    this.comments.assertFormFieldsPresent();

    // 3) Verify header contains "Comments"
    this.comments.assertCommentsHeader();
  }

  /**
   * Route-guard verification on the Comments page:
   *  open from summary → type → Cancel (dismiss) → verify stayed with text →
   *  Cancel (confirm) → verify returned to summary.
   * @param noteText - Text to enter into the comment before cancelling.
   */
  public verifyRouteGuardBehaviourOnComments(noteText: string): void {
    Cypress.log({
      name: 'flow',
      displayName: 'Comments Route Guard',
      message: `Open → type "${noteText}" → cancel(dismiss) → cancel(confirm)`,
      consoleProps: () => ({ noteText }),
    });

    // Open Comments from summary and verify we're on the page
    this.atAGlanceDetails.openCommentsFromSummary();
    this.comments.assertCommentsHeader();

    // Enter unsaved text
    this.comments.setComment(noteText);

    // Cancel → dismiss (stay on Comments)
    this.common.confirmNextUnsavedChanges(false);
    this.comments.clickCancelLink();
    this.comments.assertCommentsHeader();
    this.comments.assertCommentValueEquals(noteText);

    // Cancel → confirm (leave to summary)
    this.comments.confirmLeaveAndReturnToSummary();

    cy.location('pathname', { timeout: 15000 }).should('match', /\/fines\/account\/defendant\/\d+\/details$/);
  }

  /**
   * Open the Comments section and verify existing prefilled values.
   * @param expected Prefilled form values to assert.
   * @param expected.comment - Expected comment text.
   * @param expected.line1 - Expected first free-text line.
   * @param expected.line2 - Expected second free-text line.
   * @param expected.line3 - Expected third free-text line.
   */
  verifyPrefilledComments(expected: { comment?: string; line1?: string; line2?: string; line3?: string }): void {
    cy.log('Flow: Verify prefilled Comments form');

    this.atAGlanceDetails.openCommentsFromSummary();
    this.comments.assertPrefilledFormValues(expected);
  }

  /**
   * Verifies route-guard behaviour for a Parent/Guardian by editing First names,
   * choosing to stay, then confirming the temporary value is retained until leaving,
   * and finally confirming the header reverts to the original name.
   *
   * @param originalHeaderName - The original defendant name shown in the header (e.g. "Miss Catherine GREEN").
   * @param tempFirstName - Temporary value to enter into the "First names" field (e.g. "FNAMECHANGE").
   */
  public verifyParentGuardianRouteGuardBehaviour(originalHeaderName: string, tempFirstName: string): void {
    logAE('method', 'verifyParentGuardianRouteGuardBehaviour()');
    logAE('verify', 'Verifying route guard behaviour (Parent/Guardian)', { originalHeaderName, tempFirstName });

    // Navigate to Defendant tab
    logAE('action', 'Navigating to Parent Guardian tab');
    this.detailsNav.goToParentGuardianTab();

    // Click Change Link
    logAE('action', 'Change Link');
    this.parentGuardianDetails.change();

    // Assert section header
    logAE('verify', 'Verifying section header is "Parent or guardian details"');
    this.editParentGuardianActions.assertHeader();

    // Enter temporary first name
    logAE('action', 'Editing "First names"', { newValue: tempFirstName });
    this.editParentGuardianActions.editFirstNames(tempFirstName);

    // Cancel edit (user chooses to stay on page)
    logAE('action', 'Cancelling edit without saving (stay on page)');
    this.common.cancelEditing(false); // maps to: click Cancel -> modal -> Cancel

    // Verify temp value persisted
    logAE('verify', 'Verifying temporary first name persisted', { expected: tempFirstName });
    this.editParentGuardianActions.verifyFirstName(tempFirstName);

    // Cancel edit (user confirms leaving/reverting)
    logAE('action', 'Cancelling edit with revert (leave)');
    this.common.cancelEditing(true); // maps to: click Cancel -> modal -> Ok

    // Final verification: header restored to original defendant name
    logAE('verify', 'Verifying header reverted to original name', { expected: originalHeaderName });
    this.atAGlanceDetails.assertHeaderContains(originalHeaderName);

    logAE('complete', 'Parent/Guardian route-guard verification completed');
  }

  /**
   * Cancels Parent/Guardian edit without saving
   *
   * Opens the Parent/Guardian tab, starts an edit, then cancels and discards changes.
   */
  public cancelParentGuardianEditWithoutSaving(): void {
    logAE('method', 'cancelParentGuardianEditWithoutSaving()');
    logAE('action', 'Navigating to Parent/Guardian tab');
    this.detailsNav.goToParentGuardianTab();

    logAE('action', 'Starting Parent/Guardian edit');
    this.parentGuardianDetails.change();

    logAE('verify', 'Verifying Parent/Guardian section header');
    this.editParentGuardianActions.assertHeader();

    const tempLastName = 'LNAMEALTERED';

    logAE('action', 'Editing "Last name"', { newValue: tempLastName });
    this.editParentGuardianActions.editLastName(tempLastName);

    logAE('action', 'Cancelling edit without saving (discard changes)');
    this.common.cancelEditing(true); // "Cancel" -> Confirm "Ok"

    logAE('complete', 'Parent/Guardian cancel edit without saving complete');
  }

  /**
   * Handles the "Cancel → Stay" route-guard scenario for Parent/Guardian edits.
   *
   * Starts an edit, changes a field temporarily, cancels but chooses to stay,
   * verifies the temporary value persists, then leaves verification for later steps.
   */
  public cancelParentGuardianEditButStayOnPage(): void {
    logAE('method', 'cancelParentGuardianEditButStayOnPage()');
    logAE('action', 'Navigating to Parent/Guardian tab');
    this.detailsNav.goToParentGuardianTab();

    logAE('action', 'Starting Parent/Guardian edit');
    this.parentGuardianDetails.change();

    logAE('verify', 'Verifying Parent/Guardian section header');
    this.editParentGuardianActions.assertHeader();

    const tempLastName = 'LNAMEALTERED';

    logAE('action', 'Editing "Last name"', { newValue: tempLastName });
    this.editParentGuardianActions.editLastName(tempLastName);

    logAE('action', 'Cancelling edit but staying on the page');
    this.common.cancelEditing(false); // user selects "Cancel" → "Stay"

    logAE('complete', 'Stayed on page; temporary data should be retained');
  }

  /**
   * Updates defendant details and records the amendment baseline for later comparisons.
   *
   * @param updatedFirstName - First name to persist and audit.
   * @remarks Stores `@amendmentBaseline` for subsequent no-change assertions.
   */
  public establishDefendantAmendmentBaseline(updatedFirstName: string): void {
    logAE('method', 'establishDefendantAmendmentBaseline()', { updatedFirstName });

    this.editDefendantAndChangeFirstName(updatedFirstName);
    this.saveDefendantDetails();
    this.assertDefendantNameContains(updatedFirstName);
    this.verifyDefendantAmendmentsViaApi(updatedFirstName);
  }

  /**
   * Updates company details and records the amendment baseline for later comparisons.
   *
   * @param updatedCompanyName - Company name to persist and audit.
   * @remarks Stores `@amendmentBaseline` for subsequent no-change assertions.
   */
  public establishCompanyAmendmentBaseline(updatedCompanyName: string): void {
    logAE('method', 'establishCompanyAmendmentBaseline()', { updatedCompanyName });

    this.editCompanyDetailsAndChangeName(updatedCompanyName);
    this.saveCompanyDetails();
    this.assertCompanyNameContains(updatedCompanyName);
    this.verifyCompanyAmendmentsViaApi(updatedCompanyName);
  }

  /**
   * Updates parent/guardian details and records the amendment baseline for later comparisons.
   *
   * @param updatedFirstName - Guardian first name to persist and audit.
   * @remarks Stores `@amendmentBaseline` for subsequent no-change assertions.
   */
  public establishParentGuardianAmendmentBaseline(updatedFirstName: string): void {
    logAE('method', 'establishParentGuardianAmendmentBaseline()', { updatedFirstName });

    this.editParentGuardianAndChangeFirstName(updatedFirstName);
    this.saveParentGuardianDetails();
    this.assertParentGuardianNameContains(updatedFirstName);
    this.verifyParentGuardianAmendmentsViaApi(updatedFirstName);
  }

  /**
   * Verifies persisted minor creditor updates and amendment audit rows via backend APIs.
   *
   * @param expectedForename - The forename value that should be persisted and audited.
   */
  public verifyMinorCreditorAmendmentsViaApi(expectedForename: string): void {
    logAE('action', 'Verify minor creditor amendments via API', { expectedForename });

    this.extractMinorCreditorAccountIdFromUrl()
      .then((minorCreditorAccountId) =>
        this.fetchMinorCreditorAccount(minorCreditorAccountId).then((accountBody) => ({
          minorCreditorAccountId,
          accountBody,
        })),
      )
      .then(({ minorCreditorAccountId, accountBody }) => {
        const partyDetails = accountBody['party_details'] as Record<string, unknown> | undefined;
        const individual = partyDetails?.['individual_details'] as Record<string, unknown> | undefined;

        expect(individual?.['forenames'], 'Minor creditor forename should match expected value').to.eq(
          expectedForename,
        );
        logAESync('assert', 'Minor creditor forename verified in account details', {
          forenames: individual?.['forenames'],
        });

        return minorCreditorAccountId;
      })
      .then((minorCreditorAccountId) => this.searchAmendmentsForMinorCreditorAccount(minorCreditorAccountId))
      .then(({ amendments, recordType }) => {
        expect(amendments, 'Amendments searchData should be an array').to.be.an('array').and.not.be.empty;

        const match = amendments.find(
          (row) => typeof row['new_value'] === 'string' && row['new_value'].includes(expectedForename),
        );

        expect(match, 'Amendment record should contain updated minor creditor forename').to.exist;
        expect(
          match?.['associated_record_type'],
          'associated_record_type should match resolved backend record type',
        ).to.eq(recordType);
        expect(match?.['function_code'], 'function_code should be ACCOUNT_ENQUIRY').to.eq('ACCOUNT_ENQUIRY');

        this.assertAmendmentCoreFields(match);

        expect(match?.['new_value'], 'new_value should contain updated minor creditor forename')
          .to.be.a('string')
          .and.include(expectedForename);

        expect(match?.['old_value'], 'old_value should exist and be a string').to.be.a('string').and.not.be.empty;
        expect(match?.['old_value'], 'old_value should differ from new_value').to.not.eq(match?.['new_value']);

        logAE('done', 'Minor creditor amendment verified in amendments log', {
          amendmentId: match?.['amendment_id'],
          oldValue: match?.['old_value'],
          newValue: match?.['new_value'],
        });
      });
  }

  /**
   * Verifies persisted defendant updates and amendment audit rows via backend APIs.
   * Uses relative API paths - same pattern as draft accounts.
   *
   * @param expectedForename - The forename value that should be persisted/audited.
   */
  public verifyDefendantAmendmentsViaApi(expectedForename: string): void {
    logAE('action', 'Verify defendant amendments via API', { expectedForename });

    this.extractDefendantAccountIdFromUrl()
      .then((defendantAccountId) =>
        this.fetchHeaderSummary(defendantAccountId).then((headerBody) => ({ defendantAccountId, headerBody })),
      )
      .then(({ defendantAccountId, headerBody }) => {
        const partyId = headerBody['defendant_account_party_id'];
        expect(partyId, 'defendant_account_party_id must exist').to.exist;

        logAESync('action', `Found party ID: ${partyId}`);

        return { defendantAccountId, partyId: partyId as string };
      })
      .then((data) =>
        this.fetchPartyDetails(data.defendantAccountId, data.partyId).then((partyBody) => {
          const party = partyBody['defendant_account_party'] as Record<string, unknown> | undefined;
          const details = party?.['party_details'] as Record<string, unknown> | undefined;
          const individual = details?.['individual_details'] as Record<string, unknown> | undefined;

          expect(individual?.['forenames'], 'Forename should match expected value').to.eq(expectedForename);
          logAESync('assert', 'Forename verified in party details', { forenames: individual?.['forenames'] });
          return data.defendantAccountId;
        }),
      )
      .then((defendantAccountId) => this.searchAmendmentsForAccount(defendantAccountId))
      .then(({ amendments }) => {
        expect(amendments, 'Amendments searchData should be an array').to.be.an('array').and.not.be.empty;

        const match = amendments.find(
          (row) => typeof row['new_value'] === 'string' && row['new_value'].includes(expectedForename),
        );

        expect(match, 'Amendment record should contain updated forename').to.exist;
        expect(match).to.include({
          associated_record_type: 'defendant_accounts',
          function_code: 'ACCOUNT_ENQUIRY',
        });

        this.assertAmendmentCoreFields(match);

        expect(match?.['new_value'], 'new_value should contain updated forename')
          .to.be.a('string')
          .and.include(expectedForename);

        expect(match?.['old_value'], 'old_value should exist and be a string').to.be.a('string').and.not.be.empty;
        expect(match?.['old_value'], 'old_value should differ from new_value').to.not.eq(match?.['new_value']);

        logAE('done', 'Amendment verified in amendments log', {
          amendmentId: match?.['amendment_id'],
          oldValue: match?.['old_value'],
          newValue: match?.['new_value'],
        });

        // Store the current amendment count for later comparison
        cy.wrap({ amendmentCount: amendments.length }).as('amendmentBaseline');
        logAE('info', 'Stored amendment count for baseline', { count: amendments.length });
      });
  }

  /**
   * Verifies that NO defendant amendments were created.
   *
   * Extracts the defendant account ID from the current URL and queries the amendments API
   * to verify no amendment records exist for forenames field.
   */
  public verifyNoDefendantAmendments(): void {
    logAE('method', 'verifyNoDefendantAmendments()');

    // Get the baseline amendment count from the previous verification step
    cy.get('@amendmentBaseline').then((baseline) => {
      const baselineCount = (baseline as unknown as { amendmentCount: number })?.amendmentCount ?? 0;
      logAE('info', 'Retrieved amendment baseline', { baselineCount });

      let defendantAccountId: number;

      this.extractDefendantAccountIdFromUrl()
        .then((id) => {
          defendantAccountId = id;
          return this.fetchHeaderSummary(id);
        })
        .then((headerBody) => {
          const partyId = headerBody['defendant_account_party_id'];
          expect(partyId, 'defendant_account_party_id must exist').to.exist;

          logAESync('info', `Found party ID: ${partyId}`);
          return defendantAccountId;
        })
        .then((id) => this.searchAmendmentsForAccount(id))
        .then(({ amendments }) => {
          logAE('info', 'Amendments search result', {
            searchDataLength: amendments.length,
            baselineCount,
          });

          expect(
            amendments.length,
            `No amendment records should be created when no changes were made (baseline: ${baselineCount})`,
          ).to.eq(baselineCount);

          logAE('done', 'Verified no new amendments were created', {
            currentCount: amendments.length,
            baselineCount,
          });
        });
    });
  }

  /**
   * Handles the "Cancel → OK" route-guard scenario for Parent/Guardian edits.
   *
   * Starts an edit, triggers cancel, confirms the discard
   */
  public discardParentGuardianChanges(): void {
    logAE('method', 'discardParentGuardianChanges()');
    logAE('action', 'Navigating to Parent/Guardian tab');
    this.detailsNav.goToParentGuardianTab();

    logAE('action', 'Starting Parent/Guardian edit');
    this.parentGuardianDetails.change();

    logAE('verify', 'Verifying Parent/Guardian section header');
    this.editParentGuardianActions.assertHeader();

    logAE('action', 'Cancelling edit and confirming discard');
    this.common.cancelEditing(true); // user selects "Cancel" → "OK" to discard

    logAE('complete', 'Parent/Guardian changes discarded successfully');
  }

  /**
   * Verifies persisted parent/guardian updates and amendment audit rows via backend APIs.
   * Uses relative API paths - same pattern as draft accounts.
   *
   * @param expectedGuardianName - The guardian name value that should be persisted/audited.
   */
  public verifyParentGuardianAmendmentsViaApi(expectedGuardianName: string): void {
    logAE('action', 'Verify parent/guardian amendments via API', { expectedGuardianName });

    this.extractDefendantAccountIdFromUrl()
      .then((defendantAccountId) =>
        this.fetchHeaderSummary(defendantAccountId).then((headerBody) => ({ defendantAccountId, headerBody })),
      )
      .then(({ defendantAccountId, headerBody }) => {
        const partyId = headerBody['parent_guardian_party_id'];
        expect(partyId, 'parent_guardian_party_id must exist').to.exist;

        logAESync('action', `Found parent/guardian party ID: ${partyId}`);

        return { defendantAccountId, partyId: partyId as string };
      })
      .then((data) =>
        this.fetchPartyDetails(data.defendantAccountId, data.partyId).then((partyBody) => {
          const party = partyBody['defendant_account_party'] as Record<string, unknown> | undefined;
          const details = party?.['party_details'] as Record<string, unknown> | undefined;
          const individual = details?.['individual_details'] as Record<string, unknown> | undefined;

          expect(individual?.['forenames'], 'Guardian forename should match expected value').to.eq(
            expectedGuardianName,
          );
          logAESync('assert', 'Guardian forename verified in party details', {
            forenames: individual?.['forenames'],
          });
          return data.defendantAccountId;
        }),
      )
      .then((defendantAccountId) => this.searchAmendmentsForAccount(defendantAccountId))
      .then(({ amendments }) => {
        expect(amendments, 'Amendments searchData should be an array').to.be.an('array').and.not.be.empty;

        const match = amendments.find(
          (row) => typeof row['new_value'] === 'string' && row['new_value'].includes(expectedGuardianName),
        );

        expect(match, 'Amendment record should contain updated guardian forename').to.exist;
        expect(match).to.include({
          associated_record_type: 'defendant_accounts',
          function_code: 'ACCOUNT_ENQUIRY',
        });

        this.assertAmendmentCoreFields(match);

        expect(match?.['new_value'], 'new_value should contain updated guardian forename')
          .to.be.a('string')
          .and.include(expectedGuardianName);

        const oldValue = match?.['old_value'];
        const newValue = match?.['new_value'];

        if (oldValue && typeof oldValue === 'string' && oldValue.trim() !== '') {
          expect(oldValue, 'old_value should differ from new_value when both exist').to.not.eq(newValue);
        }

        logAE('done', 'Parent/guardian amendment verified in amendments log', {
          amendmentId: match?.['amendment_id'],
          fieldCode: match?.['field_code'],
          oldValue: oldValue || '(empty)',
          newValue,
        });

        // Store the current amendment count for later comparison
        cy.wrap({ amendmentCount: amendments.length }).as('amendmentBaseline');
        logAE('info', 'Stored amendment count for baseline', { count: amendments.length });
      });
  }

  /**
   * Verifies persisted company updates and amendment audit rows via backend APIs.
   * Uses relative API paths - same pattern as draft accounts.
   *
   * @param expectedCompanyName - The company name value that should be persisted/audited.
   */
  public verifyCompanyAmendmentsViaApi(expectedCompanyName: string): void {
    logAE('action', 'Verify company amendments via API', { expectedCompanyName });

    this.extractDefendantAccountIdFromUrl()
      .then((defendantAccountId) =>
        this.fetchHeaderSummary(defendantAccountId).then((headerBody) => ({ defendantAccountId, headerBody })),
      )
      .then(({ defendantAccountId, headerBody }) => {
        const partyId = headerBody['defendant_account_party_id'];
        expect(partyId, 'defendant_account_party_id must exist').to.exist;

        logAESync('action', `Found party ID: ${partyId}`);

        return { defendantAccountId, partyId: partyId as string };
      })
      .then((data) =>
        this.fetchPartyDetails(data.defendantAccountId, data.partyId).then((partyBody) => {
          const party = partyBody['defendant_account_party'] as Record<string, unknown> | undefined;
          const details = party?.['party_details'] as Record<string, unknown> | undefined;

          // Guard: Ensure this is an organisation party
          expect(details?.['organisation_flag'], 'Party should be an organisation').to.be.true;

          const organisation = details?.['organisation_details'] as Record<string, unknown> | undefined;
          const organisationName = organisation?.['organisation_name'];

          expect(organisationName, 'Organisation name should match expected value').to.eq(expectedCompanyName);
          logAESync('assert', 'Organisation name verified in party details', { organisationName });
          return data.defendantAccountId;
        }),
      )
      .then((defendantAccountId) => this.searchAmendmentsForAccount(defendantAccountId))
      .then(({ amendments }) => {
        expect(amendments, 'Amendments searchData should be an array').to.be.an('array').and.not.be.empty;

        // Find amendment matching the organisation name
        // Narrow by field_code if possible to avoid matching unrelated fields
        const match = amendments.find(
          (row) => typeof row['new_value'] === 'string' && row['new_value'].includes(expectedCompanyName),
        );

        expect(match, 'Amendment record should contain updated organisation name').to.exist;
        expect(match).to.include({
          associated_record_type: 'defendant_accounts',
          function_code: 'ACCOUNT_ENQUIRY',
        });

        this.assertAmendmentCoreFields(match);

        expect(match?.['new_value'], 'new_value should contain updated organisation name')
          .to.be.a('string')
          .and.include(expectedCompanyName);

        const oldValue = match?.['old_value'];
        const newValue = match?.['new_value'];

        if (oldValue && typeof oldValue === 'string' && oldValue.trim() !== '') {
          expect(oldValue, 'old_value should differ from new_value when both exist').to.not.eq(newValue);
        }

        logAE('done', 'Organisation amendment verified in amendments log', {
          amendmentId: match?.['amendment_id'],
          fieldCode: match?.['field_code'],
          oldValue: oldValue || '(empty)',
          newValue,
        });

        // Store the current amendment count for later comparison
        cy.wrap({ amendmentCount: amendments.length }).as('amendmentBaseline');
        logAE('info', 'Stored amendment count for baseline', { count: amendments.length });
      });
  }

  /**
   * Verifies that NO company amendments were created.
   * Saving without making changes should not create amendment records.
   *
   * Extracts the defendant account ID from the current URL and queries the amendments API
   * to verify no amendment records exist for company details.
   */
  public verifyNoCompanyAmendments(): void {
    logAE('method', 'verifyNoCompanyAmendments()');

    // Get the baseline amendment count from the previous verification step
    cy.get('@amendmentBaseline').then((baseline) => {
      const baselineCount = (baseline as unknown as { amendmentCount: number })?.amendmentCount ?? 0;
      logAE('info', 'Retrieved amendment baseline', { baselineCount });

      let defendantAccountId: number;

      this.extractDefendantAccountIdFromUrl()
        .then((id) => {
          defendantAccountId = id;
          return this.fetchHeaderSummary(id);
        })
        .then((headerBody) => {
          const partyId = headerBody['defendant_account_party_id'];
          expect(partyId, 'defendant_account_party_id must exist').to.exist;

          logAESync('info', `Found party ID: ${partyId}`);
          return defendantAccountId;
        })
        .then((id) => this.searchAmendmentsForAccount(id))
        .then(({ amendments }) => {
          logAE('info', 'Amendments search result', {
            searchDataLength: amendments.length,
            baselineCount,
          });

          // No NEW amendments should have been created since the baseline
          expect(
            amendments.length,
            `No amendment records should be created when no changes were made (baseline: ${baselineCount})`,
          ).to.eq(baselineCount);

          logAE('done', 'Verified no new amendments were created', {
            currentCount: amendments.length,
            baselineCount,
          });
        });
    });
  }

  /**
   * Verifies that NO parent/guardian amendments were created.
   *
   * Extracts the defendant account ID from the current URL and queries the amendments API
   * to verify no amendment records exist for parent/guardian details.
   */
  public verifyNoParentGuardianAmendments(): void {
    logAE('method', 'verifyNoParentGuardianAmendments()');

    // Get the baseline amendment count from the previous verification step
    cy.get('@amendmentBaseline').then((baseline) => {
      const baselineCount = (baseline as unknown as { amendmentCount: number })?.amendmentCount ?? 0;
      logAE('info', 'Retrieved amendment baseline', { baselineCount });

      let defendantAccountId: number;

      this.extractDefendantAccountIdFromUrl()
        .then((id) => {
          defendantAccountId = id;
          return this.fetchHeaderSummary(id);
        })
        .then((headerBody) => {
          const partyId = headerBody['defendant_account_party_id'];
          expect(partyId, 'defendant_account_party_id must exist').to.exist;

          logAESync('info', `Found party ID: ${partyId}`);
          return defendantAccountId;
        })
        .then((id) => this.searchAmendmentsForAccount(id))
        .then(({ amendments }) => {
          logAE('info', 'Amendments search result', {
            searchDataLength: amendments.length,
            baselineCount,
          });

          expect(
            amendments.length,
            `No amendment records should be created when no changes were made (baseline: ${baselineCount})`,
          ).to.eq(baselineCount);

          logAE('done', 'Verified no new amendments were created', {
            currentCount: amendments.length,
            baselineCount,
          });
        });
    });
  }
}

export default AccountEnquiryFlow;
