import { AccountNavDetailsLocators as N } from '../../../../../shared/selectors/account-details/account.nav.details.locators';
import { createScopedLogger } from '../../../../../support/utils/log.helper';

const log = createScopedLogger('AccountDetailsNavActions');

/**
 * @file account.details.nav.actions.ts
 * @description
 * Defines navigation and shell-level actions for the Account Details page,
 * including switching between sub-navigation tabs and interacting with
 * header-level buttons such as “Add account note”.
 *
 * @remarks
 * - Relies on centralized selectors from `AccountNavDetailsLocators`.
 * - Commonly used by flows like `AccountEnquiryFlow` and actions verifying
 *   correct tab transitions.
 * - Each method includes Cypress logging and consistent assertions.
 */
export class AccountDetailsNavActions {
  /**
   * Clicks the "Add account note" button in the page header.
   *
   * @description
   * Locates and clicks the “Add account note” button visible within the
   * Account Details shell header.
   *
   * @remarks
   * - Uses `force: true` to ensure interaction even if overlapping elements exist.
   * - Waits up to 10 seconds for visibility before clicking.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.clickAddAccountNoteButton();
   */
  clickAddAccountNoteButton(): void {
    log('navigate', 'Clicking "Add account note" button');

    cy.get(N.addAccountNoteButton, { timeout: 10_000 }).should('be.visible').click({ force: true });
  }

  /**
   * Navigates to the "Defendant" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Defendant” sub-navigation tab link using the centralized
   * locator and waits for the tab to become active.
   *
   * @remarks
   * - Relies on `subNav.defendantTab` from `AccountNavDetailsLocators`.
   * - Does not assert tab activation by default (pair with `assertDefendantTabIsActive()`).
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.goToDefendantTab();
   *  nav.assertDefendantTabIsActive();
   */
  goToDefendantTab(): void {
    log('navigate', 'Navigating to "Defendant" tab');

    cy.get(N.subNav.defendantTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Navigates to the "Parent or guardian" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Parent or guardian” sub-navigation tab and prepares for assertions
   * or further content checks within the tab panel.
   *
   * @remarks
   * - Relies on `subNav.parentOrGuardianTab` in `AccountNavDetailsLocators`.
   * - Does not automatically verify activation; pair with `assertParentGuardianTabIsActive()`.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.goToParentGuardianTab();
   *  nav.assertParentGuardianTabIsActive();
   */
  goToParentGuardianTab(): void {
    log('navigate', 'Navigating to "Parent or guardian" tab');

    cy.get(N.subNav.parentOrGuardianTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Navigates to the "Fixed penalty" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Fixed penalty” sub-navigation tab and prepares for assertions
   * or further content checks within the tab panel.
   */
  goToFixedPenaltyTab(): void {
    log('navigate', 'Navigating to "Fixed penalty" tab');

    cy.get(N.subNav.fixedPenaltyTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Asserts that the "Fixed penalty" tab is visible within the Account Details shell.
   *
   * @description
   * Confirms that the fixed-penalty sub-navigation tab is rendered and available to the user.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.assertFixedPenaltyTabIsVisible();
   */
  assertFixedPenaltyTabIsVisible(): void {
    log('assert', 'Asserting "Fixed penalty" tab is visible');

    cy.get(N.subNav.fixedPenaltyTab, { timeout: 10_000 }).should('be.visible').and('contain.text', 'Fixed penalty');
  }

  /**
   * Navigates to the "Payment terms" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Payment terms” sub-navigation tab and prepares for assertions
   * or further content checks within the tab panel.
   *
   * @remarks
   * - Relies on `subNav.paymentTermsTab` in `AccountNavDetailsLocators`.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.goToPaymentTermsTab();
   *  nav.assertPaymentTermsTabIsActive();
   */
  goToPaymentTermsTab(): void {
    log('navigate', 'Navigating to "Payment terms" tab');

    cy.get(N.subNav.paymentTermsTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Navigates to the "Creditor" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Creditor” sub-navigation tab and prepares for assertions
   * or further content checks within the tab panel.
   */
  goToCreditorTab(): void {
    log('navigate', 'Navigating to "Creditor" tab');

    cy.get(N.subNav.creditorTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Navigates to the "Enforcement" tab within the Account Details shell.
   *
   * @description
   * Clicks the “Enforcement” sub-navigation tab and prepares for assertions
   * or further content checks within the tab panel.
   */
  goToEnforcementTab(): void {
    log('navigate', 'Navigating to "Enforcement" tab');

    cy.get(N.subNav.enforcementTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Navigates to the "Impositions" tab within the Account Details shell.
   */
  goToImpositionsTab(): void {
    log('navigate', 'Navigating to "Impositions" tab');

    cy.get(N.subNav.impositionsTab, { timeout: 10_000 }).should('be.visible').click();
  }

  /**
   * Asserts that the "Parent or guardian" tab is currently active.
   *
   * @description
   * Validates that the currently active sub-navigation tab link contains
   * the label “Parent or guardian” and has `aria-current="page"`.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.assertParentGuardianTabIsActive();
   */
  assertParentGuardianTabIsActive(): void {
    log('assert', 'Asserting "Parent or guardian" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Parent or guardian');
  }

  /**
   * Asserts that the "Defendant" tab is currently active.
   *
   * @description
   * Confirms that the active tab link displays “Defendant” and has the
   * appropriate `aria-current="page"` attribute.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.assertDefendantTabIsActive();
   */
  assertDefendantTabIsActive(): void {
    log('assert', 'Asserting "Defendant" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Defendant');
  }

  /**
   * Asserts that the "At a glance" tab is currently active.
   *
   * @description
   * Confirms that the active sub-navigation tab shows the label “At a glance”
   * and has `aria-current="page"`.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.assertAtAGlanceTabIsActive();
   */
  assertAtAGlanceTabIsActive(): void {
    log('assert', 'Asserting "At a glance" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'At a glance');
  }

  /**
   * Asserts that the "Payment terms" tab is currently active.
   *
   * @description
   * Confirms that the active tab link displays “Payment terms”
   * and has the `aria-current="page"` attribute.
   *
   * @remarks
   * - Validates the active tab label and `aria-current="page"`.
   */
  assertPaymentTermsTabIsActive(): void {
    log('assert', 'Asserting "Payment terms" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Payment terms');
  }

  /**
   * Asserts that the "Creditor" tab is currently active.
   *
   * @description
   * Confirms that the active tab link displays “Creditor”
   * and has the `aria-current="page"` attribute.
   */
  assertCreditorTabIsActive(): void {
    log('assert', 'Asserting "Creditor" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Creditor');
  }

  /**
   * Asserts that the "Fixed penalty" tab is currently active.
   *
   * @description
   * Confirms that the active tab link displays "Fixed penalty" and has the
   * appropriate `aria-current="page"` attribute.
   */
  assertFixedPenaltyTabIsActive(): void {
    log('assert', 'Asserting "Fixed penalty" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Fixed penalty');
  }

  /**
   * Asserts that the "Enforcement" tab is currently active.
   *
   * @description
   * Confirms that the active tab link displays “Enforcement” and has the
   * appropriate `aria-current="page"` attribute.
   *
   * @example
   *  const nav = new AccountDetailsNavActions();
   *  nav.assertEnforcementTabIsActive();
   */
  assertEnforcementTabIsActive(): void {
    log('assert', 'Asserting "Enforcement" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Enforcement');
  }

  /**
   * Asserts that the "Impositions" tab is currently active.
   */
  assertImpositionsTabIsActive(): void {
    log('assert', 'Asserting "Impositions" tab is active');

    cy.get(N.subNav.currentTab, { timeout: 10_000 })
      .should('be.visible')
      .and('have.attr', 'aria-current', 'page')
      .and('contain.text', 'Impositions');
  }

  /**
   * Asserts the account details success banner shows the expected message.
   *
   * @param expected - Expected success banner text.
   */
  assertSuccessBannerText(expected: string): void {
    log('assert', 'Asserting account details success banner text', { expected });

    cy.get(N.banners.success, { timeout: 10_000 })
      .should('be.visible')
      .find(N.banners.successText)
      .should('contain.text', expected);
  }
}
