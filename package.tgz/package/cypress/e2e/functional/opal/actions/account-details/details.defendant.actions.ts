/**
 * @file details.defendant.actions.ts
 * @description Provides reusable UI interactions and assertions for the Defendant Details page.
 * Supports both individual and company account contexts.
 */
import { AccountDefendantDetailsLocators as L } from '../../../../../shared/selectors/account-details/account.defendant.details.locators';
import { CommonActions } from '../common/common.actions';

/** Actions and assertions for the Defendant tab on Account Details. */
export class AccountDetailsDefendantActions {
  readonly common = new CommonActions();

  /**
   * Assert section header text matches expectation
   * @param expected - Expected heading text.
   */
  assertSectionHeader(expected: string): void {
    cy.get(L.defendantTabHeader.title, this.common.getTimeoutOptions())
      .should('be.visible')
      .should(($h2) => {
        const actual = $h2.text().trim().toLowerCase();
        const exp = expected.trim().toLowerCase();
        expect(actual).to.contain(exp);
      });
  }

  /**
   * Clicks the top-right "Change" link in the Defendant tab header.
   *
   * Ensures the tab header is visible first, scrolls the link into view,
   * then clicks it. Optionally waits for a supplied form selector to appear.
   *
   * @param {Object} [opts] - Optional configuration for the click/wait.
   * @param {number} [opts.timeout=10000] - Max time to wait for elements.
   * @param {string} [opts.formSelector] - If provided, waits for this form to be visible after clicking.
   */
  change(opts?: { timeout?: number; formSelector?: string }): void {
    const timeout = opts?.timeout ?? 10_000;

    // Make sure we're on the Defendant tab and its header is visible
    cy.get(L.defendantTabHeader.title, { timeout }).should('be.visible');

    // Click the "Change" link in the Defendant tab header
    cy.get(L.defendantTabHeader.changeLink, { timeout })
      .contains('Change')
      .should('be.visible')
      .scrollIntoView()
      .click({ force: true });

    // Optionally wait for the edit form to appear
    if (opts?.formSelector) {
      cy.get(opts.formSelector, { timeout }).should('be.visible');
    }
  }

  /**
   * Asserts the defendant name on the summary card contains the expected value.
   * @param expected text expected in the name field
   */
  assertDefendantNameContains(expected: string): void {
    cy.get(L.defendant.fields.name, this.common.getTimeoutOptions()).should('contain.text', expected);
  }

  /**
   * Asserts the defendant summary card is rendered in the Defendant tab.
   */
  assertDefendantSummaryVisible(): void {
    cy.get(L.defendant.card, this.common.getTimeoutOptions()).should('be.visible');
  }

  /**
   * Asserts the defendant summary card is not rendered in the Defendant tab.
   */
  assertDefendantSummaryNotPresent(): void {
    cy.get(L.defendant.card, this.common.getTimeoutOptions()).should('not.exist');
  }

  /**
   * Asserts the primary email address shown in the contact summary contains the expected value.
   *
   * @param expected - Expected text within the primary email field.
   */
  assertPrimaryEmailContains(expected: string): void {
    cy.get(L.contact.fields.primaryEmail, this.common.getTimeoutOptions()).should('contain.text', expected);
  }

  /**
   * Asserts that the convert-to-company action is visible in the Defendant tab.
   */
  assertConvertToCompanyActionVisible(): void {
    cy.get(L.actions.convertAction, this.common.getTimeoutOptions())
      .should('be.visible')
      .and('contain.text', 'Convert to a company account');
  }

  /**
   * Asserts that the convert-to-individual action is visible in the Defendant tab.
   */
  assertConvertToIndividualActionVisible(): void {
    cy.get(L.actions.convertAction, this.common.getTimeoutOptions())
      .should('be.visible')
      .and('contain.text', 'Convert to an individual account');
  }

  /**
   * Asserts that the add parent/guardian action is visible in the Defendant tab.
   */
  assertAddParentGuardianActionVisible(): void {
    cy.contains(
      L.actions.addParentGuardianActionLink,
      L.actions.addParentGuardianActionLabel,
      this.common.getTimeoutOptions(),
    ).should('be.visible');
  }

  /**
   * Asserts that the visible convert action does not contain the company label.
   */
  assertConvertToCompanyActionTextNotPresent(): void {
    cy.get(L.actions.convertAction, this.common.getTimeoutOptions())
      .should('be.visible')
      .and('not.contain.text', 'Convert to a company account');
  }

  /**
   * Clicks the convert-to-company action from the Defendant tab.
   */
  startConvertToCompanyAccount(): void {
    cy.get(L.actions.convertActionLink, this.common.getTimeoutOptions()).should('be.visible').click();
  }

  /**
   * Clicks the convert-to-individual action from the Defendant tab.
   */
  startConvertToIndividualAccount(): void {
    cy.get(L.actions.convertActionLink, this.common.getTimeoutOptions()).should('be.visible').click();
  }

  /**
   * Clicks the add parent/guardian action from the Defendant tab.
   */
  startAddParentGuardianDetails(): void {
    cy.contains(
      L.actions.addParentGuardianActionLink,
      L.actions.addParentGuardianActionLabel,
      this.common.getTimeoutOptions(),
    )
      .should('be.visible')
      .click();
  }

  /**
   * Asserts that the convert-to-company action is not rendered in the Defendant tab.
   */
  assertConvertToCompanyActionNotPresent(): void {
    cy.get(L.actions.convertAction, this.common.getTimeoutOptions()).should('not.exist');
  }
}
