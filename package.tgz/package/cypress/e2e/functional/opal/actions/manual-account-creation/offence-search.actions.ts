/**
 * @file Actions for the Manual Account Creation **Offence search** pages.
 * @description Covers entering search criteria, submitting, navigating back, and validating results.
 */
import {
  MacOffenceDetailsLocators as L,
  MacOffenceDetailsSearchOffenceResultsLocators as R,
} from '../../../../../shared/selectors/manual-account-creation/mac.offence-details.locators';
import { createScopedLogger } from '../../../../../support/utils/log.helper';
import { CommonActions } from '../common/common.actions';

const log = createScopedLogger('ManualOffenceSearchActions');

type SearchField = 'Offence code' | 'Short title' | 'Act and section';
type ResultsColumn = 'Code' | 'Short title' | 'Act and section' | 'Used from' | 'Used to';

/** Actions for the Manual Account Creation Offence search flow. */
export class ManualOffenceSearchActions {
  private readonly common = new CommonActions();
  private readonly pathTimeout = this.common.getPathTimeout();
  private readonly paginationLimit = 10;

  /**
   * Asserts the search form page is displayed.
   * @param expectedHeader - Expected header text fragment.
   */
  assertOnSearchPage(expectedHeader: string = 'Search offences'): void {
    cy.location('pathname', { timeout: this.pathTimeout }).should('include', 'search-offences');
    this.common.assertHeaderContains(expectedHeader, this.pathTimeout);
  }

  /**
   * Asserts the search results page is displayed.
   * @param expectedHeader - Expected header text fragment.
   */
  assertOnResultsPage(expectedHeader: string = 'Search results'): void {
    cy.location('pathname', { timeout: this.pathTimeout }).should('include', 'search-offences-results');
    this.common.assertHeaderContains(expectedHeader, this.pathTimeout);
  }

  /**
   * Sets a search field value.
   * @param field - Logical field label.
   * @param value - Value to type.
   */
  setSearchField(field: SearchField, value: string): void {
    const selector = this.resolveFieldSelector(field);
    log('type', 'Setting offence search field', { field, value });
    cy.get(selector, this.common.getTimeoutOptions())
      .should('exist')
      .scrollIntoView()
      .clear({ force: true })
      .type(value, { force: true, delay: 0 })
      .should('have.value', value);
  }

  /**
   * Clears a search field.
   * @param field - Logical field label.
   */
  clearSearchField(field: SearchField): void {
    const selector = this.resolveFieldSelector(field);
    log('clear', 'Clearing offence search field', { field });
    cy.get(selector, this.common.getTimeoutOptions())
      .should('exist')
      .scrollIntoView()
      .clear({ force: true })
      .should('have.value', '');
  }

  /**
   * Asserts a search field value.
   * @param field - Logical field label.
   * @param expected - Expected value.
   */
  assertSearchFieldValue(field: SearchField, expected: string): void {
    const selector = this.resolveFieldSelector(field);
    log('assert', 'Asserting offence search field value', { field, expected });
    cy.get(selector, this.common.getTimeoutOptions()).should('have.value', expected);
  }

  /**
   * Toggles the Include inactive offence codes checkbox.
   * @param checked - Desired state.
   */
  toggleIncludeInactive(checked: boolean): void {
    log('click', 'Toggling include inactive offences', { checked });
    const action = checked ? 'check' : 'uncheck';
    cy.get(L.search.includeInactiveCheckbox, this.common.getTimeoutOptions())
      .should('exist')
      .scrollIntoView()
      [action]({ force: true });
  }

  /**
   * Submits the search form.
   */
  submitSearch(): void {
    log('action', 'Submitting offence search');
    cy.get(L.search.searchButton, this.common.getTimeoutOptions()).should('be.visible').click();
  }

  /**
   * Clicks the back link on the results page.
   */
  clickBackLink(): void {
    log('navigate', 'Navigating back from search results');
    cy.get(L.search.backLink, this.common.getTimeoutOptions()).should('exist').click({ force: true });
  }

  /**
   * Asserts a value exists within a search results column.
   * @param column - Column heading.
   * @param expected - Expected text.
   */
  assertResultContains(column: ResultsColumn, expected: string): void {
    this.assertResultsIncludeValues(column, [expected]);
  }

  /**
   * Asserts every result row in a column contains the expected text.
   * @param column - Column heading.
   * @param expected - Text each row should include.
   */
  assertAllResultsContain(column: ResultsColumn, expected: string): void {
    const cellId = this.resolveResultColumnId(column);
    log('assert', 'Validating all search results contain value', { column, expected });
    cy.get(R.app, this.common.getTimeoutOptions())
      .find(`td#${cellId}`)
      .should('have.length.greaterThan', 0)
      .each(($cell) => cy.wrap($cell).should('contain.text', expected));
  }

  /**
   * Asserts that the results contain at least one row for each expected value in a column.
   * @param column - Column heading.
   * @param expectedValues - Values that must appear in at least one row.
   */
  assertResultsIncludeValues(column: ResultsColumn, expectedValues: string[]): void {
    const cellId = this.resolveResultColumnId(column);
    log('assert', 'Validating search results include values', { column, expectedValues });
    const foundValues = new Set<string>();

    const scanPage = (remainingPages: number) => {
      cy.get(R.app, this.common.getTimeoutOptions()).should('exist');
      cy.get('body', this.common.getTimeoutOptions()).then(($body) => {
        const values = Array.from($body.find(`${R.app} td#${cellId}`), (cell) => cell.textContent?.trim() ?? '');

        expectedValues.forEach((expected) => {
          if (values.some((value) => this.normalizeResultText(value).includes(this.normalizeResultText(expected)))) {
            foundValues.add(expected);
          }
        });

        const missingValues = expectedValues.filter((expected) => !foundValues.has(expected));
        if (!missingValues.length) {
          return;
        }

        const nextPage = $body.find(R.nextPageButton).first();
        const hasNextPage = nextPage.length > 0;

        if (hasNextPage && remainingPages > 0) {
          const currentPage = $body.find(R.paginationCurrentPage).first().text().trim();
          const paginationText = $body.find(R.paginationText).first().text().trim();
          cy.wrap(nextPage).scrollIntoView().click({ force: true });
          if (currentPage) {
            cy.get(R.paginationCurrentPage, this.common.getTimeoutOptions()).should(($currentPage) => {
              expect($currentPage.text().trim(), 'pagination advanced').not.to.equal(currentPage);
            });
          } else if (paginationText) {
            cy.get(R.paginationText, this.common.getTimeoutOptions()).should(($paginationText) => {
              expect($paginationText.text().trim(), 'pagination status changed').not.to.equal(paginationText);
            });
          }
          scanPage(remainingPages - 1);
          return;
        }

        throw new Error(
          `Expected offence search results column "${column}" to include ${missingValues
            .map((value) => `"${value}"`)
            .join(', ')} across paginated results. Last visible values: ${values.join(' | ') || '[none]'}`,
        );
      });
    };

    scanPage(this.paginationLimit);
  }

  /**
   * Returns all values from a column in the current results table.
   * @param column - Column heading.
   * @returns Chainable yielding an array of trimmed column values.
   */
  getResultColumnValues(column: ResultsColumn): Cypress.Chainable<string[]> {
    const cellId = this.resolveResultColumnId(column);
    return cy
      .get(R.app, this.common.getTimeoutOptions())
      .find(`td#${cellId}`)
      .then(($cells) => Array.from($cells, (cell) => cell.textContent?.trim() ?? ''));
  }

  /**
   * Resolves a logical search field label to its input selector.
   * @param field - Offence search field name.
   * @returns CSS selector for the input field.
   * @throws Error when an unknown field is provided.
   */
  private resolveFieldSelector(field: SearchField): string {
    switch (field) {
      case 'Offence code':
        return L.search.offenceCodeInput;
      case 'Short title':
        return L.search.shortTitleInput;
      case 'Act and section':
        return L.search.actAndSectionInput;
      default:
        throw new Error(`Unknown search field: ${field}`);
    }
  }

  /**
   * Resolves a results column heading to its table cell id.
   * @param column - Column name as displayed in the results table.
   * @returns Cell id used for the column.
   * @throws Error when an unknown column is provided.
   */
  private resolveResultColumnId(column: ResultsColumn): string {
    const normalized = column.toLowerCase();
    if (normalized.includes('code')) return 'code';
    if (normalized.includes('short title')) return 'shortTitle';
    if (normalized.includes('act')) return 'actAndSection';
    if (normalized.includes('used from')) return 'usedFrom';
    if (normalized.includes('used to')) return 'usedTo';
    throw new Error(`Unknown results column: ${column}`);
  }

  /**
   * Normalizes result text so cross-page assertions tolerate whitespace differences.
   * @param value - Raw cell or expected text.
   * @returns Lower-cased normalized text.
   */
  private normalizeResultText(value: string): string {
    return value
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }
}
