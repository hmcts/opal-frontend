/**
 * @file Actions for Manual Account Creation - Account details task list.
 * @description Provides helpers to open tasks, assert status, and confirm header presence.
 */
import {
  MacAccountDetailsLocators as L,
  MacAccountTaskName,
} from '../../../../../shared/selectors/manual-account-creation/mac.account-details.locators';
import { createScopedLogger } from '../../../../../support/utils/log.helper';
import { CommonActions } from '../common/common.actions';
import { applyUniqPlaceholder } from '../../../../../support/utils/stringUtils';

const log = createScopedLogger('ManualAccountDetailsActions');
type OriginatorType = 'New' | 'Transfer in';
type EntryType = 'New account' | 'Transfer in from England or Wales';
const TASK_NAMES: MacAccountTaskName[] = [
  'Account comments and notes',
  'Company details',
  'Contact details',
  'Court details',
  'Employer details',
  'Parent or guardian details',
  'Personal details',
  'Offence details',
  'Payment terms',
];

/**
 * Task list helpers for Manual Account Creation Account details.
 */
export class ManualAccountDetailsActions {
  private readonly common = new CommonActions();

  /**
   * Opens a task list item by its display name.
   * @param taskName Task display name from the account details list.
   */
  openTask(taskName: MacAccountTaskName): void {
    const normalizedTask = (taskName ?? '').trim() as MacAccountTaskName;
    if (!TASK_NAMES.includes(normalizedTask)) {
      throw new Error(`Unsupported Account details task "${taskName}". Expected one of: ${TASK_NAMES.join(', ')}`);
    }

    log('navigate', 'Opening task from account details', { taskName: normalizedTask });

    cy.get(L.taskList.itemByName(normalizedTask), this.common.getTimeoutOptions())
      .should('be.visible')
      .within(() => {
        cy.get(L.taskList.link).first().should('be.visible').click();
      });
  }

  /**
   * Asserts the status text for a given task list item.
   * @param taskName Task display name to check.
   * @param expectedStatus Expected status text (e.g., "Completed").
   * @param expectedHeader Expected Account details header (defaults to "Account details").
   */
  assertTaskStatus(
    taskName: MacAccountTaskName,
    expectedStatus: string,
    expectedHeader: string = 'Account details',
  ): void {
    log('assert', 'Asserting task status', { taskName, expectedStatus, expectedHeader });

    this.assertOnAccountDetailsPage(expectedHeader);
    cy.get(L.taskList.itemByName(taskName), this.common.getTimeoutOptions())
      .should('be.visible')
      .find(L.taskList.status)
      .should('contain.text', expectedStatus);
  }

  /**
   * Ensures the Account Details header is visible.
   */
  /**
   * Asserts the account details page is loaded.
   * - Always guards the pathname to include `/account-details`.
   * - If `expectedHeader` is provided, asserts the header contains it.
   * - If `expectedHeader` is omitted/undefined, asserts the default header "Account details".
   * - If `expectedHeader` is null, skips header assertion (path guard still applies).
   * - If `originatorType` is provided, asserts the "Entry type" row for that originator.
   * @param expectedHeader Optional header to assert; null skips header assertion.
   * @param originatorType Optional originator type ("New" | "Transfer in") to assert via Entry type.
   */
  assertOnAccountDetailsPage(expectedHeader?: string | null, originatorType?: OriginatorType): void {
    cy.location('pathname', this.common.getTimeoutOptions()).should('include', '/account-details');
    const headerToAssert = expectedHeader === undefined ? 'Account details' : expectedHeader;
    const normalizedHeader = headerToAssert === null ? null : applyUniqPlaceholder(headerToAssert);
    if (normalizedHeader) {
      this.common.assertHeaderContains(normalizedHeader);
    }
    if (originatorType) {
      const expectedEntryType: EntryType =
        originatorType === 'Transfer in' ? 'Transfer in from England or Wales' : 'New account';
      this.assertEntryType(expectedEntryType);
    }
  }

  /**
   * Asserts a language preference value in the Account details summary list.
   * @param label - Row label ("Document language" or "Hearing language").
   * @param expectedValue - Expected value text.
   */
  assertLanguagePreference(label: 'Document language' | 'Hearing language', expectedValue: string): void {
    log('assert', 'Checking account language preference', { label, expectedValue });

    cy.contains(L.summaryList.languageRow, label, this.common.getTimeoutOptions())
      .should('be.visible')
      .within(() => {
        cy.get(L.summaryList.value)
          .invoke('text')
          .should((text) => expect(text.trim()).to.equal(expectedValue));
      });
  }

  /**
   * Asserts the entry type for the account.
   * @param expectedType Expected entry type ("New account" or "Transfer in from England or Wales").
   */
  assertEntryType(expectedType: 'New account' | 'Transfer in from England or Wales'): void {
    log('assert', 'Asserting entry type contain correct value', { expectedType });
    cy.get(L.entryType)
      .invoke('text')
      .then((text) =>
        text
          .replace(/\u00a0/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
          .toLowerCase(),
      )
      .should((actualText) => {
        if (expectedType === 'New account') {
          // UI copy differs by journey/version; both labels map to the same originator type.
          expect(actualText, 'entry type should contain either "New account" or "Create new account"').to.satisfy(
            (value: string) => value.includes('new account') || value.includes('create new account'),
          );
          return;
        }

        expect(actualText).to.contain('transfer in from england or wales');
      });
  }

  /**
   * Opens the Change link for a language preference row.
   * @param label - Row label ("Document language" or "Hearing language").
   */
  openLanguagePreference(label: 'Document language' | 'Hearing language'): void {
    log('navigate', 'Opening language preference change link', { label });

    cy.contains(L.summaryList.languageRow, label, this.common.getTimeoutOptions())
      .should('be.visible')
      .within(() => {
        cy.get(L.summaryList.changeLink).should('contain.text', 'Change').scrollIntoView().click({ force: true });
      });
  }
}
