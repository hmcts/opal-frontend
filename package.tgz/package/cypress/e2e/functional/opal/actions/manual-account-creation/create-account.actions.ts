/**
 * @file Actions for Manual Account Creation - Create account page.
 * @description Encapsulates business unit selection, account type/defendant type selection, and navigation to task list.
 */
import { MacCreateAccountLocators as L } from '../../../../../shared/selectors/manual-account-creation/mac.create-account.locators';
import { createScopedLogger } from '../../../../../support/utils/log.helper';
import { CommonActions } from '../common/common.actions';
import { AccountType } from '../../../../../support/utils/payloads';
import { CreateManageDraftsActions } from '../draft-account/create-manage-drafts.actions';

const log = createScopedLogger('ManualCreateAccountActions');
const DIRECT_MANUAL_ACCOUNT_CREATION_LINK = '#finesMacLink';

export type DefendantType =
  | 'Adult or youth'
  | 'Adult or youth only'
  | 'Adult or youth with parent or guardian to pay'
  | 'Parent or guardian'
  | 'Company';

/** Actions for the Manual Account Creation landing page. */
export class ManualCreateAccountActions {
  private readonly common = new CommonActions();
  private readonly createManageDrafts = new CreateManageDraftsActions();

  /**
   * Opens Manual Account Creation from the Accounts landing page.
   * @param route - `direct` uses the legacy direct link; `cam` uses Create and Manage Draft Accounts first.
   */
  openFromAccountsPage(route: 'direct' | 'cam' = 'cam'): void {
    if (route === 'direct') {
      log('navigate', 'Opening Manual Account Creation using direct Accounts-page link');
      cy.get(DIRECT_MANUAL_ACCOUNT_CREATION_LINK, { timeout: 20_000 }).should('be.visible').click({ force: true });
      return;
    }

    log('navigate', 'Opening Manual Account Creation using Create and Manage Draft Accounts route');
    this.createManageDrafts.openPageFromAccounts();
    this.createManageDrafts.assertOnPage();
    this.createManageDrafts.clickCreateAccount();
  }

  /**
   * Confirms the Manual Account Creation landing page is visible.
   *
   * @param expectedHeader Optional header text to assert.
   */
  assertOnCreateAccountPage(expectedHeader: string = 'Create account'): void {
    log('assert', 'Asserting manual account creation landing page', { expectedHeader });
    cy.get(L.heading, { timeout: 15_000 }).should('contain.text', expectedHeader);
  }

  /**
   * Selects a business unit via autocomplete.
   * @param businessUnit Business unit name to select.
   */
  selectBusinessUnit(businessUnit: string): void {
    log('type', 'Selecting business unit', { businessUnit });
    cy.get(L.businessUnit.input, { timeout: 15_000 })
      .first()
      .should('exist')
      .should('be.visible')
      .scrollIntoView()
      .clear({ force: true })
      .type(businessUnit, { delay: 0, force: true });

    cy.get(L.businessUnit.listbox, this.common.getTimeoutOptions()).first().should('be.visible');

    cy.get(L.businessUnit.input).first().focus().type('{downarrow}{enter}', { force: true });

    cy.get(L.businessUnit.input)
      .first()
      .invoke('val')
      .should((val) => {
        expect(String(val ?? '')).to.not.equal('', 'Business unit should be selected');
      });
  }

  /**
   * Chooses an account type radio option.
   * @param type Account type to select (Fine/Fixed penalty/Conditional caution).
   */
  selectAccountType(type: AccountType): void {
    const normalized = type.toLowerCase();
    const selector =
      normalized === 'fine'
        ? L.accountType.fine
        : normalized.startsWith('fixed penalty')
          ? L.accountType.fixedPenalty
          : L.accountType.conditionalCaution;

    log('click', 'Selecting account type', { type });
    cy.get(selector, this.common.getTimeoutOptions()).first().should('exist').scrollIntoView().check({ force: true });

    if (normalized === 'fine') {
      cy.get(L.defendantTypePanel.fine, this.common.getTimeoutOptions()).should('be.visible');
    } else if (normalized.startsWith('fixed penalty')) {
      cy.get(L.defendantTypePanel.fixedPenalty, this.common.getTimeoutOptions()).should('be.visible');
    }
  }

  /**
   * Chooses a defendant type radio option.
   * @param defendantType Defendant type to select.
   */
  selectDefendantType(defendantType: DefendantType): void {
    const normalized = defendantType.toLowerCase();
    let selector: string = L.defendantType.adultOrYouth;

    if (normalized.includes('guardian')) {
      selector = L.defendantType.parentOrGuardianToPay;
    } else if (normalized.includes('company')) {
      selector = L.defendantType.company;
    }

    log('click', 'Selecting defendant type', { defendantType });
    cy.get('body', this.common.getTimeoutOptions()).then(($body) => {
      const fixedPenaltyChecked = $body.find(L.accountType.fixedPenalty).filter(':checked').length > 0;
      const fineChecked = $body.find(L.accountType.fine).filter(':checked').length > 0;

      const panelSelector = fixedPenaltyChecked
        ? L.defendantTypePanel.fixedPenalty
        : fineChecked
          ? L.defendantTypePanel.fine
          : null;

      if (panelSelector) {
        cy.get(panelSelector, this.common.getTimeoutOptions())
          .should('be.visible')
          .within(() => {
            cy.get(selector, this.common.getTimeoutOptions())
              .first()
              .should('exist')
              .scrollIntoView()
              .check({ force: true });
          });
        return;
      }

      cy.get(selector, this.common.getTimeoutOptions())
        .filter(':visible')
        .first()
        .should('exist')
        .scrollIntoView()
        .check({ force: true });
    });
  }

  /**
   * Continues to the Account Details task list.
   */
  continueToAccountDetails(): void {
    log('navigate', 'Continuing to account details task list');
    cy.get(L.continueButton, this.common.getTimeoutOptions()).should('be.visible').click();
  }

  /**
   * Clicks the back link to return to the previous page.
   */
  selectBackLink(): void {
    log('navigate', 'Clicking back link');
    cy.get(L.backLink, this.common.getTimeoutOptions()).should('be.visible').click();
  }

  /**
   * Confirms the Manual Account Creation Transfer In landing page is visible.
   *
   * @param expectedHeader Optional header text to assert.
   */
  assertOnTransferInPage(expectedHeader: string = 'Transfer in'): void {
    log('assert', 'Asserting manual account creation landing page', { expectedHeader });
    cy.get(L.heading, { timeout: 15_000 }).should('contain.text', expectedHeader);
  }

  /**
   * Handles Cancel click with the provided confirm choice.
   * @param choice Confirmation choice (Cancel/Ok).
   */
  cancelAndChoose(choice: 'Cancel' | 'Ok'): void {
    const accept = /ok|leave/i.test(choice);
    log('cancel', 'Cancelling create account', { choice, accept });
    this.common.confirmNextUnsavedChanges(accept);

    cy.get(L.cancelLink, this.common.getTimeoutOptions()).should('exist').scrollIntoView().click({ force: true });
  }
}
