/**
 * @file account.search.nav.locators.ts
 * @description
 * Locators for the **Account Search navigation tabs**.
 *
 * Tabs included:
 * - Individuals
 * - Companies
 * - Major creditors
 * - Minor creditors
 *
 * Notes:
 * - These IDs follow the same pattern used in other search panels.
 * - Only tab controls are defined here; panel-specific fields live in their
 *   respective locator files (e.g. account.search.individuals.locators.ts).
 */

export const AccountSearchNavLocators = {
  /** Tabs component wrapping the account-search tab set. */
  tabsContainer: 'opal-lib-govuk-tabs, #defendantTabs',

  /** GOV.UK tab list rendered within the tabs component. */
  tabsList: '.govuk-tabs__list',

  /** Individuals tab toggle */
  individualsTab: '[tabitemid="tab-individuals"]',

  /** Companies tab toggle */
  companiesTab: '[tabitemid="tab-companies"]',

  /** Major creditors tab toggle */
  majorCreditorsTab: '[tabitemid="tab-major-creditors"]',

  /** Minor creditors tab toggle */
  minorCreditorsTab: '[tabitemid="tab-minor-creditors"]',
} as const;

export type AccountSearchNavLocatorKeys = keyof typeof AccountSearchNavLocators;
