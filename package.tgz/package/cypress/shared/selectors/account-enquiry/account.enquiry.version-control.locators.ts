/**
 * @file account.enquiry.version-control.locators.ts
 * @description
 * Shared selector map for account-enquiry version-control banners and shell tab navigation.
 *
 * @remarks
 * - Preserves the legacy export name used by component specs to keep migration mechanical.
 */
export const DOM_ELEMENTS = {
  // Warning Banner Elements
  warningBanner: '.moj-alert',
  warningBannerIcon: 'opal-lib-moj-alert-icon[type="warning"]',
  warningBannerText: 'opal-lib-moj-alert-content-text',
  labelPaymentsOnHold: 'Payments to this creditor are on hold.',
  bannerText: 'opal-lib-moj-alert-content-text',
  refreshLink: 'opal-lib-moj-alert-content-text > a',

  // Success Banner Elements
  successBanner: 'opal-lib-moj-alert[type="success"]',
  successBannerIcon: 'opal-lib-moj-alert-icon[type="success"]',
  successBannerText: 'opal-lib-moj-alert-content-text',
  successBannerDismiss: '.moj-alert__dismiss',
  labelPaymentHoldRemoved: 'Payment hold removed',

  // Tab Elements
  atAGlanceTab: '[subnavitemid="at-a-glance-tab"] > .moj-sub-navigation__link',
  impositionsTab: '[subnavitemid="impositions-tab"] > .moj-sub-navigation__link',
  paymentHistoryTab: '[subnavitemid="payment-history-tab"] > .moj-sub-navigation__link',
  historyNotesTab: '[subnavitemid="history-and-notes-tab"] > .moj-sub-navigation__link',
  defendantTab: '[subnavitemid="defendant-tab"] > .moj-sub-navigation__link',
  parentGuardianTab: '[subnavitemid="parent-or-guardian-tab"] > .moj-sub-navigation__link',
  paymentTermsTab: '[subnavitemid="payment-terms-tab"] > .moj-sub-navigation__link',
  enforcementTab: '[subnavitemid="enforcement-tab"] > .moj-sub-navigation__link',
} as const;
