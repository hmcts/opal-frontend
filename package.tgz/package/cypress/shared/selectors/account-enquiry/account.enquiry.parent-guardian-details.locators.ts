/**
 * @file account.enquiry.parent-guardian-details.locators.ts
 * @description
 * Shared selector map for the Account Enquiry parent-or-guardian tab.
 *
 * @remarks
 * - Preserves the legacy export name used by component specs to keep migration mechanical.
 */
type AccountEnquiryParentGuardianLocators = {
  changeLink: string;
  removeParentGuardianLink: string;
  parentOrGuardianDetailsName: string;
  parentOrGuardianDetailsAliases: string;
  parentOrGuardianDetailsDob: string;
  parentOrGuardianDetailsAddressKey: string;
  parentOrGuardianDetailsVehicleMake: string;
  parentOrGuardianDetailsVehicleReg: string;
  parentOrGuardianDetailsNational_insurance_numberKey: string;
  contactSummaryCardTitle: string;
  contactDetailsPrimaryEmailKey: string;
  contactDetailsSecondaryEmailKey: string;
  contactDetailsMobilePhoneKey: string;
  contactDetailsHomePhoneKey: string;
  contactDetailsWorkPhoneKey: string;
  employerDetailsNameKey: string;
  employerDetailsReferenceKey: string;
  employerDetailsEmailKey: string;
  employerDetailsPhoneKey: string;
  employerDetailsAddressKey: string;
  languagePreferencePreferred: string;
  DocumentLanguageKey: string;
  courtHearingLanguageKey: string;
  accountCommentsNotesKey: string;
};

export const DOM_ELEMENTS: AccountEnquiryParentGuardianLocators = {
  // Header actions
  changeLink: 'a.govuk-link.govuk-\\!-margin-bottom-0',
  removeParentGuardianLink: '.govuk-grid-column-one-third a.govuk-link.govuk-link--no-visited-state',

  // Personal Details
  parentOrGuardianDetailsName: '#parentOrGuardianDetailsNameValue',
  parentOrGuardianDetailsAliases: '#parentOrGuardianDetailsAliasesKey',
  parentOrGuardianDetailsDob: '#parentOrGuardianDetailsDobKey',
  parentOrGuardianDetailsAddressKey: '#parentOrGuardianDetailsAddressKey',
  parentOrGuardianDetailsVehicleMake: '#parentOrGuardianDetailsVehicle_make_and_modelKey',
  parentOrGuardianDetailsVehicleReg: '#parentOrGuardianDetailsVehicle_registrationKey',
  parentOrGuardianDetailsNational_insurance_numberKey: '#parentOrGuardianDetailsNational_insurance_numberKey',

  // Contact Details
  contactSummaryCardTitle:
    '#contact-summary-card-list > .govuk-summary-card__title-wrapper > .govuk-summary-card__title',
  contactDetailsPrimaryEmailKey: '#contactDetailsPrimary_email_addressKey',
  contactDetailsSecondaryEmailKey: '#contactDetailsSecondary_email_addressKey',
  contactDetailsMobilePhoneKey: '#contactDetailsMobile_telephone_numberKey',
  contactDetailsHomePhoneKey: '#contactDetailsHome_telephone_numberKey',
  contactDetailsWorkPhoneKey: '#contactDetailsWork_telephone_numberKey',

  // Employer Details
  employerDetailsNameKey: '#employerDetailsEmployer_nameKey',
  employerDetailsReferenceKey: '#employerDetailsEmployer_referenceKey',
  employerDetailsEmailKey: '#employerDetailsEmployer_email_addressKey',
  employerDetailsPhoneKey: '#employerDetailsEmployer_telephone_numberKey',
  employerDetailsAddressKey: '#employerDetailsEmployer_addressKey',

  // Language Preference
  languagePreferencePreferred:
    '#language-summary-card-list > .govuk-summary-card__title-wrapper > .govuk-summary-card__title',
  DocumentLanguageKey: '#languagePreferencesDocument_languageKey',
  courtHearingLanguageKey: '#languagePreferencesHearing_languageKey',

  // Account Comments
  accountCommentsNotesKey: '#accountCommentsNotesKey',
} as const;
