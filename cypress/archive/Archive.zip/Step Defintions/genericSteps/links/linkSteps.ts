import { Then, When } from '@badeball/cypress-cucumber-preprocessor';
import { clickLinkAcrossPages } from '../../../step_definitions/genericSteps/links/linkHelpers';

/* ------------------------------------------------------------------------------------------------
 * Cucumber steps
 * ----------------------------------------------------------------------------------------------*/

Then('I click on the {string} link', (linkText: string) => {
  const opts = {
    waitAfterPageMs: 200,
    maxPages: 30,
    paginationRetries: 5,
    paginationRetryDelayMs: 500,
    singlePageRetries: 6,
    singlePageRetryDelayMs: 500,
    singlePageRefreshSelector: '.moj-sub-navigation__link[aria-current="page"]',
  };

  const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(escapeRegex(linkText), 'i');

  // Wait for the page to render *something*, but don't fail if the link isn't there yet.
  cy.get('body', { timeout: 5000 }).then(($body) => {
    const $match = $body.find('a').filter((_, el) => re.test(el.textContent || ''));
    if ($match.length) {
      cy.wrap($match.first())
        .scrollIntoView({ offset: { top: -100, left: 0 } })
        .should('be.visible')
        .click();
    } else {
      cy.log(`Link "${linkText}" not on this page — trying pagination…`);
      clickLinkAcrossPages(linkText, opts);
    }
  });
});

When('{string} is clicked', (linkText: string) => {
  cy.get('a').contains(linkText).click();
});

When('I click the {string} link in the {string} section', (linkText: string, _section: string) => {
  cy.contains('a', linkText).first().click();
});

When('{string} is clicked, nothing happens', (linkText: string) => {
  let initialUrl: string;
  cy.url().then((url) => {
    initialUrl = url.toString();
    cy.get('a').contains(linkText).click();
    cy.url().should('eq', initialUrl);
  });
});

When('the link with text {string} should not be present', (linkText: string) => {
  cy.contains('a', linkText).should('not.exist');
});

Then('I click on the {string} link for imposition {int}', (linkText: string, index: number) => {
  cy.contains('legend', 'Impositions')
    .closest('fieldset')
    .find('opal-lib-moj-ticket-panel')
    .eq(index - 1)
    .contains('a', linkText)
    .click();
});

Then('I see the {string} link for imposition {int}', (linkText: string, index: number) => {
  cy.contains('legend', 'Impositions')
    .closest('fieldset')
    .find('opal-lib-moj-ticket-panel')
    .eq(index - 1)
    .contains('a', linkText)
    .should('exist');
});

Then('I do not see the {string} link for imposition {int}', (linkText: string, index: number) => {
  cy.contains('legend', 'Impositions')
    .closest('fieldset')
    .find('opal-lib-moj-ticket-panel')
    .eq(index - 1)
    .contains('a', linkText)
    .should('not.exist');
});

Then('I click the {string} link for offence {string}', (linkText: string, offence: string) => {
  cy.contains('app-fines-mac-offence-details-review-offence', offence).find('a').contains(linkText).click();
});

Then('I see the {string} link for offence {string}', (linkText: string, offence: string) => {
  cy.contains('app-fines-mac-offence-details-review-offence', offence).find('a').contains(linkText).should('exist');
});

Then('I open the {string} link in the same tab', (linkText: string) => {
  cy.get('a').contains(linkText).invoke('removeAttr', 'target').click();
});
